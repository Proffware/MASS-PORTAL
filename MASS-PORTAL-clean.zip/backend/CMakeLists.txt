cmake_minimum_required(VERSION 3.20)
if(POLICY CMP0135)
    cmake_policy(SET CMP0135 NEW)
endif()

project(mass_backend VERSION 2.9.0 LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 20)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_EXTENSIONS OFF)

option(MASS_BUILD_TESTS "Build unit tests" ON)

if(MSVC)
    add_compile_options(/W4 /permissive- /EHsc)
    add_compile_definitions(_WIN32_WINNT=0x0A00 WIN32_LEAN_AND_MEAN NOMINMAX)
else()
    add_compile_options(-Wall -Wextra -Wpedantic)
endif()

# ---------------------------------------------------------------------------
# Dependencies: OpenSSL 3.x, SQLite3, Threads
# ---------------------------------------------------------------------------
find_package(OpenSSL 3.0 REQUIRED)
find_package(Threads REQUIRED)
find_package(SQLite3 REQUIRED)

if(TARGET SQLite3::SQLite3)
    set(MASS_SQLITE_TARGET SQLite3::SQLite3)
else()
    set(MASS_SQLITE_TARGET SQLite::SQLite3)
endif()

find_package(nlohmann_json 3.11 QUIET)
if(NOT nlohmann_json_FOUND)
    include(FetchContent)
    FetchContent_Declare(
        nlohmann_json
        URL https://github.com/nlohmann/json/releases/download/v3.11.3/json.tar.xz
        DOWNLOAD_EXTRACT_TIMESTAMP TRUE
    )
    FetchContent_MakeAvailable(nlohmann_json)
endif()

find_package(httplib QUIET)
if(NOT httplib_FOUND)
    include(FetchContent)
    set(HTTPLIB_REQUIRE_OPENSSL ON CACHE BOOL "" FORCE)
    FetchContent_Declare(
        httplib
        GIT_REPOSITORY https://github.com/yhirose/cpp-httplib.git
        GIT_TAG v0.18.1
    )
    FetchContent_MakeAvailable(httplib)
endif()

# ---------------------------------------------------------------------------
# Core Library: mass_core
# ---------------------------------------------------------------------------
add_library(mass_core STATIC
    src/common/crypto.cpp
    src/common/machine_id.cpp
    src/common/license.cpp
    src/common/auth.cpp
)

target_include_directories(mass_core
    PUBLIC
        ${CMAKE_CURRENT_SOURCE_DIR}/include
)

target_link_libraries(mass_core
    PUBLIC
        OpenSSL::SSL
        OpenSSL::Crypto
        nlohmann_json::nlohmann_json
        Threads::Threads
)

# ---------------------------------------------------------------------------
# Storage Library: mass_storage
# ---------------------------------------------------------------------------
add_library(mass_storage STATIC
    src/common/db.cpp
)

target_include_directories(mass_storage
    PUBLIC
        ${CMAKE_CURRENT_SOURCE_DIR}/include
)

target_link_libraries(mass_storage
    PUBLIC
        mass_core
        ${MASS_SQLITE_TARGET}
)

# ---------------------------------------------------------------------------
# Executable 1: mass_master (v2.9 Ripple)
# ---------------------------------------------------------------------------
add_executable(mass_master
    src/master/main.cpp
    src/master/master_server.cpp
    src/master/ssa_client.cpp
    src/master/file_transfer.cpp
    src/master/discovery.cpp
)

target_link_libraries(mass_master
    PRIVATE
        mass_core
        mass_storage
        httplib::httplib
)

if(WIN32)
    target_link_libraries(mass_master PRIVATE ws2_32 crypt32)
endif()

# ---------------------------------------------------------------------------
# Executable 2: mass_node (v2.9 Ripple)
# ---------------------------------------------------------------------------
add_executable(mass_node
    src/node/main.cpp
    src/node/telemetry.cpp
    src/node/shell_session.cpp
    src/node/remote_desktop.cpp
    src/node/node_agent.cpp
)

target_link_libraries(mass_node
    PRIVATE
        mass_core
        httplib::httplib
)

if(WIN32)
    target_link_libraries(mass_node PRIVATE ws2_32 crypt32)
endif()

# ---------------------------------------------------------------------------
# Executable 3: mass-cli
# ---------------------------------------------------------------------------
add_executable(mass_cli
    src/cli/main.cpp
)

set_target_properties(mass_cli PROPERTIES OUTPUT_NAME "mass-cli")

target_link_libraries(mass_cli
    PRIVATE
        mass_core
        mass_storage
)

# ---------------------------------------------------------------------------
# Executable 4: mass_keygen
# ---------------------------------------------------------------------------
add_executable(mass_keygen
    src/cli/keygen_main.cpp
)

target_link_libraries(mass_keygen
    PRIVATE
        mass_core
)

# ---------------------------------------------------------------------------
# Unit Tests (GoogleTest + CTest)
# ---------------------------------------------------------------------------
if(MASS_BUILD_TESTS)
    enable_testing()
    find_package(GTest QUIET)
    if(NOT GTest_FOUND)
        include(FetchContent)
        FetchContent_Declare(
            googletest
            URL https://github.com/google/googletest/archive/refs/tags/v1.14.0.zip
            DOWNLOAD_EXTRACT_TIMESTAMP TRUE
        )
        set(gtest_force_shared_crt ON CACHE BOOL "" FORCE)
        FetchContent_MakeAvailable(googletest)
    endif()

    add_executable(mass_tests
        tests/test_license.cpp
        tests/test_replay_auth.cpp
        tests/test_device_lock.cpp
        tests/test_v2_features.cpp
        src/node/shell_session.cpp
        src/node/remote_desktop.cpp
        src/master/ssa_client.cpp
    )

    target_link_libraries(mass_tests
        PRIVATE
            mass_core
            mass_storage
            httplib::httplib
            GTest::gtest_main
    )

    include(GoogleTest)
    gtest_discover_tests(mass_tests)
endif()
