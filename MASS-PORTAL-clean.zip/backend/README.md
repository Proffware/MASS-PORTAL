# MASS Backend v2 (C++20 / CMake)

Zero-cloud, yüksek güvenlikli, Modern C++20 / CMake tabanlı dağıtık sunucu izleme, kalıcı uzaktan kabuk (interaktif `sudo`), uzak masaüstü ve zaman aşımına uğramayan yerel AI (**SI — System Intelligence**) orkestrasyon arka ucu.

## Mimari ve Portlar

| Port | Bileşen | Protokol / Amaç |
| :--- | :--- | :--- |
| **6277** | `mass_master` | Android Portal HTTPS (**TLS 1.3**, tek cihaz ECDSA P-256 + 30 sn tek kullanımlık `nonce`) + opt-in UDP LAN keşfi |
| **8444** | `mass_master` | Node Coordinator (**TLS 1.3 mTLS**) |
| **8445** | `mass_node` | Yerel mTLS kontrol sunucusu (Shell, Desktop Frame/Input, SHA-256 File Transfer) |
| **11434** | Ollama / SI | Yerel LLM çalışma zamanı (`/api/tags`, `/api/ps`, `/api/generate`, timeout `>= 600s`) |

## Temel Özellikler (v2)

1. **Canlı Donanım ve SI (Ollama) Telemetrisi (5 sn Pulse):**
   - `/proc/stat` delta CPU (%), `/sys/class/hwmon` & `/sys/class/thermal` CPU sıcaklığı, `/proc/meminfo` (`MemAvailable`) RAM, Disk, Uptime, `/etc/os-release` ve `nvidia-smi` / DRM sysfs GPU metrikleri.
   - `127.0.0.1:11434/api/ps` ve `/api/tags` üzerinden yüklü model, VRAM kullanımı ve `active`/`idle`/`offline` durumu.
   - `mass_master` tarafında IP + hostname bazlı **UPSERT deduplication** ve `mass_node` tarafında **exponential backoff** otomatik yeniden bağlanma.
2. **Kalıcı Uzaktan Kabuk ve İnteraktif `sudo` (`POST /v1/console/exec`):**
   - Düğüm oturumu başına kalıcı çalışma dizini (`cd`), tam `bash -c` (pipe/zincir komutlar).
   - `sudo` parolası eksikse `{ "requires_password": true, "prompt": "[sudo] password:" }` döner; parola verildiğinde `sudo -S -p ''` üzerinden `stdin` ile aktarılır ve hiçbir log/SQLite kaydına yazılmaz.
3. **Uzak Masaüstü ve Dokunmatik Giriş (`GET /v1/desktop/frame`, `POST /v1/desktop/input`):**
   - X11/Wayland (`grim` / `scrot` / `ffmpeg`) JPEG yakalama ve normalize `[0.0..1.0]` koordinatların `xdotool` / `ydotool` / `wtype` ile ekran çözünürlüğüne eşlenmesi.
4. **Overthinker-Safe SI / SSA (`GET /v1/ssa/models`, `POST /v1/ssa/query`):**
   - `>= 600s` (varsayılan `900s`) okuma zaman aşımı ve Ollama'nın `thinking` alanını `<think>...</think>` blokları içinde koruma.
5. **Opt-In LAN Keşfi ve Systemd ETS Betikleri:**
   - `scripts/mass_server.sh [--enable-discovery] [--install-service]`
   - `scripts/mass_node.sh [--master-host <IP>] [--install-service]`

## Hızlı Kurulum (Linux)

```bash
sudo apt update
sudo apt install -y build-essential cmake libssl-dev libsqlite3-dev nlohmann-json3-dev scrot xdotool

chmod +x scripts/mass_server.sh scripts/mass_node.sh
./scripts/mass_server.sh --enable-discovery --install-service
./scripts/mass_node.sh --master-host 127.0.0.1 --install-service
```

## Manuel Derleme ve CTest

```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build -j
ctest --test-dir build --output-on-failure
```

## Tek Cihaz Kilidi Yönetimi (`mass-cli`)

```bash
./build/mass-cli --db mass_state.db device pair-code
./build/mass-cli --db mass_state.db status
./build/mass-cli --db mass_state.db device revoke
```
