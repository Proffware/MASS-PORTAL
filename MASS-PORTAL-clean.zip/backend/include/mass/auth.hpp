#pragma once

#include <chrono>
#include <mutex>
#include <optional>
#include <string>
#include <unordered_map>

namespace mass::auth {

// Thread-safe single-use cryptographic nonce store with 30s TTL.
// Every verified/consumed nonce is immediately erased to prevent replay attacks.
class NonceStore {
public:
    explicit NonceStore(std::chrono::seconds ttl = std::chrono::seconds{30});

    // Issues a new 32-byte hex nonce valid for `ttl`.
    std::string issue();

    // Checks if `nonce` exists and is not expired, and IMMEDIATELY deletes it.
    // Returns true if valid and consumed; false if missing, expired, or already used.
    bool consume(const std::string& nonce);

    // Purges expired entries.
    void cleanup();

    std::size_t active_count() const;

private:
    struct Entry {
        std::chrono::steady_clock::time_point expires_at;
    };

    std::chrono::seconds ttl_;
    mutable std::mutex mutex_;
    std::unordered_map<std::string, Entry> nonces_;
};

// Thread-safe single-use 6-digit pairing code store with 60s TTL.
class PairCodeStore {
public:
    explicit PairCodeStore(std::chrono::seconds ttl = std::chrono::seconds{60});

    std::string issue();
    bool consume(const std::string& code);
    void cleanup();

private:
    struct Entry {
        std::chrono::steady_clock::time_point expires_at;
    };

    std::chrono::seconds ttl_;
    mutable std::mutex mutex_;
    std::unordered_map<std::string, Entry> codes_;
};

struct AuthVerifyResult {
    bool ok = false;
    int http_status = 401;
    std::string error;
};

// Verifies X-MASS-Nonce and X-MASS-Signature (Base64-encoded ECDSA P-256 DER signature)
// over canonical string: METHOD + "\n" + PATH + "\n" + NONCE + "\n" + SHA256(BODY).
// Consumes the nonce immediately on lookup to guarantee strict replay protection.
AuthVerifyResult verify_request_signature(
    NonceStore& nonce_store,
    const std::optional<std::string>& paired_public_key_pem,
    const std::string& method,
    const std::string& path,
    const std::string& body,
    const std::string& header_nonce,
    const std::string& header_signature_b64);

} // namespace mass::auth
