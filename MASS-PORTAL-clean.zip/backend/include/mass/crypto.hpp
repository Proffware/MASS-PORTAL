#pragma once

#include <cstdint>
#include <filesystem>
#include <optional>
#include <span>
#include <string>
#include <utility>
#include <vector>

namespace mass::crypto {

struct KeyPairPem {
    std::string private_pem;
    std::string public_pem;
};

// SHA-256 hashing
std::string sha256_hex(std::span<const uint8_t> data);
std::string sha256_hex(const std::string& text);
std::optional<std::string> sha256_file_hex(const std::filesystem::path& path);

// Cryptographically secure random generators (OpenSSL RAND_bytes)
std::string generate_nonce_hex(std::size_t num_bytes = 32);
std::string generate_pair_code_6digit();

// Base64 helpers
std::string base64_encode(std::span<const uint8_t> data);
std::optional<std::vector<uint8_t>> base64_decode(const std::string& encoded);

// Hex helpers
std::string bytes_to_hex(std::span<const uint8_t> data);
std::optional<std::vector<uint8_t>> hex_to_bytes(const std::string& hex);

// Ed25519 (License signing & verification)
std::optional<KeyPairPem> generate_ed25519_keypair();
std::optional<std::vector<uint8_t>> sign_ed25519(
    const std::string& private_key_pem,
    std::span<const uint8_t> message);
bool verify_ed25519(
    const std::string& public_key_pem,
    std::span<const uint8_t> message,
    std::span<const uint8_t> signature);

// ECDSA P-256 (Android Keystore TEE device authentication)
std::optional<KeyPairPem> generate_ecdsa_p256_keypair();
std::optional<std::vector<uint8_t>> sign_ecdsa_p256(
    const std::string& private_key_pem,
    std::span<const uint8_t> message);
bool verify_ecdsa_p256(
    const std::string& public_key_pem,
    std::span<const uint8_t> message,
    std::span<const uint8_t> signature_der);
bool is_valid_ecdsa_p256_public_key_pem(const std::string& public_key_pem);

} // namespace mass::crypto
