#pragma once

#include <cstdint>
#include <filesystem>
#include <memory>
#include <mutex>
#include <optional>
#include <string>
#include <vector>

struct sqlite3;

namespace mass::storage {

struct SqliteDeleter {
    void operator()(sqlite3* db) const noexcept;
};

using SqlitePtr = std::unique_ptr<sqlite3, SqliteDeleter>;

struct PairedDevice {
    int id = 1;
    std::string device_public_key_pem;
    std::string paired_at;
};

struct NodeRecord {
    std::string node_id;
    std::string hostname;
    std::string ip;
    std::string role;
    std::string status;
    std::string public_key;
    std::string last_seen;
};

struct AuditLogEntry {
    int64_t id = 0;
    std::string actor;
    std::string action;
    std::string target_node;
    std::string status;
    std::string created_at;
};

enum class PairResult {
    Success,
    AlreadyPaired, // 409 Conflict
    InvalidKey,    // 400 Bad Request
    DbError        // 500 Internal Server Error
};

enum class NodeRegisterResult {
    Registered,
    Updated,
    LicenseQuotaExceeded, // active_nodes >= max_nodes
    DbError
};

class Database {
public:
    explicit Database(const std::filesystem::path& db_path);
    ~Database() = default;

    Database(const Database&) = delete;
    Database& operator=(const Database&) = delete;
    Database(Database&&) noexcept = default;
    Database& operator=(Database&&) noexcept = default;

    bool init_schema();

    // paired_device (max 1 active record)
    std::optional<PairedDevice> get_paired_device();
    PairResult pair_device_exclusive(const std::string& device_public_key_pem);
    bool revoke_paired_device();

    // pair_codes (shared via SQLite so mass-cli and mass_master stay synchronized)
    bool store_pair_code(const std::string& code, int ttl_seconds = 60);
    bool consume_pair_code(const std::string& code);

    // nodes
    NodeRegisterResult register_or_update_node(const NodeRecord& node, int max_nodes);
    std::vector<NodeRecord> list_nodes();
    std::optional<NodeRecord> get_node(const std::string& node_id);
    int count_active_nodes();

    // audit_logs
    bool append_audit_log(
        const std::string& actor,
        const std::string& action,
        const std::string& target_node,
        const std::string& status);
    std::vector<AuditLogEntry> list_recent_audit_logs(int limit = 50);

private:
    SqlitePtr db_;
    mutable std::mutex mutex_;
};

} // namespace mass::storage
