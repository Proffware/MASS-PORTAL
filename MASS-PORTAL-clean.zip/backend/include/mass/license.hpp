#pragma once

#include <filesystem>
#include <optional>
#include <string>
#include <vector>

namespace mass::licensing {

struct LicenseFeatures {
    bool telemetry     = false;
    bool console       = false;
    bool file_transfer = false;
    bool ssa           = false;
};

struct LicensePayload {
    std::string master_machine_id;
    int max_nodes = 0;
    LicenseFeatures features;
    std::string expires_at; // ISO-8601 UTC, e.g. "2027-12-31T23:59:59Z"
};

struct LicenseValidationResult {
    bool valid = false;
    std::string error;
    std::optional<LicensePayload> payload;
};

// Embedded Ed25519 public key (PEM). In production, replace with your vendor signing public key.
inline constexpr const char* kEmbeddedVendorPublicKeyPem =
    "-----BEGIN PUBLIC KEY-----\n"
    "MCowBQYDK2VwAyEAu7Y7lF4n7y4Q6rJ4iQ5vS0q9pX1Z2V0cW3y8f9K6mNo=\n"
    "-----END PUBLIC KEY-----\n";

// Canonical JSON serialization for deterministic Ed25519 signing & verification.
std::string canonicalize_license_payload(const LicensePayload& payload);

// Validates a signed license.mass JSON string against the given public key,
// expected master_machine_id, and current UTC time.
LicenseValidationResult verify_license_json(
    const std::string& license_json_str,
    const std::string& expected_machine_id,
    const std::string& public_key_pem = kEmbeddedVendorPublicKeyPem);

// Loads and validates license.mass from disk.
LicenseValidationResult load_and_verify_license(
    const std::filesystem::path& license_path,
    const std::string& expected_machine_id,
    const std::string& public_key_pem = kEmbeddedVendorPublicKeyPem);

// Signs a LicensePayload with an Ed25519 private key PEM and returns the complete license.mass JSON.
std::optional<std::string> create_signed_license_json(
    const LicensePayload& payload,
    const std::string& private_key_pem);

} // namespace mass::licensing
