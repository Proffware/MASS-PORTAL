#pragma once

#include <string>

namespace mass::hw {

// Generates a deterministic SHA-256 hardware-bound machine identifier.
// Linux: reads /etc/machine-id and /sys/class/dmi/id/product_uuid (with hostname fallback).
// Windows: reads HKLM\SOFTWARE\Microsoft\Cryptography\MachineGuid (with volume serial fallback).
std::string get_master_machine_id();

} // namespace mass::hw
