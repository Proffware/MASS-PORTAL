#pragma once

#include "mass/auth.hpp"
#include "mass/db.hpp"
#include "mass/license.hpp"

#include <atomic>
#include <cstdint>
#include <mutex>
#include <nlohmann/json.hpp>
#include <string>
#include <unordered_map>

namespace mass::master {

struct MasterConfig {
    std::string bind_host = "0.0.0.0";
    int portal_port = 6277;       // Android Portal HTTPS (TLS 1.3)
    int node_mtls_port = 8444;    // Node Daemon mTLS (TLS 1.3)
    bool enable_discovery = false; // Opt-in UDP LAN discovery on portal_port
    std::string db_path = "mass_state.db";
    std::string license_path = "license.mass";
    std::string vendor_pubkey_path;
    std::string server_cert_path = "certs/master.crt";
    std::string server_key_path = "certs/master.key";
    std::string ca_cert_path = "certs/ca.crt";
};

struct GpuInfo {
    std::string name;
    std::string kind = "dedicated"; // "dedicated" | "integrated"
    double util_percent = 0.0;
    double temp_c = 0.0;
    double vram_used_gb = 0.0;
    double vram_total_gb = 0.0;
};

struct DiskInfo {
    std::string device;
    std::string mount;
    double used_gb = 0.0;
    double total_gb = 0.0;
    double percent = 0.0;
};

struct PortStatusInfo {
    std::string name;
    std::string detail;
    bool active = false;
};

struct SiModelStatus {
    bool ollama_online = false;
    std::string state = "idle"; // "active" | "idle" | "offline"
    std::string loaded_model;
    double vram_used_gb = 0.0;
    int available_models_count = 0;
    double inference_gpu_percent = 0.0;
    double inference_gpu_temp_c = 0.0;
};

struct NodeTelemetrySnapshot {
    std::string node_id;
    std::string hostname;
    std::string ip;
    std::string role = "server";
    double cpu_percent = 0.0;
    double cpu_temp_c = 0.0;
    double gpu_percent = 0.0;
    double gpu_temp_c = 0.0;
    double gpu_vram_used_gb = 0.0;
    double gpu_vram_total_gb = 0.0;
    std::string gpu_name = "N/A";
    double ram_used_gb = 0.0;
    double ram_total_gb = 0.0;
    double disk_used_gb = 0.0;
    double disk_total_gb = 0.0;
    uint64_t uptime = 0;
    std::string os_info;
    std::string last_sync;
    SiModelStatus si_info;
    std::vector<GpuInfo> gpus;
    std::vector<DiskInfo> disks;
    std::vector<PortStatusInfo> network_ports;
};

struct FileTransferRequest {
    std::string source_node_id;
    std::string target_node_id;
    std::string source_path;
    std::string target_path;
    std::string expected_sha256;
};

struct FileTransferResult {
    bool ok = false;
    std::string transfer_id;
    std::string sha256;
    uint64_t bytes_transferred = 0;
    std::string error;
};

FileTransferResult execute_node_file_transfer(
    const FileTransferRequest& req,
    const std::unordered_map<std::string, std::string>& node_endpoints,
    const std::string& ca_cert_path,
    const std::string& client_cert_path,
    const std::string& client_key_path);

// Opt-in UDP LAN discovery responder (responds ONLY when user explicitly enables discovery).
// Replies with { "service": "mass_master", "port": 6277, "hostname": "...", "requires_pairing": true }
void run_opt_in_lan_discovery(int udp_port, int portal_port, std::atomic<bool>& running);

class MasterServer {
public:
    MasterServer(
        MasterConfig config,
        storage::Database& db,
        licensing::LicensePayload license,
        std::string machine_id);

    int run();

private:
    MasterConfig config_;
    storage::Database& db_;
    licensing::LicensePayload license_;
    std::string machine_id_;
    auth::NonceStore nonce_store_;

    std::mutex telemetry_mutex_;
    std::unordered_map<std::string, NodeTelemetrySnapshot> live_telemetry_;
    std::unordered_map<std::string, std::string> node_control_urls_;
};

} // namespace mass::master
