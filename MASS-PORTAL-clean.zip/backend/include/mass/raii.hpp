#pragma once

#include <memory>
#include <openssl/bio.h>
#include <openssl/evp.h>
#include <openssl/ssl.h>
#include <openssl/x509.h>

namespace mass::raii {

struct EvpPkeyDeleter {
    void operator()(EVP_PKEY* p) const noexcept {
        if (p) EVP_PKEY_free(p);
    }
};

struct EvpPkeyCtxDeleter {
    void operator()(EVP_PKEY_CTX* p) const noexcept {
        if (p) EVP_PKEY_CTX_free(p);
    }
};

struct EvpMdCtxDeleter {
    void operator()(EVP_MD_CTX* p) const noexcept {
        if (p) EVP_MD_CTX_free(p);
    }
};

struct BioDeleter {
    void operator()(BIO* p) const noexcept {
        if (p) BIO_free_all(p);
    }
};

struct SslCtxDeleter {
    void operator()(SSL_CTX* p) const noexcept {
        if (p) SSL_CTX_free(p);
    }
};

struct X509Deleter {
    void operator()(X509* p) const noexcept {
        if (p) X509_free(p);
    }
};

using EvpPkeyPtr    = std::unique_ptr<EVP_PKEY, EvpPkeyDeleter>;
using EvpPkeyCtxPtr = std::unique_ptr<EVP_PKEY_CTX, EvpPkeyCtxDeleter>;
using EvpMdCtxPtr   = std::unique_ptr<EVP_MD_CTX, EvpMdCtxDeleter>;
using BioPtr        = std::unique_ptr<BIO, BioDeleter>;
using SslCtxPtr     = std::unique_ptr<SSL_CTX, SslCtxDeleter>;
using X509Ptr       = std::unique_ptr<X509, X509Deleter>;

} // namespace mass::raii
