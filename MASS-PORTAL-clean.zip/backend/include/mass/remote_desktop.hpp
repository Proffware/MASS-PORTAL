#pragma once

#include <atomic>
#include <cstdint>
#include <functional>
#include <optional>
#include <string>
#include <utility>
#include <vector>

namespace mass::node {

struct DesktopFrame {
    bool ok = false;
    int width = 0;
    int height = 0;
    std::vector<uint8_t> jpeg_bytes;
    std::string error;
};

struct DesktopInputEvent {
    std::string type; // move, click, double_click, right_click, drag_start, drag_move, drag_end, scroll, key, text
    double x_norm = 0.0;
    double y_norm = 0.0;
    int button = 1;
    int delta_y = 0;
    std::string key;
    std::string text;
};

struct DesktopInputResult {
    bool ok = false;
    int mapped_x = 0;
    int mapped_y = 0;
    std::string backend; // "xdotool" | "ydotool" | "wtype"
    std::string error;
};

// Detects active screen resolution on X11 or Wayland.
std::pair<int, int> detect_screen_resolution();

// Maps normalized coordinates [0.0..1.0] to pixel coordinates safely clamped.
std::pair<int, int> map_normalized_coords(double x_norm, double y_norm, int screen_w, int screen_h);

// Captures a single JPEG frame from active X11/Wayland screen (quality 10..100).
DesktopFrame capture_desktop_jpeg(int quality = 65);

// Streams live 30 FPS MJPEG directly from ffmpeg pipe:1 (zero disk I/O).
// Invokes `on_frame(jpeg_bytes)` for each complete JPEG frame; stops when `on_frame` returns false.
void stream_desktop_h264(
    int fps,
    int bitrate_kbps,
    int max_width,
    const std::function<bool(const uint8_t*, std::size_t)>& on_chunk);

void stream_desktop_mjpeg(
    int fps,
    int quality,
    int max_width,
    const std::function<bool(const std::vector<uint8_t>&)>& on_frame);

// Pure helper exposed for unit testing: extracts complete JPEG frames (SOI 0xFFD8 .. EOI 0xFFD9)
// from a streaming byte buffer and erases consumed bytes.
std::vector<std::vector<uint8_t>> extract_jpeg_frames_from_buffer(std::vector<uint8_t>& buffer);

// Injects mouse/touch/keyboard input via xdotool (X11) or ydotool/wtype (Wayland).
DesktopInputResult inject_desktop_input(const DesktopInputEvent& ev);

} // namespace mass::node
