#pragma once

#include <mutex>
#include <optional>
#include <string>

namespace mass::node {

struct ShellExecResult {
    bool ok = false;
    bool requires_password = false;
    std::string prompt;
    int exit_code = 0;
    std::string cwd;
    std::string output;
    std::string error;
};

// Persistent per-node bash session that preserves working directory (`cd`),
// supports full bash pipelines/chains, and handles interactive `sudo` safely
// via `sudo -S -p ''` without persisting passwords to logs or disk.
class ShellSession {
public:
    explicit ShellSession(std::string initial_cwd = "");

    ShellExecResult execute(
        const std::string& command,
        const std::optional<std::string>& sudo_password = std::nullopt);

    std::string current_working_directory() const;

    // Pure helper exposed for unit tests: detects whether a command invokes sudo
    static bool command_uses_sudo(const std::string& command);

private:
    mutable std::mutex mutex_;
    std::string cwd_;
};

} // namespace mass::node
