#pragma once

#include <optional>
#include <string>
#include <vector>

namespace mass::ssa {

struct LocalModelInfo {
    std::string id;
    std::string name;
    std::string runtime; // "Ollama" | "llama.cpp" | "vLLM"
    std::string quant;
    int context_window = 0;
    bool running = false;
    double vram_gb = 0.0;
    std::string status = "available"; // "running" | "available"
    std::string endpoint_url;
};

struct SsaQueryResponse {
    bool ok = false;
    std::string model_id;
    std::string runtime;
    std::string answer; // Preserves <think>...</think> reasoning blocks
    std::string error;
};

// Scans local Ollama (/api/tags + /api/ps) and optional local runtimes.
std::vector<LocalModelInfo> discover_local_models();

// Overthinker-safe local LLM query (read timeout >= 600s) against 127.0.0.1:11434/api/generate.
// Wraps Ollama's separate `thinking` field in <think>...</think> when present.
SsaQueryResponse query_local_model(
    const std::string& model_id,
    const std::string& telemetry_context_json,
    const std::string& user_query,
    int timeout_seconds = 900);

// Helper exposed for unit testing: merges Ollama `thinking` and `response` fields
// while preserving any existing <think>...</think> blocks.
std::string format_overthinker_response(
    const std::string& thinking_field,
    const std::string& response_field);

} // namespace mass::ssa
