#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BUILD_DIR="${ROOT_DIR}/build"
CERTS_DIR="${ROOT_DIR}/certs"

NODE_ID="$(hostname 2>/dev/null || echo 'mass-node-01')"
ROLE="server"
MASTER_HOST="127.0.0.1"
MASTER_PORT=8444
NODE_PORT=8445
ADVERTISED_IP="$(hostname -I 2>/dev/null | awk '{print $1}' || echo '127.0.0.1')"
INSTALL_SERVICE=0

while [[ $# -gt 0 ]]; do
    case "$1" in
        --node-id) NODE_ID="$2"; shift 2 ;;
        --role) ROLE="$2"; shift 2 ;;
        --master-host) MASTER_HOST="$2"; shift 2 ;;
        --master-port) MASTER_PORT="$2"; shift 2 ;;
        --port) NODE_PORT="$2"; shift 2 ;;
        --ip) ADVERTISED_IP="$2"; shift 2 ;;
        --install-service) INSTALL_SERVICE=1; shift ;;
        --help|-h)
            echo "Usage: $0 [--node-id ID] [--master-host IP] [--master-port 8444] [--port 8445] [--install-service]"
            exit 0
            ;;
        *) shift ;;
    esac
done

echo "[MASS Node ETS] Building mass_node..."
cmake -S "${ROOT_DIR}" -B "${BUILD_DIR}" -DCMAKE_BUILD_TYPE=Release
cmake --build "${BUILD_DIR}" --target mass_node -j"$(nproc 2>/dev/null || echo 4)"

if [[ "${INSTALL_SERVICE}" -eq 1 ]]; then
    SERVICE_FILE="/etc/systemd/system/mass-node.service"
    echo "[MASS Node ETS] Installing systemd service at ${SERVICE_FILE}..."
    sudo tee "${SERVICE_FILE}" >/dev/null <<EOF
[Unit]
Description=MASS Backend v2 Node Agent (${NODE_ID})
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
WorkingDirectory=${ROOT_DIR}
Environment=DISPLAY=:0
ExecStart=${BUILD_DIR}/mass_node --node-id ${NODE_ID} --role ${ROLE} --master-host ${MASTER_HOST} --master-port ${MASTER_PORT} --port ${NODE_PORT} --ip ${ADVERTISED_IP} --cert ${CERTS_DIR}/node.crt --key ${CERTS_DIR}/node.key --ca ${CERTS_DIR}/ca.crt
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
EOF
    sudo systemctl daemon-reload
    sudo systemctl enable --now mass-node.service
    echo "[MASS Node ETS] mass-node.service enabled and started."
    exit 0
fi

exec "${BUILD_DIR}/mass_node" \
    --node-id "${NODE_ID}" \
    --role "${ROLE}" \
    --master-host "${MASTER_HOST}" \
    --master-port "${MASTER_PORT}" \
    --port "${NODE_PORT}" \
    --ip "${ADVERTISED_IP}" \
    --cert "${CERTS_DIR}/node.crt" \
    --key "${CERTS_DIR}/node.key" \
    --ca "${CERTS_DIR}/ca.crt"
