#!/usr/bin/env bash
# ============================================================================
# MASS Backend v2.5 — All-In-One Zero-Setup (LAN + 4G/5G Auto-Tunnel + 30/60 FPS)
# End user runs ONE command — no extra apps, no router port-forwarding, no accounts!
# ============================================================================
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if [[ ! -f "${ROOT_DIR}/CMakeLists.txt" && -f "${ROOT_DIR}/../CMakeLists.txt" ]]; then
    ROOT_DIR="$(cd "${ROOT_DIR}/.." && pwd)"
fi

BUILD_DIR="${ROOT_DIR}/build"
BIN_DIR="${ROOT_DIR}/bin"
CERTS_DIR="${ROOT_DIR}/certs"
DB_PATH="${ROOT_DIR}/mass_state.db"
LICENSE_PATH="${ROOT_DIR}/license.mass"
VENDOR_PRIV="${ROOT_DIR}/vendor_priv.pem"
VENDOR_PUB="${ROOT_DIR}/vendor_pub.pem"
TUNNEL_LOG="${ROOT_DIR}/mass_tunnel.log"

PORTAL_PORT=6277
NODE_MTLS_PORT=8444
NODE_CTRL_PORT=8445
MASTER_HOST="127.0.0.1"
ENABLE_DISCOVERY=1
INSTALL_SERVICE=1
ENABLE_4G_TUNNEL=1
NODE_ONLY=0
CUSTOM_NODE_ID=""
CUSTOM_ROLE="server"
SKIP_DEPS=0
REGEN_CERTS=0

RUN_USER="${SUDO_USER:-$USER}"
RUN_HOME="$(eval echo "~${RUN_USER}")"

while [[ $# -gt 0 ]]; do
    case "$1" in
        --enable-discovery) ENABLE_DISCOVERY=1; shift ;;
        --no-discovery)     ENABLE_DISCOVERY=0; shift ;;
        --install-service)  INSTALL_SERVICE=1; shift ;;
        --foreground)       INSTALL_SERVICE=0; shift ;;
        --no-4g)            ENABLE_4G_TUNNEL=0; shift ;;
        --node-only)        NODE_ONLY=1; shift ;;
        --master-host)      MASTER_HOST="$2"; shift 2 ;;
        --node-id)          CUSTOM_NODE_ID="$2"; shift 2 ;;
        --role)             CUSTOM_ROLE="$2"; shift 2 ;;
        --skip-deps)        SKIP_DEPS=1; shift ;;
        --regen-certs)      REGEN_CERTS=1; shift ;;
        --help|-h)
            echo "MASS Backend v2.5 All-In-One ETS (Linux)"
            echo "  Default: builds, generates TLS 1.3 SAN certs, starts Master + Node + 4G/5G Auto-Tunnel."
            echo "  --no-4g             Disable automatic 4G/5G public HTTPS tunnel"
            echo "  --foreground        Run mass_master in foreground instead of systemd"
            echo "  --regen-certs       Force regenerate TLS 1.3 / mTLS SAN certs"
            echo "  --skip-deps         Skip apt/dnf/pacman package install"
            exit 0
            ;;
        *) shift ;;
    esac
done

echo "============================================================"
echo " MASS Backend v2.5 — All-In-One (LAN + 4G/5G + 0.2ms Touch)"
echo "============================================================"

# 1. Dependencies
if [[ "${SKIP_DEPS}" -eq 0 ]]; then
    if command -v apt-get >/dev/null 2>&1; then
        echo "[1/7] Checking dependencies via apt..."
        sudo apt-get install -y -qq build-essential cmake pkg-config libssl-dev \
            libsqlite3-dev nlohmann-json3-dev openssl ffmpeg scrot xdotool curl || true
    elif command -v dnf >/dev/null 2>&1; then
        echo "[1/7] Checking dependencies via dnf..."
        sudo dnf install -y gcc-c++ cmake openssl-devel sqlite-devel json-devel \
            openssl ffmpeg scrot xdotool curl || true
    elif command -v pacman >/dev/null 2>&1; then
        echo "[1/7] Checking dependencies via pacman..."
        sudo pacman -Sy --noconfirm --needed base-devel cmake openssl sqlite \
            nlohmann-json ffmpeg scrot xdotool curl || true
    fi
fi

# 2. Build & Unit Tests
if [[ ! -f "${ROOT_DIR}/CMakeLists.txt" ]]; then
    echo "[ERROR] CMakeLists.txt not found in ${ROOT_DIR}."
    exit 1
fi

echo "[2/7] Compiling MASS Backend v2.5..."
cmake -S "${ROOT_DIR}" -B "${BUILD_DIR}" -DCMAKE_BUILD_TYPE=Release
cmake --build "${BUILD_DIR}" -j"$(nproc 2>/dev/null || echo 4)"
ctest --test-dir "${BUILD_DIR}" --output-on-failure

# 3. Collect ALL local IPv4 addresses + Tailscale IP for SAN
ALL_IPS="$(hostname -I 2>/dev/null || echo '127.0.0.1')"
LAN_IP="$(echo "${ALL_IPS}" | awk '{print $1}')"
[[ -z "${LAN_IP}" ]] && LAN_IP="127.0.0.1"
TAILSCALE_IP=""
if command -v tailscale >/dev/null 2>&1; then
    TAILSCALE_IP="$(tailscale ip -4 2>/dev/null | head -n 1 || true)"
fi
HOST_NAME="${CUSTOM_NODE_ID:-$(hostname 2>/dev/null || echo 'mass-host')}"

NEED_CERTS="${REGEN_CERTS}"
if [[ ! -f "${CERTS_DIR}/master.crt" || ! -f "${CERTS_DIR}/ca.crt" || ! -f "${CERTS_DIR}/node.crt" ]]; then
    NEED_CERTS=1
elif ! openssl x509 -in "${CERTS_DIR}/master.crt" -noout -text 2>/dev/null | grep -q "IP Address:${LAN_IP}"; then
    echo "[3/7] Current LAN IP (${LAN_IP}) not in certificate SAN — regenerating..."
    NEED_CERTS=1
fi

if [[ "${NEED_CERTS}" -eq 1 ]]; then
    echo "[3/7] Generating X.509 v3 TLS 1.3 / mTLS certificates..."
    mkdir -p "${CERTS_DIR}"

    SAN_LIST="DNS:localhost,DNS:mass-master,DNS:mass-node,DNS:${HOST_NAME},IP:127.0.0.1"
    for ip in ${ALL_IPS}; do
        if [[ "${ip}" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ && "${ip}" != "127.0.0.1" ]]; then
            SAN_LIST="${SAN_LIST},IP:${ip}"
        fi
    done
    if [[ -n "${TAILSCALE_IP}" && "${SAN_LIST}" != *"IP:${TAILSCALE_IP}"* ]]; then
        SAN_LIST="${SAN_LIST},IP:${TAILSCALE_IP}"
    fi

    cat > "${CERTS_DIR}/ca_ext.cnf" <<EOF
[v3_ca]
basicConstraints = critical,CA:TRUE
keyUsage = critical,keyCertSign,cRLSign
subjectKeyIdentifier = hash
EOF

    cat > "${CERTS_DIR}/leaf_ext.cnf" <<EOF
[v3_leaf]
basicConstraints = critical,CA:FALSE
keyUsage = critical,digitalSignature,keyEncipherment
extendedKeyUsage = serverAuth,clientAuth
subjectAltName = ${SAN_LIST}
EOF

    openssl req -x509 -newkey ec -pkeyopt ec_paramgen_curve:prime256v1 -days 3650 -nodes \
        -keyout "${CERTS_DIR}/ca.key" -out "${CERTS_DIR}/ca.crt" \
        -subj "/CN=MASS-Internal-CA" -config "${CERTS_DIR}/ca_ext.cnf" -extensions v3_ca 2>/dev/null

    openssl req -newkey ec -pkeyopt ec_paramgen_curve:prime256v1 -nodes \
        -keyout "${CERTS_DIR}/master.key" -out "${CERTS_DIR}/master.csr" \
        -subj "/CN=mass-master" 2>/dev/null
    openssl x509 -req -in "${CERTS_DIR}/master.csr" -CA "${CERTS_DIR}/ca.crt" -CAkey "${CERTS_DIR}/ca.key" \
        -CAcreateserial -out "${CERTS_DIR}/master.crt" -days 825 \
        -extfile "${CERTS_DIR}/leaf_ext.cnf" -extensions v3_leaf 2>/dev/null

    openssl req -newkey ec -pkeyopt ec_paramgen_curve:prime256v1 -nodes \
        -keyout "${CERTS_DIR}/node.key" -out "${CERTS_DIR}/node.csr" \
        -subj "/CN=${HOST_NAME}" 2>/dev/null
    openssl x509 -req -in "${CERTS_DIR}/node.csr" -CA "${CERTS_DIR}/ca.crt" -CAkey "${CERTS_DIR}/ca.key" \
        -CAcreateserial -out "${CERTS_DIR}/node.crt" -days 825 \
        -extfile "${CERTS_DIR}/leaf_ext.cnf" -extensions v3_leaf 2>/dev/null

    chmod 600 "${CERTS_DIR}"/*.key
    openssl verify -CAfile "${CERTS_DIR}/ca.crt" "${CERTS_DIR}/master.crt" "${CERTS_DIR}/node.crt"
else
    echo "[3/7] Valid X.509 v3 SAN certificates verified."
fi

# 4. Hardware-Bound License
if [[ "${NODE_ONLY}" -eq 0 ]]; then
    echo "[4/7] Ensuring hardware-bound Ed25519 license.mass..."
    if [[ ! -f "${VENDOR_PRIV}" || ! -f "${VENDOR_PUB}" ]]; then
        "${BUILD_DIR}/mass_keygen" gen-keys "${VENDOR_PRIV}" "${VENDOR_PUB}"
        chmod 600 "${VENDOR_PRIV}"
    fi
    "${BUILD_DIR}/mass_keygen" sign --priv "${VENDOR_PRIV}" --machine-id self \
        --max-nodes 16 --expires 2030-12-31T23:59:59Z --out "${LICENSE_PATH}"
fi

# 5. Stop stale processes, fix permissions, open firewall
echo "[5/7] Stopping stale processes & opening port ${PORTAL_PORT}..."
sudo systemctl stop mass-master mass-node mass-tunnel >/dev/null 2>&1 || true
sudo pkill -9 mass_master >/dev/null 2>&1 || true
sudo pkill -9 mass_node >/dev/null 2>&1 || true
sudo chown -R "${RUN_USER}:${RUN_USER}" "${ROOT_DIR}" >/dev/null 2>&1 || true

if command -v ufw >/dev/null 2>&1 && sudo ufw status 2>/dev/null | grep -q "Status: active"; then
    sudo ufw allow "${PORTAL_PORT}/tcp" >/dev/null 2>&1 || true
    sudo ufw allow "${PORTAL_PORT}/udp" >/dev/null 2>&1 || true
    sudo ufw allow "${NODE_MTLS_PORT}/tcp" >/dev/null 2>&1 || true
fi
sudo iptables -C INPUT -p tcp --dport "${PORTAL_PORT}" -j ACCEPT >/dev/null 2>&1 || \
    sudo iptables -I INPUT -p tcp --dport "${PORTAL_PORT}" -j ACCEPT >/dev/null 2>&1 || true
sudo iptables -C INPUT -p udp --dport "${PORTAL_PORT}" -j ACCEPT >/dev/null 2>&1 || \
    sudo iptables -I INPUT -p udp --dport "${PORTAL_PORT}" -j ACCEPT >/dev/null 2>&1 || true

EXTRA_MASTER_FLAGS=""
if [[ "${ENABLE_DISCOVERY}" -eq 1 ]]; then
    EXTRA_MASTER_FLAGS="--enable-discovery"
fi

# 6. Install & Start Systemd Services
if [[ "${INSTALL_SERVICE}" -eq 1 ]]; then
    echo "[6/7] Installing & starting systemd services as '${RUN_USER}'..."
    if [[ "${NODE_ONLY}" -eq 0 ]]; then
        sudo tee /etc/systemd/system/mass-master.service >/dev/null <<EOF
[Unit]
Description=MASS Backend v2.5 Master Coordinator
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=${RUN_USER}
WorkingDirectory=${ROOT_DIR}
ExecStart=${BUILD_DIR}/mass_master --port ${PORTAL_PORT} --node-port ${NODE_MTLS_PORT} --db ${DB_PATH} --license ${LICENSE_PATH} --pubkey ${VENDOR_PUB} --cert ${CERTS_DIR}/master.crt --key ${CERTS_DIR}/master.key --ca ${CERTS_DIR}/ca.crt ${EXTRA_MASTER_FLAGS}
Restart=always
RestartSec=2
LimitNOFILE=65536

[Install]
WantedBy=multi-user.target
EOF
    fi

    XAUTH_PATH="${XAUTHORITY:-${RUN_HOME}/.Xauthority}"
    DISP_VAL="${DISPLAY:-:0}"
    sudo tee /etc/systemd/system/mass-node.service >/dev/null <<EOF
[Unit]
Description=MASS Backend v2.5 Node Agent (${HOST_NAME})
After=network-online.target mass-master.service
Wants=network-online.target

[Service]
Type=simple
User=${RUN_USER}
WorkingDirectory=${ROOT_DIR}
Environment=DISPLAY=${DISP_VAL}
Environment=XAUTHORITY=${XAUTH_PATH}
ExecStart=${BUILD_DIR}/mass_node --node-id ${HOST_NAME} --role ${CUSTOM_ROLE} --master-host ${MASTER_HOST} --master-port ${NODE_MTLS_PORT} --port ${NODE_CTRL_PORT} --ip 127.0.0.1 --cert ${CERTS_DIR}/node.crt --key ${CERTS_DIR}/node.key --ca ${CERTS_DIR}/ca.crt
Restart=always
RestartSec=2

[Install]
WantedBy=multi-user.target
EOF

    sudo systemctl daemon-reload
    if [[ "${NODE_ONLY}" -eq 0 ]]; then
        sudo systemctl enable --now mass-master.service
    fi
    sudo systemctl enable --now mass-node.service
    sleep 1

    if [[ "${NODE_ONLY}" -eq 0 ]]; then
        CHALLENGE_OUT="$(curl -sk --max-time 5 "https://${LAN_IP}:${PORTAL_PORT}/v1/auth/challenge" || true)"
        if echo "${CHALLENGE_OUT}" | grep -q '"nonce"'; then
            echo "[OK] Live HTTPS/TLS verified at https://${LAN_IP}:${PORTAL_PORT}"
        else
            echo "[ERROR] Master did not respond on https://${LAN_IP}:${PORTAL_PORT}. Logs:"
            sudo journalctl -u mass-master -n 20 --no-pager
            exit 1
        fi
    fi
fi

# 7. Zero-Account Built-In 4G/5G Auto-Tunnel (No phone app, no router setup!)
REMOTE_4G_URL=""
if [[ "${NODE_ONLY}" -eq 0 && "${ENABLE_4G_TUNNEL}" -eq 1 ]]; then
    echo "[7/7] Starting built-in 4G/5G HTTPS tunnel (no extra phone app needed)..."
    mkdir -p "${BIN_DIR}"
    CF_BIN=""
    if command -v cloudflared >/dev/null 2>&1; then
        CF_BIN="$(command -v cloudflared)"
    elif [[ -x "${BIN_DIR}/cloudflared" ]]; then
        CF_BIN="${BIN_DIR}/cloudflared"
    else
        ARCH="$(uname -m)"
        CF_ARCH="amd64"
        [[ "${ARCH}" == "aarch64" || "${ARCH}" == "arm64" ]] && CF_ARCH="arm64"
        curl -fsSL "https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-${CF_ARCH}" \
            -o "${BIN_DIR}/cloudflared" && chmod +x "${BIN_DIR}/cloudflared" && CF_BIN="${BIN_DIR}/cloudflared" || true
    fi

    if [[ -n "${CF_BIN}" ]]; then
        rm -f "${TUNNEL_LOG}"
        sudo tee /etc/systemd/system/mass-tunnel.service >/dev/null <<EOF
[Unit]
Description=MASS Backend v2.5 Built-In 4G/5G HTTPS Tunnel
After=network-online.target mass-master.service
Wants=network-online.target

[Service]
Type=simple
User=${RUN_USER}
WorkingDirectory=${ROOT_DIR}
ExecStart=${CF_BIN} tunnel --url https://127.0.0.1:${PORTAL_PORT} --no-tls-verify --logfile ${TUNNEL_LOG}
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
EOF
        sudo systemctl daemon-reload
        sudo systemctl enable --now mass-tunnel.service
        for _ in $(seq 1 15); do
            REMOTE_4G_URL="$(grep -oE 'https://[a-zA-Z0-9-]+\.trycloudflare\.com' "${TUNNEL_LOG}" 2>/dev/null | head -n 1 || true)"
            [[ -n "${REMOTE_4G_URL}" ]] && break
            sleep 1
        done
    fi
fi

echo "============================================================"
echo " MASS Backend v2.5 READY (LAN + 4G/5G + 0.2ms Touch)"
if [[ "${NODE_ONLY}" -eq 0 ]]; then
echo " Local Wi-Fi URL    : https://${LAN_IP}:${PORTAL_PORT}"
if [[ -n "${REMOTE_4G_URL}" ]]; then
echo " 4G / 5G Remote URL : ${REMOTE_4G_URL}"
elif [[ -n "${TAILSCALE_IP}" ]]; then
echo " 4G / 5G Remote URL : https://${TAILSCALE_IP}:${PORTAL_PORT}"
fi
echo " Node mTLS Listener : https://${LAN_IP}:${NODE_MTLS_PORT}"
fi
echo "============================================================"

if [[ "${NODE_ONLY}" -eq 0 ]]; then
    "${BUILD_DIR}/mass-cli" --db "${DB_PATH}" device pair-code || true
fi

if [[ "${INSTALL_SERVICE}" -eq 0 ]]; then
    exec "${BUILD_DIR}/mass_master" --port "${PORTAL_PORT}" --node-port "${NODE_MTLS_PORT}" \
        --db "${DB_PATH}" --license "${LICENSE_PATH}" --pubkey "${VENDOR_PUB}" \
        --cert "${CERTS_DIR}/master.crt" --key "${CERTS_DIR}/master.key" --ca "${CERTS_DIR}/ca.crt" \
        ${EXTRA_MASTER_FLAGS}
fi
