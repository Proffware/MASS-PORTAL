#!/usr/bin/env bash
# MASS Backend v2.9 "Ripple" — Clean Node Installer (Server Rack / Workstation / NAS / PC)
set -euo pipefail

C_CYAN='\033[1;36m'
C_GREEN='\033[1;32m'
C_RED='\033[1;31m'
C_DIM='\033[0;90m'
C_BOLD='\033[1m'
C_RST='\033[0m'

ok()   { printf "\r\033[K  ${C_GREEN}✔${C_RST} %s\n" "$1"; }
fail() { printf "\r\033[K  ${C_RED}✖${C_RST} %s\n" "$1"; exit 1; }

WAVE_PID=""
start_wave() {
    local msg="$1"
    (
        local frames=("Mass" "mAss" "maSs" "masS" "maSs" "mAss")
        local i=0
        while true; do
            printf "\r\033[K  ${C_CYAN}[%s]${C_RST} %s" "${frames[$i]}" "${msg}"
            i=$(( (i + 1) % ${#frames[@]} ))
            sleep 0.14
        done
    ) &
    WAVE_PID=$!
}

stop_wave() {
    if [[ -n "${WAVE_PID}" ]]; then
        kill "${WAVE_PID}" >/dev/null 2>&1 || true
        wait "${WAVE_PID}" >/dev/null 2>&1 || true
        WAVE_PID=""
        printf "\r\033[K"
    fi
}
trap stop_wave EXIT

clear 2>/dev/null || true
printf "${C_CYAN}"
cat << 'BANNER'
█   █  ███   ████  ████     █ ████   ███  ████  █████  ███  █
██ ██░█ ░░█ █ ░░░░█ ░░░░   █ ░█░░░█ █ ░░█ █░░░█  ░█░░░█ ░░█ █░
█░█ █░█████░ ███░░░███░░░ █ ░ ████░░█░ ░█░████░░  █░░░█████░█░░
█░░░█░█░░░█░░ ░░█   ░░█  █ ░ ░█░░░░ █░░ █░█░░█░ ░ █░░ █░░░█░█░░
█░░ █░█░░░█░████░░████░░█ ░ ░ █░░░░░ ███ ░█░░░█░  █░░ █░░░█░█████
 ░░  ░░░░  ░░░░░░ ░░░░░ ░░ ░   ░░     ░░░ ░░░  ░   ░░  ░░  ░░░░░░░
  ░   ░ ░   ░ ░░░░  ░░░░  ░     ░      ░░░  ░   ░   ░   ░   ░ ░░░░░
BANNER
printf "${C_BOLD}                  v2.9 • Ripple (NODE)${C_RST}\n\n"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="${SCRIPT_DIR}"
if [[ ! -f "${ROOT_DIR}/CMakeLists.txt" && -f "${ROOT_DIR}/mass-backend/CMakeLists.txt" ]]; then
    ROOT_DIR="${ROOT_DIR}/mass-backend"
elif [[ ! -f "${ROOT_DIR}/CMakeLists.txt" && -f "${ROOT_DIR}/../CMakeLists.txt" ]]; then
    ROOT_DIR="$(cd "${ROOT_DIR}/.." && pwd)"
fi

MASTER_IP=""
MASTER_PORT=8444
NODE_PORT=8445
NODE_ID=""
ROLE=""
SKIP_DEPS=0
RUN_USER="${SUDO_USER:-$USER}"
RUN_HOME="$(eval echo "~${RUN_USER}")"

while [[ $# -gt 0 ]]; do
    case "$1" in
        --master-ip)   MASTER_IP="$2"; shift 2 ;;
        --master-port) MASTER_PORT="$2"; shift 2 ;;
        --port)        NODE_PORT="$2"; shift 2 ;;
        --node-id)     NODE_ID="$2"; shift 2 ;;
        --role)        ROLE="$2"; shift 2 ;;
        --skip-deps)   SKIP_DEPS=1; shift ;;
        *) shift ;;
    esac
done

DEFAULT_NAME="$(hostname 2>/dev/null || echo 'mass-node-01')"
if [[ -z "${NODE_ID}" ]]; then
    printf "  ${C_BOLD}Bu cihazı nasıl tanımlamak istersiniz?${C_RST}\n"
    read -r -p "  Cihaz adı [${DEFAULT_NAME}]: " CUSTOM_NAME
    NODE_ID="${CUSTOM_NAME:-$DEFAULT_NAME}"
fi
if [[ -z "${ROLE}" ]]; then
    printf "  Cihaz rolü seçin: ${C_DIM}(1) Server Rack  (2) Workstation  (3) NAS  (4) Kişisel PC  (5) Sunucu${C_RST}\n"
    read -r -p "  Seçim [1]: " ROLE_CHOICE
    case "${ROLE_CHOICE:-1}" in
        2) ROLE="workstation" ;;
        3) ROLE="nas" ;;
        4) ROLE="pc" ;;
        5) ROLE="server" ;;
        *) ROLE="rack" ;;
    esac
fi
if [[ -z "${MASTER_IP}" ]]; then
    read -r -p "  Ana MASS Master IP (örn. 192.168.1.109): " MASTER_IP
fi
echo ""

[[ -n "${MASTER_IP}" ]] || fail "Master IP belirtilmedi."
[[ -f "${ROOT_DIR}/CMakeLists.txt" ]] || fail "CMakeLists.txt bulunamadı."

CERTS_DIR="${ROOT_DIR}/certs"
BUILD_DIR="${ROOT_DIR}/build"
LOG_FILE="${ROOT_DIR}/mass_node_setup.log"
: > "${LOG_FILE}"

[[ -f "${CERTS_DIR}/ca.crt" && -f "${CERTS_DIR}/node.crt" && -f "${CERTS_DIR}/node.key" ]] \
    || fail "certs/ içinde ca.crt, node.crt, node.key eksik (Master'dan kopyalayın)."
ok "mTLS sertifikaları doğrulandı"

sudo -v

if [[ "${SKIP_DEPS}" -eq 0 ]]; then
    start_wave "Sistem bağımlılıkları kontrol ediliyor..."
    if command -v apt-get >/dev/null 2>&1; then
        sudo apt-get install -y -qq build-essential cmake pkg-config libssl-dev \
            libsqlite3-dev nlohmann-json3-dev openssl ffmpeg scrot xdotool >>"${LOG_FILE}" 2>&1 || true
    elif command -v dnf >/dev/null 2>&1; then
        sudo dnf install -y gcc-c++ cmake openssl-devel sqlite-devel json-devel \
            openssl ffmpeg scrot xdotool >>"${LOG_FILE}" 2>&1 || true
    elif command -v pacman >/dev/null 2>&1; then
        sudo pacman -Sy --noconfirm --needed base-devel cmake openssl sqlite \
            nlohmann-json ffmpeg scrot xdotool >>"${LOG_FILE}" 2>&1 || true
    fi
    stop_wave
    ok "Sistem bağımlılıkları hazır"
fi

start_wave "mass_node v2.9 Ripple derleniyor..."
if cmake -S "${ROOT_DIR}" -B "${BUILD_DIR}" -DCMAKE_BUILD_TYPE=Release -DMASS_BUILD_TESTS=OFF >>"${LOG_FILE}" 2>&1 && \
   cmake --build "${BUILD_DIR}" --target mass_node -j"$(nproc 2>/dev/null || echo 4)" >>"${LOG_FILE}" 2>&1; then
    stop_wave
    ok "mass_node v2.9 derlendi"
else
    stop_wave
    printf "  ${C_RED}✖ Derleme hatası:${C_RST}\n"
    tail -n 20 "${LOG_FILE}"
    exit 1
fi

LOCAL_IP="$(hostname -I 2>/dev/null | awk '{print $1}' || echo '127.0.0.1')"
sudo systemctl stop mass-node >/dev/null 2>&1 || true
sudo pkill -9 mass_node >/dev/null 2>&1 || true

sudo iptables -C INPUT -p tcp --dport "${NODE_PORT}" -j ACCEPT >/dev/null 2>&1 || \
    sudo iptables -I INPUT -p tcp --dport "${NODE_PORT}" -j ACCEPT >/dev/null 2>&1 || true
if command -v ufw >/dev/null 2>&1 && sudo ufw status 2>/dev/null | grep -q "Status: active"; then
    sudo ufw allow "${NODE_PORT}/tcp" >/dev/null 2>&1 || true
fi
ok "Güvenlik duvarı (:${NODE_PORT}) ayarlandı"

XAUTH_PATH="${XAUTHORITY:-${RUN_HOME}/.Xauthority}"
DISP_VAL="${DISPLAY:-:0}"

sudo tee /etc/systemd/system/mass-node.service >/dev/null <<EOF
[Unit]
Description=MASS Backend v2.9 Ripple Node (${NODE_ID} - ${ROLE})
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=${RUN_USER}
WorkingDirectory=${ROOT_DIR}
Environment=DISPLAY=${DISP_VAL}
Environment=XAUTHORITY=${XAUTH_PATH}
ExecStart=${BUILD_DIR}/mass_node --node-id ${NODE_ID} --role ${ROLE} --master-host ${MASTER_IP} --master-port ${MASTER_PORT} --port ${NODE_PORT} --ip ${LOCAL_IP} --cert ${CERTS_DIR}/node.crt --key ${CERTS_DIR}/node.key --ca ${CERTS_DIR}/ca.crt
Restart=always
RestartSec=2

[Install]
WantedBy=multi-user.target
EOF

sudo systemctl daemon-reload
sudo systemctl enable --now mass-node.service >/dev/null 2>&1
sleep 1

if [[ "$(sudo systemctl is-active mass-node 2>/dev/null || true)" == "active" ]]; then
    ok "mass-node servisi aktif (${NODE_ID} • ${ROLE})"
else
    fail "mass-node başlatılamadı (sudo journalctl -u mass-node -n 20)."
fi

echo ""
printf "  ${C_BOLD}Düğüm  :${C_RST} %s (%s) • %s:%s\n" "${NODE_ID}" "${ROLE}" "${LOCAL_IP}" "${NODE_PORT}"
printf "  ${C_BOLD}Master :${C_RST} https://%s:%s (mTLS)\n\n" "${MASTER_IP}" "${MASTER_PORT}"
