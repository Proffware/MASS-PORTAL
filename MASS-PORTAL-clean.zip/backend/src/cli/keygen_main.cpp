#include "mass/crypto.hpp"
#include "mass/license.hpp"
#include "mass/machine_id.hpp"

#include <fstream>
#include <iostream>
#include <sstream>
#include <string>

namespace {

void print_usage() {
    std::cout << "MASS Ed25519 License Keygen\n"
              << "Usage:\n"
              << "  mass_keygen gen-keys <priv.pem> <pub.pem>\n"
              << "  mass_keygen sign --priv <priv.pem> --machine-id <id|self> --max-nodes <N> "
              << "--expires <ISO8601Z> [--out license.mass]\n";
}

std::string read_file(const std::string& path) {
    std::ifstream ifs(path);
    if (!ifs.is_open()) return {};
    std::ostringstream ss;
    ss << ifs.rdbuf();
    return ss.str();
}

bool write_file(const std::string& path, const std::string& content) {
    std::ofstream ofs(path, std::ios::trunc);
    if (!ofs.is_open()) return false;
    ofs << content;
    return true;
}

} // namespace

int main(int argc, char* argv[]) {
    if (argc < 2) {
        print_usage();
        return 1;
    }

    const std::string mode = argv[1];
    if (mode == "gen-keys" && argc == 4) {
        const auto kp = mass::crypto::generate_ed25519_keypair();
        if (!kp) {
            std::cerr << "Error: Ed25519 key generation failed.\n";
            return 1;
        }
        if (!write_file(argv[2], kp->private_pem) || !write_file(argv[3], kp->public_pem)) {
            std::cerr << "Error: Failed to write key files.\n";
            return 1;
        }
        std::cout << "Generated Ed25519 keypair:\n  Private: " << argv[2] << "\n  Public : " << argv[3] << "\n";
        return 0;
    }

    if (mode == "sign") {
        std::string priv_path;
        std::string machine_id;
        int max_nodes = 4;
        std::string expires_at = "2028-12-31T23:59:59Z";
        std::string out_path = "license.mass";

        for (int i = 2; i < argc; ++i) {
            const std::string arg = argv[i];
            auto next = [&]() -> std::string {
                return (i + 1 < argc) ? std::string(argv[++i]) : "";
            };
            if (arg == "--priv") priv_path = next();
            else if (arg == "--machine-id") machine_id = next();
            else if (arg == "--max-nodes") max_nodes = std::stoi(next());
            else if (arg == "--expires") expires_at = next();
            else if (arg == "--out") out_path = next();
        }

        if (priv_path.empty() || machine_id.empty()) {
            print_usage();
            return 1;
        }
        if (machine_id == "self") {
            machine_id = mass::hw::get_master_machine_id();
        }

        const std::string priv_pem = read_file(priv_path);
        if (priv_pem.empty()) {
            std::cerr << "Error: Cannot read private key: " << priv_path << "\n";
            return 1;
        }

        mass::licensing::LicensePayload payload;
        payload.master_machine_id = machine_id;
        payload.max_nodes = max_nodes;
        payload.expires_at = expires_at;
        payload.features = {true, true, true, true};

        const auto signed_json = mass::licensing::create_signed_license_json(payload, priv_pem);
        if (!signed_json || !write_file(out_path, *signed_json)) {
            std::cerr << "Error: Failed to sign or write " << out_path << "\n";
            return 1;
        }
        std::cout << "Signed license written to " << out_path << " for machine_id=" << machine_id << "\n";
        return 0;
    }

    print_usage();
    return 1;
}
