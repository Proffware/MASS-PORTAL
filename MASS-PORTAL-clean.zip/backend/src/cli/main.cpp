#include "mass/crypto.hpp"
#include "mass/db.hpp"
#include "mass/machine_id.hpp"

#include <iostream>
#include <string>

namespace {

void print_usage() {
    std::cout << "MASS CLI - Single-Device Lock & State Manager\n"
              << "Usage:\n"
              << "  mass-cli [--db mass_state.db] device pair-code\n"
              << "  mass-cli [--db mass_state.db] device revoke\n"
              << "  mass-cli [--db mass_state.db] status\n";
}

} // namespace

int main(int argc, char* argv[]) {
    std::string db_path = "mass_state.db";
    int arg_idx = 1;

    if (arg_idx + 1 < argc && std::string(argv[arg_idx]) == "--db") {
        db_path = argv[arg_idx + 1];
        arg_idx += 2;
    }

    if (arg_idx >= argc) {
        print_usage();
        return 1;
    }

    const std::string cmd = argv[arg_idx];
    mass::storage::Database db(db_path);
    if (!db.init_schema()) {
        std::cerr << "Error: Unable to open SQLite database at " << db_path << "\n";
        return 1;
    }

    if (cmd == "device" && arg_idx + 1 < argc) {
        const std::string sub = argv[arg_idx + 1];
        if (sub == "pair-code") {
            if (db.get_paired_device().has_value()) {
                std::cerr << "Error: A device is already paired. Run 'mass-cli device revoke' first.\n";
                return 1;
            }
            const std::string code = mass::crypto::generate_pair_code_6digit();
            if (!db.store_pair_code(code, 60)) {
                std::cerr << "Error: Failed to persist pair code.\n";
                return 1;
            }
            std::cout << "MASS Pairing Code (valid 60s, single-use): " << code << "\n";
            return 0;
        }
        if (sub == "revoke") {
            if (!db.revoke_paired_device()) {
                std::cerr << "Error: Failed to revoke paired device.\n";
                return 1;
            }
            db.append_audit_log("mass-cli", "device_revoke", "master", "ok");
            std::cout << "Paired Android device revoked. Portal lock is now open for re-pairing.\n";
            return 0;
        }
    } else if (cmd == "status") {
        const auto dev = db.get_paired_device();
        std::cout << "Master Machine ID : " << mass::hw::get_master_machine_id() << "\n";
        std::cout << "Paired Device     : " << (dev ? ("ACTIVE (" + dev->paired_at + ")") : "NONE") << "\n";
        std::cout << "Active Nodes      : " << db.count_active_nodes() << "\n";
        return 0;
    }

    print_usage();
    return 1;
}
