#include "mass/auth.hpp"
#include "mass/crypto.hpp"

namespace mass::auth {

NonceStore::NonceStore(std::chrono::seconds ttl) : ttl_(ttl) {}

std::string NonceStore::issue() {
    const std::string nonce = crypto::generate_nonce_hex(32);
    if (nonce.empty()) return {};

    std::lock_guard<std::mutex> lock(mutex_);
    const auto now = std::chrono::steady_clock::now();
    // Prune expired entries opportunistically
    for (auto it = nonces_.begin(); it != nonces_.end();) {
        if (it->second.expires_at <= now) {
            it = nonces_.erase(it);
        } else {
            ++it;
        }
    }
    nonces_.emplace(nonce, Entry{now + ttl_});
    return nonce;
}

bool NonceStore::consume(const std::string& nonce) {
    if (nonce.empty()) return false;

    std::lock_guard<std::mutex> lock(mutex_);
    auto it = nonces_.find(nonce);
    if (it == nonces_.end()) {
        return false;
    }

    const auto now = std::chrono::steady_clock::now();
    const bool not_expired = (it->second.expires_at > now);
    // Strict replay protection: erase immediately on lookup regardless of outcome
    nonces_.erase(it);
    return not_expired;
}

void NonceStore::cleanup() {
    std::lock_guard<std::mutex> lock(mutex_);
    const auto now = std::chrono::steady_clock::now();
    for (auto it = nonces_.begin(); it != nonces_.end();) {
        if (it->second.expires_at <= now) {
            it = nonces_.erase(it);
        } else {
            ++it;
        }
    }
}

std::size_t NonceStore::active_count() const {
    std::lock_guard<std::mutex> lock(mutex_);
    return nonces_.size();
}

PairCodeStore::PairCodeStore(std::chrono::seconds ttl) : ttl_(ttl) {}

std::string PairCodeStore::issue() {
    const std::string code = crypto::generate_pair_code_6digit();
    if (code.empty()) return {};

    std::lock_guard<std::mutex> lock(mutex_);
    const auto now = std::chrono::steady_clock::now();
    for (auto it = codes_.begin(); it != codes_.end();) {
        if (it->second.expires_at <= now) {
            it = codes_.erase(it);
        } else {
            ++it;
        }
    }
    codes_.emplace(code, Entry{now + ttl_});
    return code;
}

bool PairCodeStore::consume(const std::string& code) {
    if (code.empty()) return false;

    std::lock_guard<std::mutex> lock(mutex_);
    auto it = codes_.find(code);
    if (it == codes_.end()) return false;

    const auto now = std::chrono::steady_clock::now();
    const bool valid = (it->second.expires_at > now);
    codes_.erase(it);
    return valid;
}

void PairCodeStore::cleanup() {
    std::lock_guard<std::mutex> lock(mutex_);
    const auto now = std::chrono::steady_clock::now();
    for (auto it = codes_.begin(); it != codes_.end();) {
        if (it->second.expires_at <= now) {
            it = codes_.erase(it);
        } else {
            ++it;
        }
    }
}

AuthVerifyResult verify_request_signature(
    NonceStore& nonce_store,
    const std::optional<std::string>& paired_public_key_pem,
    const std::string& method,
    const std::string& path,
    const std::string& body,
    const std::string& header_nonce,
    const std::string& header_signature_b64) {
    if (!paired_public_key_pem.has_value() || paired_public_key_pem->empty()) {
        return {false, 401, "No paired device registered"};
    }
    if (header_nonce.empty() || header_signature_b64.empty()) {
        return {false, 401, "Missing X-MASS-Nonce or X-MASS-Signature header"};
    }

    // Consume nonce immediately (single-use replay protection)
    if (!nonce_store.consume(header_nonce)) {
        return {false, 401, "Invalid, expired, or already used X-MASS-Nonce"};
    }

    auto sig_bytes = crypto::base64_decode(header_signature_b64);
    if (!sig_bytes || sig_bytes->empty()) {
        return {false, 401, "Malformed Base64 X-MASS-Signature"};
    }

    const std::string body_hash = crypto::sha256_hex(body);
    const std::string canonical_msg = method + "\n" + path + "\n" + header_nonce + "\n" + body_hash;
    const std::span<const uint8_t> msg_span(
        reinterpret_cast<const uint8_t*>(canonical_msg.data()), canonical_msg.size());

    if (!crypto::verify_ecdsa_p256(*paired_public_key_pem, msg_span, *sig_bytes)) {
        return {false, 401, "ECDSA P-256 signature verification failed"};
    }

    return {true, 200, ""};
}

} // namespace mass::auth
