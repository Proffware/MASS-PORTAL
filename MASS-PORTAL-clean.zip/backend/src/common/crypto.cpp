#include "mass/crypto.hpp"
#include "mass/raii.hpp"

#include <array>
#include <cstring>
#include <fstream>
#include <iomanip>
#include <openssl/core_names.h>
#include <openssl/evp.h>
#include <openssl/pem.h>
#include <openssl/rand.h>
#include <sstream>

namespace mass::crypto {

namespace {

std::optional<std::string> bio_to_string(BIO* bio) {
    if (!bio) return std::nullopt;
    BUF_MEM* mem = nullptr;
    BIO_get_mem_ptr(bio, &mem);
    if (!mem || !mem->data) return std::nullopt;
    return std::string(mem->data, mem->length);
}

raii::EvpPkeyPtr load_public_key_pem(const std::string& pem) {
    raii::BioPtr bio(BIO_new_mem_buf(pem.data(), static_cast<int>(pem.size())));
    if (!bio) return nullptr;
    return raii::EvpPkeyPtr(PEM_read_bio_PUBKEY(bio.get(), nullptr, nullptr, nullptr));
}

raii::EvpPkeyPtr load_private_key_pem(const std::string& pem) {
    raii::BioPtr bio(BIO_new_mem_buf(pem.data(), static_cast<int>(pem.size())));
    if (!bio) return nullptr;
    return raii::EvpPkeyPtr(PEM_read_bio_PrivateKey(bio.get(), nullptr, nullptr, nullptr));
}

std::optional<KeyPairPem> export_keypair_pem(EVP_PKEY* pkey) {
    if (!pkey) return std::nullopt;
    raii::BioPtr priv_bio(BIO_new(BIO_s_mem()));
    raii::BioPtr pub_bio(BIO_new(BIO_s_mem()));
    if (!priv_bio || !pub_bio) return std::nullopt;

    if (PEM_write_bio_PrivateKey(priv_bio.get(), pkey, nullptr, nullptr, 0, nullptr, nullptr) != 1) {
        return std::nullopt;
    }
    if (PEM_write_bio_PUBKEY(pub_bio.get(), pkey) != 1) {
        return std::nullopt;
    }

    auto priv = bio_to_string(priv_bio.get());
    auto pub  = bio_to_string(pub_bio.get());
    if (!priv || !pub) return std::nullopt;

    return KeyPairPem{*priv, *pub};
}

} // namespace

std::string bytes_to_hex(std::span<const uint8_t> data) {
    std::ostringstream oss;
    oss << std::hex << std::setfill('0');
    for (uint8_t b : data) {
        oss << std::setw(2) << static_cast<unsigned int>(b);
    }
    return oss.str();
}

std::optional<std::vector<uint8_t>> hex_to_bytes(const std::string& hex) {
    if (hex.size() % 2 != 0) return std::nullopt;
    std::vector<uint8_t> out;
    out.reserve(hex.size() / 2);
    for (std::size_t i = 0; i < hex.size(); i += 2) {
        auto parse_nibble = [](char c) -> int {
            if (c >= '0' && c <= '9') return c - '0';
            if (c >= 'a' && c <= 'f') return c - 'a' + 10;
            if (c >= 'A' && c <= 'F') return c - 'A' + 10;
            return -1;
        };
        int hi = parse_nibble(hex[i]);
        int lo = parse_nibble(hex[i + 1]);
        if (hi < 0 || lo < 0) return std::nullopt;
        out.push_back(static_cast<uint8_t>((hi << 4) | lo));
    }
    return out;
}

std::string sha256_hex(std::span<const uint8_t> data) {
    raii::EvpMdCtxPtr ctx(EVP_MD_CTX_new());
    if (!ctx) return {};

    std::array<uint8_t, EVP_MAX_MD_SIZE> digest{};
    unsigned int digest_len = 0;

    if (EVP_DigestInit_ex(ctx.get(), EVP_sha256(), nullptr) != 1 ||
        EVP_DigestUpdate(ctx.get(), data.data(), data.size()) != 1 ||
        EVP_DigestFinal_ex(ctx.get(), digest.data(), &digest_len) != 1) {
        return {};
    }

    return bytes_to_hex(std::span<const uint8_t>(digest.data(), digest_len));
}

std::string sha256_hex(const std::string& text) {
    return sha256_hex(std::span<const uint8_t>(
        reinterpret_cast<const uint8_t*>(text.data()), text.size()));
}

std::optional<std::string> sha256_file_hex(const std::filesystem::path& path) {
    std::ifstream file(path, std::ios::binary);
    if (!file.is_open()) return std::nullopt;

    raii::EvpMdCtxPtr ctx(EVP_MD_CTX_new());
    if (!ctx || EVP_DigestInit_ex(ctx.get(), EVP_sha256(), nullptr) != 1) {
        return std::nullopt;
    }

    std::array<char, 65536> buffer{};
    while (file.good()) {
        file.read(buffer.data(), static_cast<std::streamsize>(buffer.size()));
        const auto read_bytes = file.gcount();
        if (read_bytes > 0) {
            if (EVP_DigestUpdate(ctx.get(), buffer.data(), static_cast<std::size_t>(read_bytes)) != 1) {
                return std::nullopt;
            }
        }
    }

    std::array<uint8_t, EVP_MAX_MD_SIZE> digest{};
    unsigned int digest_len = 0;
    if (EVP_DigestFinal_ex(ctx.get(), digest.data(), &digest_len) != 1) {
        return std::nullopt;
    }

    return bytes_to_hex(std::span<const uint8_t>(digest.data(), digest_len));
}

std::string generate_nonce_hex(std::size_t num_bytes) {
    std::vector<uint8_t> buf(num_bytes);
    if (RAND_bytes(buf.data(), static_cast<int>(buf.size())) != 1) {
        return {};
    }
    return bytes_to_hex(buf);
}

std::string generate_pair_code_6digit() {
    uint32_t value = 0;
    // Rejection sampling to avoid modulo bias
    constexpr uint32_t limit = (UINT32_MAX / 1000000U) * 1000000U;
    do {
        if (RAND_bytes(reinterpret_cast<uint8_t*>(&value), sizeof(value)) != 1) {
            return {};
        }
    } while (value >= limit);

    uint32_t code = value % 1000000U;
    std::ostringstream oss;
    oss << std::setw(6) << std::setfill('0') << code;
    return oss.str();
}

std::string base64_encode(std::span<const uint8_t> data) {
    if (data.empty()) return {};
    const std::size_t out_len = 4 * ((data.size() + 2) / 3);
    std::string out(out_len, '\0');
    int written = EVP_EncodeBlock(
        reinterpret_cast<unsigned char*>(out.data()),
        data.data(),
        static_cast<int>(data.size()));
    if (written < 0) return {};
    out.resize(static_cast<std::size_t>(written));
    return out;
}

std::optional<std::vector<uint8_t>> base64_decode(const std::string& encoded) {
    if (encoded.empty()) return std::vector<uint8_t>{};

    std::string clean;
    clean.reserve(encoded.size());
    for (char c : encoded) {
        if (c != '\r' && c != '\n' && c != ' ') clean.push_back(c);
    }
    if (clean.size() % 4 != 0) return std::nullopt;

    std::size_t padding = 0;
    if (!clean.empty() && clean.back() == '=') padding++;
    if (clean.size() >= 2 && clean[clean.size() - 2] == '=') padding++;

    std::vector<uint8_t> out((clean.size() / 4) * 3);
    int decoded = EVP_DecodeBlock(
        out.data(),
        reinterpret_cast<const unsigned char*>(clean.data()),
        static_cast<int>(clean.size()));
    if (decoded < 0) return std::nullopt;

    const std::size_t actual_len = static_cast<std::size_t>(decoded) - padding;
    out.resize(actual_len);
    return out;
}

std::optional<KeyPairPem> generate_ed25519_keypair() {
    raii::EvpPkeyPtr pkey(EVP_PKEY_Q_keygen(nullptr, nullptr, "ED25519"));
    return export_keypair_pem(pkey.get());
}

std::optional<std::vector<uint8_t>> sign_ed25519(
    const std::string& private_key_pem,
    std::span<const uint8_t> message) {
    auto pkey = load_private_key_pem(private_key_pem);
    if (!pkey || !EVP_PKEY_is_a(pkey.get(), "ED25519")) return std::nullopt;

    raii::EvpMdCtxPtr ctx(EVP_MD_CTX_new());
    if (!ctx) return std::nullopt;

    if (EVP_DigestSignInit(ctx.get(), nullptr, nullptr, nullptr, pkey.get()) != 1) {
        return std::nullopt;
    }

    std::size_t sig_len = 0;
    if (EVP_DigestSign(ctx.get(), nullptr, &sig_len, message.data(), message.size()) != 1) {
        return std::nullopt;
    }

    std::vector<uint8_t> sig(sig_len);
    if (EVP_DigestSign(ctx.get(), sig.data(), &sig_len, message.data(), message.size()) != 1) {
        return std::nullopt;
    }
    sig.resize(sig_len);
    return sig;
}

bool verify_ed25519(
    const std::string& public_key_pem,
    std::span<const uint8_t> message,
    std::span<const uint8_t> signature) {
    auto pkey = load_public_key_pem(public_key_pem);
    if (!pkey || !EVP_PKEY_is_a(pkey.get(), "ED25519")) return false;

    raii::EvpMdCtxPtr ctx(EVP_MD_CTX_new());
    if (!ctx) return false;

    if (EVP_DigestVerifyInit(ctx.get(), nullptr, nullptr, nullptr, pkey.get()) != 1) {
        return false;
    }

    return EVP_DigestVerify(
               ctx.get(),
               signature.data(),
               signature.size(),
               message.data(),
               message.size()) == 1;
}

std::optional<KeyPairPem> generate_ecdsa_p256_keypair() {
    raii::EvpPkeyPtr pkey(EVP_PKEY_Q_keygen(nullptr, nullptr, "EC", "P-256"));
    return export_keypair_pem(pkey.get());
}

bool is_valid_ecdsa_p256_public_key_pem(const std::string& public_key_pem) {
    auto pkey = load_public_key_pem(public_key_pem);
    if (!pkey || !EVP_PKEY_is_a(pkey.get(), "EC")) return false;

    std::array<char, 64> group_name{};
    std::size_t len = 0;
    if (EVP_PKEY_get_utf8_string_param(
            pkey.get(), OSSL_PKEY_PARAM_GROUP_NAME,
            group_name.data(), group_name.size(), &len) != 1) {
        return false;
    }
    const std::string group(group_name.data(), len > 0 ? len - 1 : 0);
    // OpenSSL reports P-256 as "prime256v1" or "P-256"
    return group == "prime256v1" || group == "P-256" || std::string(group_name.data()) == "prime256v1";
}

std::optional<std::vector<uint8_t>> sign_ecdsa_p256(
    const std::string& private_key_pem,
    std::span<const uint8_t> message) {
    auto pkey = load_private_key_pem(private_key_pem);
    if (!pkey || !EVP_PKEY_is_a(pkey.get(), "EC")) return std::nullopt;

    raii::EvpMdCtxPtr ctx(EVP_MD_CTX_new());
    if (!ctx) return std::nullopt;

    if (EVP_DigestSignInit(ctx.get(), nullptr, EVP_sha256(), nullptr, pkey.get()) != 1) {
        return std::nullopt;
    }
    if (EVP_DigestSignUpdate(ctx.get(), message.data(), message.size()) != 1) {
        return std::nullopt;
    }

    std::size_t sig_len = 0;
    if (EVP_DigestSignFinal(ctx.get(), nullptr, &sig_len) != 1) {
        return std::nullopt;
    }
    std::vector<uint8_t> sig(sig_len);
    if (EVP_DigestSignFinal(ctx.get(), sig.data(), &sig_len) != 1) {
        return std::nullopt;
    }
    sig.resize(sig_len);
    return sig;
}

bool verify_ecdsa_p256(
    const std::string& public_key_pem,
    std::span<const uint8_t> message,
    std::span<const uint8_t> signature_der) {
    if (!is_valid_ecdsa_p256_public_key_pem(public_key_pem)) return false;

    auto pkey = load_public_key_pem(public_key_pem);
    if (!pkey) return false;

    raii::EvpMdCtxPtr ctx(EVP_MD_CTX_new());
    if (!ctx) return false;

    if (EVP_DigestVerifyInit(ctx.get(), nullptr, EVP_sha256(), nullptr, pkey.get()) != 1) {
        return false;
    }
    if (EVP_DigestVerifyUpdate(ctx.get(), message.data(), message.size()) != 1) {
        return false;
    }
    return EVP_DigestVerifyFinal(ctx.get(), signature_der.data(), signature_der.size()) == 1;
}

} // namespace mass::crypto
