#include "mass/db.hpp"
#include "mass/crypto.hpp"

#include <sqlite3.h>

namespace mass::storage {

namespace {

struct StmtDeleter {
    void operator()(sqlite3_stmt* stmt) const noexcept {
        if (stmt) sqlite3_finalize(stmt);
    }
};

using StmtPtr = std::unique_ptr<sqlite3_stmt, StmtDeleter>;

StmtPtr prepare(sqlite3* db, const char* sql) {
    sqlite3_stmt* raw = nullptr;
    if (sqlite3_prepare_v2(db, sql, -1, &raw, nullptr) != SQLITE_OK) {
        if (raw) sqlite3_finalize(raw);
        return nullptr;
    }
    return StmtPtr(raw);
}

std::string col_text(sqlite3_stmt* stmt, int col) {
    const unsigned char* txt = sqlite3_column_text(stmt, col);
    return txt ? reinterpret_cast<const char*>(txt) : "";
}

} // namespace

void SqliteDeleter::operator()(sqlite3* db) const noexcept {
    if (db) sqlite3_close_v2(db);
}

Database::Database(const std::filesystem::path& db_path) {
    sqlite3* raw = nullptr;
    if (sqlite3_open_v2(
            db_path.string().c_str(),
            &raw,
            SQLITE_OPEN_READWRITE | SQLITE_OPEN_CREATE | SQLITE_OPEN_FULLMUTEX,
            nullptr) == SQLITE_OK) {
        db_.reset(raw);
        sqlite3_busy_timeout(db_.get(), 5000);
        sqlite3_exec(db_.get(), "PRAGMA journal_mode=WAL;", nullptr, nullptr, nullptr);
    } else if (raw) {
        sqlite3_close_v2(raw);
    }
}

bool Database::init_schema() {
    std::lock_guard<std::mutex> lock(mutex_);
    if (!db_) return false;

    const char* ddl = R"SQL(
        CREATE TABLE IF NOT EXISTS paired_device (
            id INTEGER PRIMARY KEY CHECK (id = 1),
            device_public_key_pem TEXT NOT NULL,
            paired_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now'))
        );

        CREATE TABLE IF NOT EXISTS pair_codes (
            code TEXT PRIMARY KEY,
            expires_at INTEGER NOT NULL
        );

        CREATE TABLE IF NOT EXISTS nodes (
            node_id TEXT PRIMARY KEY,
            hostname TEXT NOT NULL,
            ip TEXT NOT NULL,
            role TEXT NOT NULL,
            status TEXT NOT NULL,
            public_key TEXT NOT NULL,
            last_seen TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now'))
        );

        CREATE INDEX IF NOT EXISTS idx_nodes_ip_hostname ON nodes(ip, hostname);

        CREATE TABLE IF NOT EXISTS audit_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            actor TEXT NOT NULL,
            action TEXT NOT NULL,
            target_node TEXT NOT NULL,
            status TEXT NOT NULL,
            created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now'))
        );
    )SQL";

    return sqlite3_exec(db_.get(), ddl, nullptr, nullptr, nullptr) == SQLITE_OK;
}

std::optional<PairedDevice> Database::get_paired_device() {
    std::lock_guard<std::mutex> lock(mutex_);
    if (!db_) return std::nullopt;

    auto stmt = prepare(db_.get(),
        "SELECT id, device_public_key_pem, paired_at FROM paired_device WHERE id = 1;");
    if (!stmt) return std::nullopt;

    if (sqlite3_step(stmt.get()) == SQLITE_ROW) {
        PairedDevice dev;
        dev.id = sqlite3_column_int(stmt.get(), 0);
        dev.device_public_key_pem = col_text(stmt.get(), 1);
        dev.paired_at = col_text(stmt.get(), 2);
        return dev;
    }
    return std::nullopt;
}

PairResult Database::pair_device_exclusive(const std::string& device_public_key_pem) {
    if (!crypto::is_valid_ecdsa_p256_public_key_pem(device_public_key_pem)) {
        return PairResult::InvalidKey;
    }

    std::lock_guard<std::mutex> lock(mutex_);
    if (!db_) return PairResult::DbError;

    auto check_stmt = prepare(db_.get(), "SELECT COUNT(*) FROM paired_device;");
    if (!check_stmt || sqlite3_step(check_stmt.get()) != SQLITE_ROW) {
        return PairResult::DbError;
    }
    if (sqlite3_column_int(check_stmt.get(), 0) >= 1) {
        return PairResult::AlreadyPaired;
    }

    auto ins_stmt = prepare(db_.get(),
        "INSERT INTO paired_device (id, device_public_key_pem) VALUES (1, ?);");
    if (!ins_stmt) return PairResult::DbError;

    sqlite3_bind_text(ins_stmt.get(), 1, device_public_key_pem.c_str(), -1, SQLITE_TRANSIENT);
    const int rc = sqlite3_step(ins_stmt.get());
    if (rc == SQLITE_CONSTRAINT) {
        return PairResult::AlreadyPaired;
    }
    return (rc == SQLITE_DONE) ? PairResult::Success : PairResult::DbError;
}

bool Database::revoke_paired_device() {
    std::lock_guard<std::mutex> lock(mutex_);
    if (!db_) return false;
    return sqlite3_exec(db_.get(), "DELETE FROM paired_device;", nullptr, nullptr, nullptr) == SQLITE_OK;
}

bool Database::store_pair_code(const std::string& code, int ttl_seconds) {
    std::lock_guard<std::mutex> lock(mutex_);
    if (!db_) return false;

    sqlite3_exec(db_.get(), "DELETE FROM pair_codes WHERE expires_at <= unixepoch('now');",
                 nullptr, nullptr, nullptr);

    auto stmt = prepare(db_.get(),
        "INSERT OR REPLACE INTO pair_codes (code, expires_at) VALUES (?, unixepoch('now') + ?);");
    if (!stmt) return false;
    sqlite3_bind_text(stmt.get(), 1, code.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_int(stmt.get(), 2, ttl_seconds);
    return sqlite3_step(stmt.get()) == SQLITE_DONE;
}

bool Database::consume_pair_code(const std::string& code) {
    std::lock_guard<std::mutex> lock(mutex_);
    if (!db_ || code.empty()) return false;

    auto stmt = prepare(db_.get(),
        "DELETE FROM pair_codes WHERE code = ? AND expires_at > unixepoch('now');");
    if (!stmt) return false;
    sqlite3_bind_text(stmt.get(), 1, code.c_str(), -1, SQLITE_TRANSIENT);
    if (sqlite3_step(stmt.get()) != SQLITE_DONE) return false;
    return sqlite3_changes(db_.get()) > 0;
}

NodeRegisterResult Database::register_or_update_node(const NodeRecord& node, int max_nodes) {
    std::lock_guard<std::mutex> lock(mutex_);
    if (!db_) return NodeRegisterResult::DbError;

    // Deduplicate by node_id OR (ip AND hostname) so restarting a node never creates duplicates
    auto dedup_stmt = prepare(db_.get(),
        "SELECT node_id FROM nodes WHERE node_id = ? OR (ip = ? AND hostname = ?) LIMIT 1;");
    if (!dedup_stmt) return NodeRegisterResult::DbError;
    sqlite3_bind_text(dedup_stmt.get(), 1, node.node_id.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(dedup_stmt.get(), 2, node.ip.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(dedup_stmt.get(), 3, node.hostname.c_str(), -1, SQLITE_TRANSIENT);

    std::string existing_id;
    const bool already_exists = (sqlite3_step(dedup_stmt.get()) == SQLITE_ROW);
    if (already_exists) {
        existing_id = col_text(dedup_stmt.get(), 0);
    }

    if (!already_exists) {
        auto count_stmt = prepare(db_.get(),
            "SELECT COUNT(*) FROM nodes WHERE status = 'online' OR status = 'active';");
        if (!count_stmt || sqlite3_step(count_stmt.get()) != SQLITE_ROW) {
            return NodeRegisterResult::DbError;
        }
        const int active_count = sqlite3_column_int(count_stmt.get(), 0);
        if (active_count >= max_nodes) {
            return NodeRegisterResult::LicenseQuotaExceeded;
        }
    } else if (existing_id != node.node_id) {
        // Remove stale entry for same IP+hostname under a previous node_id before upserting
        auto del_stmt = prepare(db_.get(), "DELETE FROM nodes WHERE node_id = ?;");
        if (del_stmt) {
            sqlite3_bind_text(del_stmt.get(), 1, existing_id.c_str(), -1, SQLITE_TRANSIENT);
            sqlite3_step(del_stmt.get());
        }
    }

    auto upsert = prepare(db_.get(), R"SQL(
        INSERT INTO nodes (node_id, hostname, ip, role, status, public_key, last_seen)
        VALUES (?, ?, ?, ?, ?, ?, strftime('%Y-%m-%dT%H:%M:%SZ', 'now'))
        ON CONFLICT(node_id) DO UPDATE SET
            hostname = excluded.hostname,
            ip = excluded.ip,
            role = excluded.role,
            status = excluded.status,
            public_key = excluded.public_key,
            last_seen = strftime('%Y-%m-%dT%H:%M:%SZ', 'now');
    )SQL");
    if (!upsert) return NodeRegisterResult::DbError;

    sqlite3_bind_text(upsert.get(), 1, node.node_id.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(upsert.get(), 2, node.hostname.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(upsert.get(), 3, node.ip.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(upsert.get(), 4, node.role.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(upsert.get(), 5, node.status.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(upsert.get(), 6, node.public_key.c_str(), -1, SQLITE_TRANSIENT);

    if (sqlite3_step(upsert.get()) != SQLITE_DONE) return NodeRegisterResult::DbError;
    return already_exists ? NodeRegisterResult::Updated : NodeRegisterResult::Registered;
}

std::vector<NodeRecord> Database::list_nodes() {
    std::lock_guard<std::mutex> lock(mutex_);
    std::vector<NodeRecord> out;
    if (!db_) return out;

    auto stmt = prepare(db_.get(),
        "SELECT node_id, hostname, ip, role, status, public_key, last_seen FROM nodes ORDER BY node_id;");
    if (!stmt) return out;

    while (sqlite3_step(stmt.get()) == SQLITE_ROW) {
        out.push_back(NodeRecord{
            col_text(stmt.get(), 0),
            col_text(stmt.get(), 1),
            col_text(stmt.get(), 2),
            col_text(stmt.get(), 3),
            col_text(stmt.get(), 4),
            col_text(stmt.get(), 5),
            col_text(stmt.get(), 6)
        });
    }
    return out;
}

std::optional<NodeRecord> Database::get_node(const std::string& node_id) {
    std::lock_guard<std::mutex> lock(mutex_);
    if (!db_) return std::nullopt;

    auto stmt = prepare(db_.get(),
        "SELECT node_id, hostname, ip, role, status, public_key, last_seen FROM nodes WHERE node_id = ?;");
    if (!stmt) return std::nullopt;
    sqlite3_bind_text(stmt.get(), 1, node_id.c_str(), -1, SQLITE_TRANSIENT);

    if (sqlite3_step(stmt.get()) == SQLITE_ROW) {
        return NodeRecord{
            col_text(stmt.get(), 0),
            col_text(stmt.get(), 1),
            col_text(stmt.get(), 2),
            col_text(stmt.get(), 3),
            col_text(stmt.get(), 4),
            col_text(stmt.get(), 5),
            col_text(stmt.get(), 6)
        };
    }
    return std::nullopt;
}

int Database::count_active_nodes() {
    std::lock_guard<std::mutex> lock(mutex_);
    if (!db_) return 0;

    auto stmt = prepare(db_.get(),
        "SELECT COUNT(*) FROM nodes WHERE status = 'online' OR status = 'active';");
    if (!stmt || sqlite3_step(stmt.get()) != SQLITE_ROW) return 0;
    return sqlite3_column_int(stmt.get(), 0);
}

bool Database::append_audit_log(
    const std::string& actor,
    const std::string& action,
    const std::string& target_node,
    const std::string& status) {
    std::lock_guard<std::mutex> lock(mutex_);
    if (!db_) return false;

    auto stmt = prepare(db_.get(),
        "INSERT INTO audit_logs (actor, action, target_node, status) VALUES (?, ?, ?, ?);");
    if (!stmt) return false;

    sqlite3_bind_text(stmt.get(), 1, actor.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(stmt.get(), 2, action.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(stmt.get(), 3, target_node.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(stmt.get(), 4, status.c_str(), -1, SQLITE_TRANSIENT);
    return sqlite3_step(stmt.get()) == SQLITE_DONE;
}

std::vector<AuditLogEntry> Database::list_recent_audit_logs(int limit) {
    std::lock_guard<std::mutex> lock(mutex_);
    std::vector<AuditLogEntry> out;
    if (!db_) return out;

    auto stmt = prepare(db_.get(),
        "SELECT id, actor, action, target_node, status, created_at FROM audit_logs ORDER BY id DESC LIMIT ?;");
    if (!stmt) return out;
    sqlite3_bind_int(stmt.get(), 1, limit);

    while (sqlite3_step(stmt.get()) == SQLITE_ROW) {
        out.push_back(AuditLogEntry{
            sqlite3_column_int64(stmt.get(), 0),
            col_text(stmt.get(), 1),
            col_text(stmt.get(), 2),
            col_text(stmt.get(), 3),
            col_text(stmt.get(), 4),
            col_text(stmt.get(), 5)
        });
    }
    return out;
}

} // namespace mass::storage
