#include "mass/license.hpp"
#include "mass/crypto.hpp"

#include <chrono>
#include <ctime>
#include <fstream>
#include <iomanip>
#include <nlohmann/json.hpp>
#include <sstream>

namespace mass::licensing {

namespace {

std::optional<std::chrono::system_clock::time_point> parse_iso8601_utc(const std::string& iso) {
    // Supports "YYYY-MM-DDTHH:MM:SSZ"
    if (iso.size() < 20 || iso.back() != 'Z') return std::nullopt;
    std::tm tm{};
    std::istringstream iss(iso.substr(0, 19));
    iss >> std::get_time(&tm, "%Y-%m-%dT%H:%M:%S");
    if (iss.fail()) return std::nullopt;

#ifdef _WIN32
    std::time_t tt = _mkgmtime(&tm);
#else
    std::time_t tt = timegm(&tm);
#endif
    if (tt == static_cast<std::time_t>(-1)) return std::nullopt;
    return std::chrono::system_clock::from_time_t(tt);
}

} // namespace

std::string canonicalize_license_payload(const LicensePayload& payload) {
    // Fixed key order JSON serialization for deterministic Ed25519 signature verification
    nlohmann::json j;
    j["expires_at"] = payload.expires_at;
    j["features"] = {
        {"console", payload.features.console},
        {"file_transfer", payload.features.file_transfer},
        {"ssa", payload.features.ssa},
        {"telemetry", payload.features.telemetry}
    };
    j["master_machine_id"] = payload.master_machine_id;
    j["max_nodes"] = payload.max_nodes;
    return j.dump();
}

LicenseValidationResult verify_license_json(
    const std::string& license_json_str,
    const std::string& expected_machine_id,
    const std::string& public_key_pem) {
    LicenseValidationResult res;
    nlohmann::json root;
    try {
        root = nlohmann::json::parse(license_json_str);
    } catch (const std::exception& e) {
        res.error = std::string("Invalid JSON in license.mass: ") + e.what();
        return res;
    }

    if (!root.contains("payload") || !root.contains("signature") ||
        !root["payload"].is_object() || !root["signature"].is_string()) {
        res.error = "Missing payload or signature field in license.mass";
        return res;
    }

    const auto& pj = root["payload"];
    if (!pj.contains("master_machine_id") || !pj.contains("max_nodes") ||
        !pj.contains("features") || !pj.contains("expires_at")) {
        res.error = "Incomplete license payload fields";
        return res;
    }

    LicensePayload payload;
    try {
        payload.master_machine_id = pj.at("master_machine_id").get<std::string>();
        payload.max_nodes         = pj.at("max_nodes").get<int>();
        payload.expires_at        = pj.at("expires_at").get<std::string>();

        const auto& fj = pj.at("features");
        payload.features.telemetry     = fj.value("telemetry", false);
        payload.features.console       = fj.value("console", false);
        payload.features.file_transfer = fj.value("file_transfer", false);
        payload.features.ssa           = fj.value("ssa", false);
    } catch (const std::exception& e) {
        res.error = std::string("Malformed license payload types: ") + e.what();
        return res;
    }

    if (payload.max_nodes < 1) {
        res.error = "License max_nodes must be >= 1";
        return res;
    }

    // 1. Verify Ed25519 signature over canonical payload
    const std::string canonical = canonicalize_license_payload(payload);
    auto sig_bytes = crypto::base64_decode(root.at("signature").get<std::string>());
    if (!sig_bytes) {
        res.error = "Invalid Base64 signature encoding";
        return res;
    }

    const std::span<const uint8_t> msg_span(
        reinterpret_cast<const uint8_t*>(canonical.data()), canonical.size());
    if (!crypto::verify_ed25519(public_key_pem, msg_span, *sig_bytes)) {
        res.error = "Ed25519 license signature verification failed";
        return res;
    }

    // 2. Verify hardware binding (master_machine_id)
    if (payload.master_machine_id != expected_machine_id) {
        res.error = "Hardware mismatch: license bound to " + payload.master_machine_id +
                    ", host is " + expected_machine_id;
        return res;
    }

    // 3. Verify expiration timestamp (ISO-8601 UTC)
    auto exp_tp = parse_iso8601_utc(payload.expires_at);
    if (!exp_tp) {
        res.error = "Invalid ISO-8601 UTC expires_at format (expected YYYY-MM-DDTHH:MM:SSZ)";
        return res;
    }
    if (std::chrono::system_clock::now() > *exp_tp) {
        res.error = "License expired at " + payload.expires_at;
        return res;
    }

    res.valid = true;
    res.payload = payload;
    return res;
}

LicenseValidationResult load_and_verify_license(
    const std::filesystem::path& license_path,
    const std::string& expected_machine_id,
    const std::string& public_key_pem) {
    std::ifstream ifs(license_path);
    if (!ifs.is_open()) {
        return LicenseValidationResult{
            false, "Cannot open license file: " + license_path.string(), std::nullopt};
    }
    std::ostringstream ss;
    ss << ifs.rdbuf();
    return verify_license_json(ss.str(), expected_machine_id, public_key_pem);
}

std::optional<std::string> create_signed_license_json(
    const LicensePayload& payload,
    const std::string& private_key_pem) {
    const std::string canonical = canonicalize_license_payload(payload);
    const std::span<const uint8_t> msg_span(
        reinterpret_cast<const uint8_t*>(canonical.data()), canonical.size());

    auto sig = crypto::sign_ed25519(private_key_pem, msg_span);
    if (!sig) return std::nullopt;

    nlohmann::json root;
    root["payload"] = nlohmann::json::parse(canonical);
    root["signature"] = crypto::base64_encode(*sig);
    return root.dump(2);
}

} // namespace mass::licensing
