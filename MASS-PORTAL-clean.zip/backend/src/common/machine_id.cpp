#include "mass/machine_id.hpp"
#include "mass/crypto.hpp"

#include <fstream>
#include <string>

#ifdef _WIN32
#include <windows.h>
#else
#include <unistd.h>
#endif

namespace mass::hw {

namespace {

std::string read_trimmed_file(const char* path) {
    std::ifstream ifs(path);
    if (!ifs.is_open()) return {};
    std::string line;
    std::getline(ifs, line);
    while (!line.empty() && (line.back() == '\r' || line.back() == '\n' || line.back() == ' ')) {
        line.pop_back();
    }
    return line;
}

} // namespace

std::string get_master_machine_id() {
    std::string raw_seed;

#ifdef _WIN32
    HKEY hKey = nullptr;
    if (RegOpenKeyExA(
            HKEY_LOCAL_MACHINE,
            "SOFTWARE\\Microsoft\\Cryptography",
            0,
            KEY_READ | KEY_WOW64_64KEY,
            &hKey) == ERROR_SUCCESS) {
        char buf[256] = {};
        DWORD buf_size = sizeof(buf);
        DWORD type = 0;
        if (RegQueryValueExA(hKey, "MachineGuid", nullptr, &type,
                             reinterpret_cast<LPBYTE>(buf), &buf_size) == ERROR_SUCCESS) {
            raw_seed += std::string(buf);
        }
        RegCloseKey(hKey);
    }

    DWORD serial = 0;
    if (GetVolumeInformationA("C:\\", nullptr, 0, &serial, nullptr, nullptr, nullptr, 0)) {
        raw_seed += ":" + std::to_string(serial);
    }
#else
    std::string etc_id = read_trimmed_file("/etc/machine-id");
    if (etc_id.empty()) {
        etc_id = read_trimmed_file("/var/lib/dbus/machine-id");
    }
    raw_seed = etc_id;
    if (raw_seed.empty()) {
        char hostname[256] = {};
        if (gethostname(hostname, sizeof(hostname)) == 0) {
            raw_seed = std::string("fallback-host:") + hostname;
        } else {
            raw_seed = "fallback-host:unknown";
        }
    }
#endif

    return "mass-hw-" + crypto::sha256_hex(raw_seed).substr(0, 32);
}

} // namespace mass::hw
