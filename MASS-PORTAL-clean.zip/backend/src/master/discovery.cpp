#include "mass/master_server.hpp"

#include <cstring>
#include <iostream>
#include <nlohmann/json.hpp>
#include <string>

#ifdef _WIN32
#include <winsock2.h>
#include <ws2tcpip.h>
using sock_t = SOCKET;
#else
#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <unistd.h>
using sock_t = int;
#endif

namespace mass::master {

namespace {

std::string get_local_hostname() {
    char buf[256] = {};
    if (gethostname(buf, sizeof(buf) - 1) == 0) {
        return std::string(buf);
    }
    return "mass-master";
}

void close_sock(sock_t s) {
#ifdef _WIN32
    closesocket(s);
#else
    close(s);
#endif
}

} // namespace

void run_opt_in_lan_discovery(int udp_port, int portal_port, std::atomic<bool>& running) {
    sock_t fd = socket(AF_INET, SOCK_DGRAM, 0);
#ifdef _WIN32
    if (fd == INVALID_SOCKET) return;
#else
    if (fd < 0) return;
#endif

    int reuse = 1;
    setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, reinterpret_cast<const char*>(&reuse), sizeof(reuse));
    int bcast = 1;
    setsockopt(fd, SOL_SOCKET, SO_BROADCAST, reinterpret_cast<const char*>(&bcast), sizeof(bcast));

#ifdef _WIN32
    DWORD tv = 1000;
    setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, reinterpret_cast<const char*>(&tv), sizeof(tv));
#else
    struct timeval tv{1, 0};
    setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
#endif

    sockaddr_in addr{};
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = htonl(INADDR_ANY);
    addr.sin_port = htons(static_cast<uint16_t>(udp_port));

    if (bind(fd, reinterpret_cast<sockaddr*>(&addr), sizeof(addr)) != 0) {
        std::cerr << "[MASS Discovery] Failed to bind UDP port " << udp_port << "\n";
        close_sock(fd);
        return;
    }

    const std::string hostname = get_local_hostname();
    const std::string reply_payload = nlohmann::json({
        {"service", "mass_master"},
        {"port", portal_port},
        {"hostname", hostname},
        {"requires_pairing", true}
    }).dump();

    std::cout << "[MASS Discovery] Opt-in UDP LAN discovery active on port " << udp_port << "\n";

    char buf[512] = {};
    while (running.load()) {
        sockaddr_in peer{};
        socklen_t peer_len = sizeof(peer);
        const auto n = recvfrom(
            fd, buf, sizeof(buf) - 1, 0,
            reinterpret_cast<sockaddr*>(&peer), &peer_len);
        if (n <= 0) continue;
        buf[n] = '\0';

        const std::string probe(buf, static_cast<std::size_t>(n));
        if (probe.find("MASS_DISCOVER") != std::string::npos) {
            sendto(
                fd,
                reply_payload.data(),
                static_cast<int>(reply_payload.size()),
                0,
                reinterpret_cast<const sockaddr*>(&peer),
                peer_len);
        }
    }

    close_sock(fd);
}

} // namespace mass::master
