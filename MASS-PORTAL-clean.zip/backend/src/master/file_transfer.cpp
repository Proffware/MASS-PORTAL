#include "mass/master_server.hpp"
#include "mass/crypto.hpp"

#include <httplib.h>
#include <memory>
#include <nlohmann/json.hpp>

namespace mass::master {

namespace {

std::pair<std::string, int> parse_host_port(const std::string& url, int default_port = 8445) {
    std::string s = url;
    const auto scheme_pos = s.find("://");
    if (scheme_pos != std::string::npos) {
        s = s.substr(scheme_pos + 3);
    }
    const auto slash_pos = s.find('/');
    if (slash_pos != std::string::npos) {
        s = s.substr(0, slash_pos);
    }
    const auto colon_pos = s.rfind(':');
    if (colon_pos != std::string::npos) {
        try {
            return {s.substr(0, colon_pos), std::stoi(s.substr(colon_pos + 1))};
        } catch (...) {}
    }
    return {s, default_port};
}

std::unique_ptr<httplib::SSLClient> make_mtls_client(
    const std::string& url,
    const std::string& ca_cert_path,
    const std::string& client_cert_path,
    const std::string& client_key_path) {
    const auto [host, port] = parse_host_port(url, 8445);
    auto cli = std::make_unique<httplib::SSLClient>(host, port, client_cert_path, client_key_path);
    cli->set_ca_cert_path(ca_cert_path);
    cli->enable_server_certificate_verification(true);
    return cli;
}

} // namespace

FileTransferResult execute_node_file_transfer(
    const FileTransferRequest& req,
    const std::unordered_map<std::string, std::string>& node_endpoints,
    const std::string& ca_cert_path,
    const std::string& client_cert_path,
    const std::string& client_key_path) {
    FileTransferResult result;
    result.transfer_id = "xfer-" + crypto::generate_nonce_hex(8);

    auto src_it = node_endpoints.find(req.source_node_id);
    auto dst_it = node_endpoints.find(req.target_node_id);
    if (src_it == node_endpoints.end()) {
        result.error = "Source node not connected: " + req.source_node_id;
        return result;
    }
    if (dst_it == node_endpoints.end()) {
        result.error = "Target node not connected: " + req.target_node_id;
        return result;
    }

    auto src_cli = make_mtls_client(src_it->second, ca_cert_path, client_cert_path, client_key_path);
    src_cli->set_read_timeout(30, 0);

    nlohmann::json pull_req = {{"path", req.source_path}};
    auto pull_res = src_cli->Post("/node/files/read", pull_req.dump(), "application/json");
    if (!pull_res || pull_res->status != 200) {
        result.error = "Failed to read file from source node over mTLS";
        return result;
    }

    std::string payload_b64;
    std::string computed_sha256;
    try {
        auto j = nlohmann::json::parse(pull_res->body);
        payload_b64 = j.at("content_b64").get<std::string>();
        computed_sha256 = j.at("sha256").get<std::string>();
    } catch (const std::exception& e) {
        result.error = std::string("Malformed response from source node: ") + e.what();
        return result;
    }

    auto raw_bytes = crypto::base64_decode(payload_b64);
    if (!raw_bytes) {
        result.error = "Invalid Base64 payload from source node";
        return result;
    }

    const std::string verified_sha256 = crypto::sha256_hex(*raw_bytes);
    if (verified_sha256 != computed_sha256) {
        result.error = "SHA-256 integrity mismatch in transit from source node";
        return result;
    }
    if (!req.expected_sha256.empty() && verified_sha256 != req.expected_sha256) {
        result.error = "SHA-256 does not match caller expected_sha256";
        return result;
    }

    auto dst_cli = make_mtls_client(dst_it->second, ca_cert_path, client_cert_path, client_key_path);
    dst_cli->set_read_timeout(30, 0);

    nlohmann::json push_req = {
        {"path", req.target_path},
        {"content_b64", payload_b64},
        {"sha256", verified_sha256}
    };
    auto push_res = dst_cli->Post("/node/files/write", push_req.dump(), "application/json");
    if (!push_res || push_res->status != 200) {
        result.error = "Failed to write verified file to target node over mTLS";
        return result;
    }

    result.ok = true;
    result.sha256 = verified_sha256;
    result.bytes_transferred = raw_bytes->size();
    return result;
}

} // namespace mass::master
