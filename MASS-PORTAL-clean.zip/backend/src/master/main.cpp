#include "mass/db.hpp"
#include "mass/license.hpp"
#include "mass/machine_id.hpp"
#include "mass/master_server.hpp"

#include <fstream>
#include <iostream>
#include <sstream>
#include <string>

namespace {

std::string read_file_str(const std::string& path) {
    std::ifstream ifs(path);
    if (!ifs.is_open()) return {};
    std::ostringstream ss;
    ss << ifs.rdbuf();
    return ss.str();
}

} // namespace

int main(int argc, char* argv[]) {
    mass::master::MasterConfig cfg;

    for (int i = 1; i < argc; ++i) {
        const std::string arg = argv[i];
        auto next = [&]() -> std::string {
            return (i + 1 < argc) ? std::string(argv[++i]) : "";
        };
        if (arg == "--port") cfg.portal_port = std::stoi(next());
        else if (arg == "--node-port") cfg.node_mtls_port = std::stoi(next());
        else if (arg == "--db") cfg.db_path = next();
        else if (arg == "--license") cfg.license_path = next();
        else if (arg == "--pubkey") cfg.vendor_pubkey_path = next();
        else if (arg == "--cert") cfg.server_cert_path = next();
        else if (arg == "--key") cfg.server_key_path = next();
        else if (arg == "--ca") cfg.ca_cert_path = next();
        else if (arg == "--enable-discovery") cfg.enable_discovery = true;
    }

    const std::string machine_id = mass::hw::get_master_machine_id();
    std::cout << "[MASS Master v2] Hardware Machine ID: " << machine_id << "\n";

    std::string pubkey_pem = mass::licensing::kEmbeddedVendorPublicKeyPem;
    if (!cfg.vendor_pubkey_path.empty()) {
        pubkey_pem = read_file_str(cfg.vendor_pubkey_path);
        if (pubkey_pem.empty()) {
            std::cerr << "[MASS Master v2] Failed to read vendor public key: " << cfg.vendor_pubkey_path << "\n";
            return 1;
        }
    }

    const auto lic_res = mass::licensing::load_and_verify_license(
        cfg.license_path, machine_id, pubkey_pem);
    if (!lic_res.valid || !lic_res.payload) {
        std::cerr << "[MASS Master v2] LICENSE ERROR: " << lic_res.error << "\n";
        return 1;
    }

    std::cout << "[MASS Master v2] License verified (max_nodes=" << lic_res.payload->max_nodes
              << ", expires_at=" << lic_res.payload->expires_at << ")\n";

    mass::storage::Database db(cfg.db_path);
    if (!db.init_schema()) {
        std::cerr << "[MASS Master v2] Failed to initialize SQLite schema at " << cfg.db_path << "\n";
        return 1;
    }

    mass::master::MasterServer server(cfg, db, *lic_res.payload, machine_id);
    return server.run();
}
