#include "mass/master_server.hpp"
#include "mass/crypto.hpp"
#include "mass/ssa.hpp"

#include <atomic>
#include <httplib.h>
#include <fstream>
#include <iostream>
#include <regex>
#include <memory>
#include <openssl/err.h>
#include <openssl/ssl.h>
#include <thread>

namespace mass::master {

namespace {

void configure_tls13_only(httplib::SSLServer& svr) {
    if (SSL_CTX* ctx = svr.ssl_context()) {
        SSL_CTX_set_min_proto_version(ctx, TLS1_2_VERSION);
        SSL_CTX_set_options(ctx, SSL_OP_NO_SSLv2 | SSL_OP_NO_SSLv3 |
                                     SSL_OP_NO_TLSv1 | SSL_OP_NO_TLSv1_1);
    }
}

std::string read_active_tunnel_url() {
    std::ifstream ifs("mass_tunnel.log");
    if (!ifs.is_open()) return {};
    static const std::regex url_re(R"(https://[a-zA-Z0-9-]+\.trycloudflare\.com)");
    std::string line, found;
    while (std::getline(ifs, line)) {
        std::smatch m;
        if (std::regex_search(line, m, url_re)) {
            found = m[0].str();
        }
    }
    return found;
}

void send_json(httplib::Response& res, int status, const nlohmann::json& body) {
    res.status = status;
    res.set_content(body.dump(), "application/json");
}

std::pair<std::string, int> parse_host_port(const std::string& url, int default_port = 8445) {
    std::string s = url;
    const auto scheme_pos = s.find("://");
    if (scheme_pos != std::string::npos) {
        s = s.substr(scheme_pos + 3);
    }
    const auto slash_pos = s.find('/');
    if (slash_pos != std::string::npos) {
        s = s.substr(0, slash_pos);
    }
    const auto colon_pos = s.rfind(':');
    if (colon_pos != std::string::npos) {
        try {
            return {s.substr(0, colon_pos), std::stoi(s.substr(colon_pos + 1))};
        } catch (...) {}
    }
    return {s, default_port};
}

std::unique_ptr<httplib::SSLClient> make_node_mtls_client(
    const std::string& control_url,
    const MasterConfig& cfg) {
    const auto [host, port] = parse_host_port(control_url, 8445);
    auto cli = std::make_unique<httplib::SSLClient>(
        host, port, cfg.server_cert_path, cfg.server_key_path);
    cli->set_ca_cert_path(cfg.ca_cert_path);
    cli->enable_server_certificate_verification(true);
    return cli;
}

} // namespace

MasterServer::MasterServer(
    MasterConfig config,
    storage::Database& db,
    licensing::LicensePayload license,
    std::string machine_id)
    : config_(std::move(config)),
      db_(db),
      license_(std::move(license)),
      machine_id_(std::move(machine_id)),
      nonce_store_(std::chrono::seconds{30}) {}

int MasterServer::run() {
    // 1. Android Portal HTTPS Server on :6277 (TLS 1.3 ONLY)
    httplib::SSLServer portal_svr(
        config_.server_cert_path.c_str(),
        config_.server_key_path.c_str());

    if (!portal_svr.is_valid()) {
        std::cerr << "[MASS Master v2] Failed to initialize TLS 1.3 Portal server.\n"
                  << "  cert=" << config_.server_cert_path << " key=" << config_.server_key_path << "\n";
        ERR_print_errors_fp(stderr);
        return 1;
    }
    configure_tls13_only(portal_svr);
    portal_svr.set_read_timeout(900, 0);
    portal_svr.set_write_timeout(900, 0);
    portal_svr.set_keep_alive_max_count(1000);
    portal_svr.set_keep_alive_timeout(30);

    // 2. Node Daemon mTLS Coordinator Server on :8444 (TLS 1.3 + Client Cert Required)
    httplib::SSLServer node_svr(
        config_.server_cert_path.c_str(),
        config_.server_key_path.c_str(),
        config_.ca_cert_path.c_str());

    if (!node_svr.is_valid()) {
        std::cerr << "[MASS Master v2] Failed to initialize mTLS Node Coordinator server.\n"
                  << "  ca=" << config_.ca_cert_path << "\n";
        ERR_print_errors_fp(stderr);
        return 1;
    }
    configure_tls13_only(node_svr);
    if (SSL_CTX* nctx = node_svr.ssl_context()) {
        SSL_CTX_set_verify(nctx, SSL_VERIFY_PEER | SSL_VERIFY_FAIL_IF_NO_PEER_CERT, nullptr);
    }

    auto authenticate_portal = [&](const httplib::Request& req, httplib::Response& res) -> bool {
        const auto paired = db_.get_paired_device();
        const std::optional<std::string> pub_pem =
            paired ? std::optional<std::string>(paired->device_public_key_pem) : std::nullopt;

        const std::string nonce = req.get_header_value("X-MASS-Nonce");
        const std::string sig   = req.get_header_value("X-MASS-Signature");

        const auto auth_res = auth::verify_request_signature(
            nonce_store_, pub_pem, req.method, req.path, req.body, nonce, sig);

        if (!auth_res.ok) {
            send_json(res, auth_res.http_status, {{"error", auth_res.error}});
            return false;
        }
        return true;
    };

    auto resolve_node_endpoint = [&](const std::string& node_id) -> std::optional<std::string> {
        std::lock_guard<std::mutex> lock(telemetry_mutex_);
        auto it = node_control_urls_.find(node_id);
        if (it == node_control_urls_.end()) return std::nullopt;
        return it->second;
    };

    // -----------------------------------------------------------------------
    // Portal Endpoints (Master :6277 <-> Android Portal)
    // -----------------------------------------------------------------------

    portal_svr.Get("/v1/auth/challenge", [&](const httplib::Request&, httplib::Response& res) {
        const std::string nonce = nonce_store_.issue();
        if (nonce.empty()) {
            send_json(res, 500, {{"error", "Failed to generate cryptographic nonce"}});
            return;
        }
        send_json(res, 200, {{"nonce", nonce}, {"ttl_seconds", 30}});
    });

    portal_svr.Post("/v1/device/pair", [&](const httplib::Request& req, httplib::Response& res) {
        nlohmann::json body;
        try {
            body = nlohmann::json::parse(req.body);
        } catch (...) {
            send_json(res, 400, {{"error", "Invalid JSON body"}});
            return;
        }

        const std::string pair_code = body.value("pair_code", "");
        const std::string pub_key   = body.value("device_public_key", "");

        if (pair_code.empty() || pub_key.empty()) {
            send_json(res, 400, {{"error", "pair_code and device_public_key are required"}});
            return;
        }

        if (!db_.consume_pair_code(pair_code)) {
            db_.append_audit_log("unpaired_client", "device_pair", "master", "rejected_invalid_code");
            send_json(res, 401, {{"error", "Invalid or expired pairing code"}});
            return;
        }

        const auto pair_res = db_.pair_device_exclusive(pub_key);
        if (pair_res == storage::PairResult::AlreadyPaired) {
            db_.append_audit_log("unpaired_client", "device_pair", "master", "conflict_409");
            send_json(res, 409, {{"error", "A device is already paired. Revoke it first."}});
            return;
        }
        if (pair_res == storage::PairResult::InvalidKey) {
            send_json(res, 400, {{"error", "device_public_key must be a valid ECDSA P-256 PEM"}});
            return;
        }
        if (pair_res != storage::PairResult::Success) {
            send_json(res, 500, {{"error", "Database error during pairing"}});
            return;
        }

        db_.append_audit_log("android_portal", "device_pair", "master", "success");
        send_json(res, 200, {{"status", "paired"}, {"lock_mode", "exclusive_single_device"}});
    });

    portal_svr.Get("/v1/health", [&](const httplib::Request& req, httplib::Response& res) {
        if (!authenticate_portal(req, res)) return;
        const int used_nodes = db_.count_active_nodes();
        send_json(res, 200, {
            {"status", "ok"},
            {"version", "2.9.0-Ripple"},
            {"tls", "TLSv1.3"},
            {"remote_url", read_active_tunnel_url()},
            {"portal_port", config_.portal_port},
            {"discovery_enabled", config_.enable_discovery},
            {"desktop_stream_fps", 30},
            {"master_machine_id", machine_id_},
            {"quota", {
                {"used_nodes", used_nodes},
                {"max_nodes", license_.max_nodes}
            }}
        });
    });

    // 1. Live Hardware & AI (SI) Telemetry
    portal_svr.Get("/v1/nodes", [&](const httplib::Request& req, httplib::Response& res) {
        if (!authenticate_portal(req, res)) return;

        const auto nodes = db_.list_nodes();
        nlohmann::json arr = nlohmann::json::array();

        std::lock_guard<std::mutex> lock(telemetry_mutex_);
        for (const auto& n : nodes) {
            nlohmann::json item = {
                {"node_id", n.node_id},
                {"hostname", n.hostname},
                {"ip", n.ip},
                {"role", n.role},
                {"status", n.status},
                {"last_seen", n.last_seen}
            };
            if (auto it = live_telemetry_.find(n.node_id); it != live_telemetry_.end()) {
                const auto& t = it->second;
                item["cpu_percent"]       = t.cpu_percent;
                item["cpu_temp_c"]        = t.cpu_temp_c;
                item["gpu_percent"]       = t.gpu_percent;
                item["gpu_temp_c"]        = t.gpu_temp_c;
                item["gpu_vram_used_gb"]  = t.gpu_vram_used_gb;
                item["gpu_vram_total_gb"] = t.gpu_vram_total_gb;
                item["gpu_name"]          = t.gpu_name;
                item["ram_used_gb"]       = t.ram_used_gb;
                item["ram_total_gb"]      = t.ram_total_gb;
                item["disk_used_gb"]      = t.disk_used_gb;
                item["disk_total_gb"]     = t.disk_total_gb;
                item["uptime"]            = t.uptime;
                item["os_info"]           = t.os_info;
                item["last_sync"]         = t.last_sync;
                item["si_status"] = {
                    {"ollama_online", t.si_info.ollama_online},
                    {"state", t.si_info.state},
                    {"loaded_model", t.si_info.loaded_model},
                    {"vram_used_gb", t.si_info.vram_used_gb},
                    {"available_models_count", t.si_info.available_models_count},
                    {"inference_gpu_percent", t.si_info.inference_gpu_percent},
                    {"inference_gpu_temp_c", t.si_info.inference_gpu_temp_c}
                };
                nlohmann::json gpus_j = nlohmann::json::array();
                for (const auto& g : t.gpus) {
                    gpus_j.push_back({
                        {"name", g.name}, {"kind", g.kind}, {"util_percent", g.util_percent},
                        {"temp_c", g.temp_c}, {"vram_used_gb", g.vram_used_gb}, {"vram_total_gb", g.vram_total_gb}
                    });
                }
                nlohmann::json disks_j = nlohmann::json::array();
                for (const auto& d : t.disks) {
                    disks_j.push_back({
                        {"device", d.device}, {"mount", d.mount}, {"used_gb", d.used_gb},
                        {"total_gb", d.total_gb}, {"percent", d.percent}
                    });
                }
                nlohmann::json ports_j = nlohmann::json::array();
                for (const auto& p : t.network_ports) {
                    ports_j.push_back({{"name", p.name}, {"detail", p.detail}, {"active", p.active}});
                }
                item["gpus"] = std::move(gpus_j);
                item["disks"] = std::move(disks_j);
                item["network_ports"] = std::move(ports_j);
            }
            arr.push_back(std::move(item));
        }

        send_json(res, 200, {{"nodes", arr}});
    });

    // 2. Remote Shell & Interactive sudo (never logs sudo_password)
    portal_svr.Post("/v1/console/exec", [&](const httplib::Request& req, httplib::Response& res) {
        if (!authenticate_portal(req, res)) return;

        nlohmann::json body;
        try {
            body = nlohmann::json::parse(req.body);
        } catch (...) {
            send_json(res, 400, {{"error", "Invalid JSON"}});
            return;
        }

        const std::string target_node_id = body.value("target_node_id", "");
        const std::string command        = body.value("command", "");
        if (target_node_id.empty() || command.empty()) {
            send_json(res, 400, {{"error", "target_node_id and command are required"}});
            return;
        }

        auto control_url = resolve_node_endpoint(target_node_id);
        if (!control_url) {
            db_.append_audit_log("android_portal", "console_exec:" + command, target_node_id, "node_offline");
            send_json(res, 404, {{"error", "Target node is not connected"}});
            return;
        }

        auto node_cli = make_node_mtls_client(*control_url, config_);
        node_cli->set_read_timeout(60, 0);

        nlohmann::json forward = {{"command", command}};
        if (body.contains("sudo_password") && body["sudo_password"].is_string()) {
            forward["sudo_password"] = body["sudo_password"].get<std::string>();
        }

        auto node_res = node_cli->Post("/node/exec", forward.dump(), "application/json");
        db_.append_audit_log(
            "android_portal",
            "console_exec:" + command,
            target_node_id,
            node_res ? "ok" : "transport_error");

        if (!node_res) {
            send_json(res, 502, {{"error", "Failed to reach target mass_node over mTLS"}});
            return;
        }

        res.status = node_res->status;
        res.set_content(node_res->body, "application/json");
    });

    // 3a. Remote Desktop Single Frame Capture
    portal_svr.Get("/v1/desktop/frame", [&](const httplib::Request& req, httplib::Response& res) {
        if (!authenticate_portal(req, res)) return;

        const std::string node_id = req.get_param_value("node_id");
        const std::string quality = req.has_param("quality") ? req.get_param_value("quality") : "65";
        const std::string format  = req.has_param("format") ? req.get_param_value("format") : "json";

        if (node_id.empty()) {
            send_json(res, 400, {{"error", "node_id query parameter is required"}});
            return;
        }

        auto control_url = resolve_node_endpoint(node_id);
        if (!control_url) {
            send_json(res, 404, {{"error", "Target node is not connected"}});
            return;
        }

        auto node_cli = make_node_mtls_client(*control_url, config_);
        node_cli->set_read_timeout(10, 0);

        const std::string path = "/node/desktop/frame?quality=" + quality + "&format=" + format;
        auto node_res = node_cli->Get(path);
        if (!node_res) {
            send_json(res, 502, {{"error", "Failed to capture desktop frame from node over mTLS"}});
            return;
        }

        res.status = node_res->status;
        const std::string ct = node_res->get_header_value("Content-Type");
        res.set_content(node_res->body, ct.empty() ? "application/json" : ct);
    });

        // 3b-H264. Remote Desktop 60 FPS Zero-Latency H.264 Stream Proxy
    portal_svr.Get("/v1/desktop/h264", [&](const httplib::Request& req, httplib::Response& res) {
        if (!authenticate_portal(req, res)) return;

        const std::string node_id = req.get_param_value("node_id");
        const std::string fps     = req.has_param("fps") ? req.get_param_value("fps") : "60";
        const std::string bitrate = req.has_param("bitrate") ? req.get_param_value("bitrate") : "4500";
        const std::string scale   = req.has_param("scale") ? req.get_param_value("scale") : "1920";

        if (node_id.empty()) {
            send_json(res, 400, {{"error", "node_id query parameter is required"}});
            return;
        }
        auto control_url = resolve_node_endpoint(node_id);
        if (!control_url) {
            send_json(res, 404, {{"error", "Target node is not connected"}});
            return;
        }

        const std::string target_url = *control_url;
        const std::string node_path =
            "/node/desktop/h264?fps=" + fps + "&bitrate=" + bitrate + "&scale=" + scale;

        res.set_header("Cache-Control", "no-store, no-cache");
        res.set_chunked_content_provider(
            "application/octet-stream",
            [this, target_url, node_path](size_t, httplib::DataSink& sink) -> bool {
                auto node_cli = make_node_mtls_client(target_url, config_);
                node_cli->set_read_timeout(30, 0);
                node_cli->Get(node_path, [&](const char* data, size_t len) -> bool {
                    if (!sink.is_writable()) return false;
                    return sink.write(data, len);
                });
                sink.done();
                return false;
            });
    });

    // 3b. Remote Desktop 30 FPS Live MJPEG Stream Proxy
    portal_svr.Get("/v1/desktop/stream", [&](const httplib::Request& req, httplib::Response& res) {
        if (!authenticate_portal(req, res)) return;

        const std::string node_id = req.get_param_value("node_id");
        const std::string fps     = req.has_param("fps") ? req.get_param_value("fps") : "30";
        const std::string quality = req.has_param("quality") ? req.get_param_value("quality") : "60";
        const std::string scale   = req.has_param("scale") ? req.get_param_value("scale") : "1280";

        if (node_id.empty()) {
            send_json(res, 400, {{"error", "node_id query parameter is required"}});
            return;
        }

        auto control_url = resolve_node_endpoint(node_id);
        if (!control_url) {
            send_json(res, 404, {{"error", "Target node is not connected"}});
            return;
        }

        const std::string target_url = *control_url;
        const std::string node_path =
            "/node/desktop/stream?fps=" + fps + "&quality=" + quality + "&scale=" + scale;

        res.set_header("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0");
        res.set_header("Pragma", "no-cache");

        res.set_chunked_content_provider(
            "multipart/x-mixed-replace; boundary=massframe",
            [this, target_url, node_path](size_t, httplib::DataSink& sink) -> bool {
                auto node_cli = make_node_mtls_client(target_url, config_);
                node_cli->set_read_timeout(30, 0);
                node_cli->Get(node_path, [&](const char* data, size_t len) -> bool {
                    if (!sink.is_writable()) return false;
                    return sink.write(data, len);
                });
                sink.done();
                return false;
            });
    });

    // 3c. Remote Desktop Touch-to-Mouse/Keyboard Input Forwarding
    portal_svr.Post("/v1/desktop/input", [&](const httplib::Request& req, httplib::Response& res) {
        if (!authenticate_portal(req, res)) return;

        nlohmann::json body;
        try {
            body = nlohmann::json::parse(req.body);
        } catch (...) {
            send_json(res, 400, {{"error", "Invalid JSON"}});
            return;
        }

        const std::string target_node_id = body.value("target_node_id", "");
        if (target_node_id.empty()) {
            send_json(res, 400, {{"error", "target_node_id is required"}});
            return;
        }

        auto control_url = resolve_node_endpoint(target_node_id);
        if (!control_url) {
            send_json(res, 404, {{"error", "Target node is not connected"}});
            return;
        }

        static std::mutex input_cli_mu;
        static std::unordered_map<std::string, decltype(make_node_mtls_client(*control_url, config_))> input_clients;
        std::lock_guard<std::mutex> cli_lock(input_cli_mu);
        auto& node_cli = input_clients[*control_url];
        if (!node_cli) {
            node_cli = make_node_mtls_client(*control_url, config_);
            node_cli->set_keep_alive(true);
            node_cli->set_read_timeout(5, 0);
        }
        auto node_res = node_cli->Post("/node/desktop/input", body.dump(), "application/json");
        if (!node_res) {
            node_cli = make_node_mtls_client(*control_url, config_);
            node_cli->set_keep_alive(true);
            node_cli->set_read_timeout(5, 0);
            node_res = node_cli->Post("/node/desktop/input", body.dump(), "application/json");
        }
        if (!node_res) {
            input_clients.erase(*control_url);
            send_json(res, 502, {{"error", "Failed to forward desktop input to node over mTLS"}});
            return;
        }

        res.status = node_res->status;
        res.set_content(node_res->body, "application/json");
    });

    // 4a. SI / SSA Models (Ollama /api/tags + /api/ps)
    portal_svr.Get("/v1/ssa/models", [&](const httplib::Request& req, httplib::Response& res) {
        if (!authenticate_portal(req, res)) return;

        const auto models = ssa::discover_local_models();
        nlohmann::json arr = nlohmann::json::array();
        for (const auto& m : models) {
            arr.push_back({
                {"id", m.id},
                {"name", m.name},
                {"runtime", m.runtime},
                {"quant", m.quant},
                {"context_window", m.context_window},
                {"running", m.running},
                {"vram_gb", m.vram_gb},
                {"status", m.status}
            });
        }
        send_json(res, 200, {{"models", arr}});
    });

    // 4b. Overthinker-Safe SI / SSA Query (>= 600s timeout, preserves <think>...</think>)
    portal_svr.Post("/v1/ssa/query", [&](const httplib::Request& req, httplib::Response& res) {
        if (!authenticate_portal(req, res)) return;

        nlohmann::json body;
        try {
            body = nlohmann::json::parse(req.body);
        } catch (...) {
            send_json(res, 400, {{"error", "Invalid JSON"}});
            return;
        }

        const std::string model_id = body.value("model_id", "");
        const std::string query    = body.value("query", "");
        std::string scope_node     = "all";
        if (body.contains("scope_node_id") && body["scope_node_id"].is_string()) {
            scope_node = body["scope_node_id"].get<std::string>();
        }

        if (model_id.empty() || query.empty()) {
            send_json(res, 400, {{"error", "model_id and query are required"}});
            return;
        }

        nlohmann::json ctx_arr = nlohmann::json::array();
        {
            std::lock_guard<std::mutex> lock(telemetry_mutex_);
            for (const auto& [nid, snap] : live_telemetry_) {
                if (scope_node == "all" || scope_node == nid) {
                    ctx_arr.push_back({
                        {"node_id", snap.node_id},
                        {"hostname", snap.hostname},
                        {"cpu_percent", snap.cpu_percent},
                        {"cpu_temp_c", snap.cpu_temp_c},
                        {"gpu_name", snap.gpu_name},
                        {"gpu_percent", snap.gpu_percent},
                        {"gpu_temp_c", snap.gpu_temp_c},
                        {"gpu_vram_used_gb", snap.gpu_vram_used_gb},
                        {"gpu_vram_total_gb", snap.gpu_vram_total_gb},
                        {"ram_used_gb", snap.ram_used_gb},
                        {"ram_total_gb", snap.ram_total_gb},
                        {"disk_used_gb", snap.disk_used_gb},
                        {"disk_total_gb", snap.disk_total_gb},
                        {"uptime", snap.uptime},
                        {"os_info", snap.os_info}
                    });
                }
            }
        }

        const auto ssa_res = ssa::query_local_model(model_id, ctx_arr.dump(), query, 900);
        db_.append_audit_log("android_portal", "ssa_query:" + model_id, scope_node, ssa_res.ok ? "ok" : "error");

        if (!ssa_res.ok) {
            send_json(res, 502, {{"error", ssa_res.error}});
            return;
        }
        send_json(res, 200, {
            {"model_id", ssa_res.model_id},
            {"runtime", ssa_res.runtime},
            {"answer", ssa_res.answer}
        });
    });

    // Encrypted SHA-256 File Transfer
    portal_svr.Post("/v1/files/transfer", [&](const httplib::Request& req, httplib::Response& res) {
        if (!authenticate_portal(req, res)) return;

        nlohmann::json body;
        try {
            body = nlohmann::json::parse(req.body);
        } catch (...) {
            send_json(res, 400, {{"error", "Invalid JSON"}});
            return;
        }

        FileTransferRequest xfer{
            body.value("source_node_id", ""),
            body.value("target_node_id", ""),
            body.value("source_path", ""),
            body.value("target_path", ""),
            body.value("expected_sha256", "")
        };

        if (xfer.source_node_id.empty() || xfer.target_node_id.empty() ||
            xfer.source_path.empty() || xfer.target_path.empty()) {
            send_json(res, 400, {{"error", "source_node_id, target_node_id, source_path, target_path required"}});
            return;
        }

        std::unordered_map<std::string, std::string> endpoints_copy;
        {
            std::lock_guard<std::mutex> lock(telemetry_mutex_);
            endpoints_copy = node_control_urls_;
        }

        const auto xfer_res = execute_node_file_transfer(
            xfer, endpoints_copy, config_.ca_cert_path, config_.server_cert_path, config_.server_key_path);

        db_.append_audit_log(
            "android_portal",
            "file_transfer:" + xfer.source_path + "->" + xfer.target_path,
            xfer.target_node_id,
            xfer_res.ok ? "ok" : "failed");

        if (!xfer_res.ok) {
            send_json(res, 502, {{"error", xfer_res.error}});
            return;
        }
        send_json(res, 200, {
            {"status", "completed"},
            {"transfer_id", xfer_res.transfer_id},
            {"sha256", xfer_res.sha256},
            {"bytes_transferred", xfer_res.bytes_transferred}
        });
    });

    // -----------------------------------------------------------------------
    // mTLS Node Coordinator Endpoints (Master :8444 <-> mass_node)
    // -----------------------------------------------------------------------
    node_svr.Post("/internal/nodes/register", [&](const httplib::Request& req, httplib::Response& res) {
        nlohmann::json body;
        try {
            body = nlohmann::json::parse(req.body);
        } catch (...) {
            send_json(res, 400, {{"error", "Invalid JSON"}});
            return;
        }

        storage::NodeRecord node{
            body.value("node_id", ""),
            body.value("hostname", ""),
            body.value("ip", req.remote_addr),
            body.value("role", "server"),
            "online",
            body.value("public_key", "mTLS-X509"),
            ""
        };
        const std::string control_url = body.value("control_url", "");

        if (node.node_id.empty() || node.hostname.empty()) {
            send_json(res, 400, {{"error", "node_id and hostname are required"}});
            return;
        }

        const auto reg = db_.register_or_update_node(node, license_.max_nodes);
        if (reg == storage::NodeRegisterResult::LicenseQuotaExceeded) {
            db_.append_audit_log(node.node_id, "node_register", "master", "rejected_max_nodes");
            send_json(res, 403, {{"error", "License max_nodes quota exceeded"}});
            return;
        }
        if (reg == storage::NodeRegisterResult::DbError) {
            send_json(res, 500, {{"error", "Database error"}});
            return;
        }

        if (!control_url.empty()) {
            std::lock_guard<std::mutex> lock(telemetry_mutex_);
            node_control_urls_[node.node_id] = control_url;
        }

        db_.append_audit_log(node.node_id, "node_register", "master", "ok");
        send_json(res, 200, {{"status", "registered"}, {"max_nodes", license_.max_nodes}});
    });

    node_svr.Post("/internal/nodes/telemetry", [&](const httplib::Request& req, httplib::Response& res) {
        nlohmann::json body;
        try {
            body = nlohmann::json::parse(req.body);
        } catch (...) {
            send_json(res, 400, {{"error", "Invalid JSON"}});
            return;
        }

        NodeTelemetrySnapshot snap;
        snap.node_id           = body.value("node_id", "");
        snap.hostname          = body.value("hostname", "");
        snap.ip                = body.value("ip", req.remote_addr);
        snap.role              = body.value("role", "server");
        snap.cpu_percent       = body.value("cpu_percent", 0.0);
        snap.cpu_temp_c        = body.value("cpu_temp_c", 0.0);
        snap.gpu_percent       = body.value("gpu_percent", 0.0);
        snap.gpu_temp_c        = body.value("gpu_temp_c", 0.0);
        snap.gpu_vram_used_gb  = body.value("gpu_vram_used_gb", 0.0);
        snap.gpu_vram_total_gb = body.value("gpu_vram_total_gb", 0.0);
        snap.gpu_name          = body.value("gpu_name", "N/A");
        snap.ram_used_gb       = body.value("ram_used_gb", 0.0);
        snap.ram_total_gb      = body.value("ram_total_gb", 0.0);
        snap.disk_used_gb      = body.value("disk_used_gb", 0.0);
        snap.disk_total_gb     = body.value("disk_total_gb", 0.0);
        snap.uptime            = body.value("uptime", uint64_t{0});
        snap.os_info           = body.value("os_info", "");
        snap.last_sync         = body.value("last_sync", "");

        if (body.contains("si_status") && body["si_status"].is_object()) {
            const auto& si = body["si_status"];
            snap.si_info.ollama_online          = si.value("ollama_online", false);
            snap.si_info.state                  = si.value("state", "offline");
            snap.si_info.loaded_model           = si.value("loaded_model", "");
            snap.si_info.vram_used_gb           = si.value("vram_used_gb", 0.0);
            snap.si_info.available_models_count = si.value("available_models_count", 0);
            snap.si_info.inference_gpu_percent  = si.value("inference_gpu_percent", 0.0);
            snap.si_info.inference_gpu_temp_c   = si.value("inference_gpu_temp_c", 0.0);
        }

        if (body.contains("gpus") && body["gpus"].is_array()) {
            for (const auto& g : body["gpus"]) {
                snap.gpus.push_back(GpuInfo{
                    g.value("name", "GPU"), g.value("kind", "dedicated"),
                    g.value("util_percent", 0.0), g.value("temp_c", 0.0),
                    g.value("vram_used_gb", 0.0), g.value("vram_total_gb", 0.0)
                });
            }
        }
        if (body.contains("disks") && body["disks"].is_array()) {
            for (const auto& d : body["disks"]) {
                snap.disks.push_back(DiskInfo{
                    d.value("device", ""), d.value("mount", "/"),
                    d.value("used_gb", 0.0), d.value("total_gb", 0.0), d.value("percent", 0.0)
                });
            }
        }
        if (body.contains("network_ports") && body["network_ports"].is_array()) {
            for (const auto& p : body["network_ports"]) {
                snap.network_ports.push_back(PortStatusInfo{
                    p.value("name", ""), p.value("detail", ""), p.value("active", false)
                });
            }
        }

        if (snap.node_id.empty()) {
            send_json(res, 400, {{"error", "node_id required"}});
            return;
        }

        db_.register_or_update_node(
            storage::NodeRecord{snap.node_id, snap.hostname, snap.ip, snap.role, "online", "mTLS-X509", snap.last_sync},
            license_.max_nodes);

        {
            std::lock_guard<std::mutex> lock(telemetry_mutex_);
            if (node_control_urls_.find(snap.node_id) == node_control_urls_.end()) { const std::string ip = (!snap.ip.empty() && snap.ip != "-") ? snap.ip : req.remote_addr; if (!ip.empty()) node_control_urls_[snap.node_id] = "https://" + ip + ":8445"; }
            live_telemetry_[snap.node_id] = std::move(snap);
        }
        send_json(res, 200, {{"status", "ok"}});
    });

    std::atomic<bool> discovery_running{true};
    std::thread discovery_thread;
    if (config_.enable_discovery) {
        discovery_thread = std::thread([&]() {
            run_opt_in_lan_discovery(config_.portal_port, config_.portal_port, discovery_running);
        });
    }

    std::thread node_thread([&]() {
        std::cout << "[MASS Master v2] mTLS Node Coordinator listening on https://"
                  << config_.bind_host << ":" << config_.node_mtls_port << " (TLS 1.3 + mTLS)\n";
        node_svr.listen(config_.bind_host, config_.node_mtls_port);
    });

    std::cout << "[MASS Master v2] Android Portal HTTPS listening on https://"
              << config_.bind_host << ":" << config_.portal_port << " (TLS 1.3 ONLY)\n";
    const bool ok = portal_svr.listen(config_.bind_host, config_.portal_port);

    discovery_running = false;
    node_svr.stop();
    if (node_thread.joinable()) node_thread.join();
    if (discovery_thread.joinable()) discovery_thread.join();
    return ok ? 0 : 1;
}

} // namespace mass::master
