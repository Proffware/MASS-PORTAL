#include "mass/ssa.hpp"

#include <httplib.h>
#include <nlohmann/json.hpp>
#include <unordered_map>

namespace mass::ssa {

std::string format_overthinker_response(
    const std::string& thinking_field,
    const std::string& response_field) {
    // If Ollama returned a separate `thinking` field, wrap it in <think>...</think>
    // unless `response_field` already contains a <think> block.
    if (!thinking_field.empty() && response_field.find("<think>") == std::string::npos) {
        return "<think>\n" + thinking_field + "\n</think>\n" + response_field;
    }
    return response_field;
}

std::vector<LocalModelInfo> discover_local_models() {
    std::vector<LocalModelInfo> models;
    httplib::Client cli("127.0.0.1", 11434);
    cli.set_connection_timeout(1, 0);
    cli.set_read_timeout(3, 0);

    // 1. Query /api/ps to find currently running models and VRAM usage
    std::unordered_map<std::string, double> running_vram_gb;
    if (auto ps_res = cli.Get("/api/ps")) {
        if (ps_res->status == 200) {
            try {
                auto j = nlohmann::json::parse(ps_res->body);
                if (j.contains("models") && j["models"].is_array()) {
                    for (const auto& m : j["models"]) {
                        const std::string name = m.value("name", "");
                        const double vram_bytes = m.value("size_vram", 0.0);
                        if (!name.empty()) {
                            running_vram_gb[name] = vram_bytes / (1024.0 * 1024.0 * 1024.0);
                        }
                    }
                }
            } catch (...) {}
        }
    }

    // 2. Query /api/tags to list all installed Ollama models
    if (auto tags_res = cli.Get("/api/tags")) {
        if (tags_res->status == 200) {
            try {
                auto j = nlohmann::json::parse(tags_res->body);
                if (j.contains("models") && j["models"].is_array()) {
                    for (const auto& m : j["models"]) {
                        LocalModelInfo info;
                        info.id = m.value("name", "ollama-model");
                        info.name = info.id;
                        info.runtime = "Ollama";
                        if (m.contains("details") && m["details"].is_object()) {
                            info.quant = m["details"].value("quantization_level", "unknown");
                        } else {
                            info.quant = "unknown";
                        }
                        info.context_window = 8192;
                        info.endpoint_url = "http://127.0.0.1:11434";
                        if (auto it = running_vram_gb.find(info.id); it != running_vram_gb.end()) {
                            info.running = true;
                            info.vram_gb = it->second;
                            info.status = "running";
                        } else {
                            info.running = false;
                            info.vram_gb = 0.0;
                            info.status = "available";
                        }
                        models.push_back(std::move(info));
                    }
                }
            } catch (...) {}
        }
    }

    return models;
}

SsaQueryResponse query_local_model(
    const std::string& model_id,
    const std::string& telemetry_context_json,
    const std::string& user_query,
    int timeout_seconds) {
    if (model_id.empty()) {
        return {false, "", "Ollama", "", "model_id is required"};
    }

    // Overthinker-safe timeout: enforce at least 600s so low-end GPUs never time out during <think>
    const int effective_timeout = (timeout_seconds < 600) ? 600 : timeout_seconds;

    httplib::Client cli("127.0.0.1", 11434);
    cli.set_connection_timeout(10, 0);
    cli.set_read_timeout(effective_timeout, 0);
    cli.set_write_timeout(effective_timeout, 0);

    const std::string system_prompt =
        "You are MASS System Intelligence (SI), a friendly and helpful assistant. Respond naturally in the user's language to casual greetings or general chat (like naber, merhaba, hi). When asked about servers, hardware, or system status, use this live telemetry:\n" +
        telemetry_context_json;

    nlohmann::json req_body = {
        {"model", model_id},
        {"system", system_prompt},
        {"prompt", user_query},
        {"stream", false}
    };

    if (auto res = cli.Post("/api/generate", req_body.dump(), "application/json")) {
        if (res->status == 200) {
            try {
                auto j = nlohmann::json::parse(res->body);
                const std::string thinking = j.value("thinking", "");
                const std::string response = j.value("response", "");
                const std::string merged = format_overthinker_response(thinking, response);
                return {true, model_id, "Ollama", merged, ""};
            } catch (const std::exception& e) {
                return {false, model_id, "Ollama", "", std::string("JSON parse error: ") + e.what()};
            }
        }
        return {false, model_id, "Ollama", "", "Ollama HTTP " + std::to_string(res->status) + ": " + res->body};
    }

    return {false, model_id, "Ollama", "", "Failed to connect to local Ollama at 127.0.0.1:11434"};
}

} // namespace mass::ssa
