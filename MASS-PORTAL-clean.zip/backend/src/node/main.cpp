#include <iostream>
#include <string>

namespace mass::node {
struct NodeConfig {
    std::string node_id = "node-01";
    std::string role = "workstation";
    std::string master_host = "127.0.0.1";
    int master_mtls_port = 8444;
    std::string listen_host = "0.0.0.0";
    int listen_port = 8445;
    std::string advertised_ip = "127.0.0.1";
    std::string cert_path = "certs/node.crt";
    std::string key_path = "certs/node.key";
    std::string ca_cert_path = "certs/ca.crt";
    int telemetry_interval_sec = 5;
};

int run_node_daemon(const NodeConfig& cfg);
} // namespace mass::node

int main(int argc, char* argv[]) {
    mass::node::NodeConfig cfg;
    for (int i = 1; i < argc; ++i) {
        const std::string arg = argv[i];
        auto next = [&]() -> std::string {
            return (i + 1 < argc) ? std::string(argv[++i]) : "";
        };
        if (arg == "--node-id") cfg.node_id = next();
        else if (arg == "--role") cfg.role = next();
        else if (arg == "--master-host") cfg.master_host = next();
        else if (arg == "--master-port") cfg.master_mtls_port = std::stoi(next());
        else if (arg == "--port") cfg.listen_port = std::stoi(next());
        else if (arg == "--ip") cfg.advertised_ip = next();
        else if (arg == "--cert") cfg.cert_path = next();
        else if (arg == "--key") cfg.key_path = next();
        else if (arg == "--ca") cfg.ca_cert_path = next();
    }
    return mass::node::run_node_daemon(cfg);
}
