#include "mass/crypto.hpp"
#include "mass/master_server.hpp"
#include "mass/remote_desktop.hpp"
#include "mass/shell_session.hpp"

#include <algorithm>
#include <atomic>
#include <chrono>
#include <fstream>
#include <httplib.h>
#include <iostream>
#include <nlohmann/json.hpp>
#include <openssl/err.h>
#include <openssl/ssl.h>
#include <thread>

namespace mass::node {

master::NodeTelemetrySnapshot collect_local_telemetry(
    const std::string& node_id,
    const std::string& role,
    const std::string& advertised_ip);

struct NodeConfig {
    std::string node_id = "node-01";
    std::string role = "server";
    std::string master_host = "127.0.0.1";
    int master_mtls_port = 8444;
    std::string listen_host = "0.0.0.0";
    int listen_port = 8445;
    std::string advertised_ip = "127.0.0.1";
    std::string cert_path = "certs/node.crt";
    std::string key_path = "certs/node.key";
    std::string ca_cert_path = "certs/ca.crt";
    int telemetry_interval_sec = 5;
};

int run_node_daemon(const NodeConfig& cfg) {
    ShellSession shell_session;

    // 1. Local mTLS control server on :8445 (Master -> Node)
    httplib::SSLServer node_svr(cfg.cert_path.c_str(), cfg.key_path.c_str(), cfg.ca_cert_path.c_str());
    if (!node_svr.is_valid()) {
        std::cerr << "[MASS Node v2] Failed to start mTLS listener. Check certs:\n"
                  << "  cert=" << cfg.cert_path << " key=" << cfg.key_path << " ca=" << cfg.ca_cert_path << "\n";
        ERR_print_errors_fp(stderr);
        return 1;
    }
    if (SSL_CTX* ctx = node_svr.ssl_context()) {
        SSL_CTX_set_min_proto_version(ctx, TLS1_2_VERSION);
        SSL_CTX_set_verify(ctx, SSL_VERIFY_PEER | SSL_VERIFY_FAIL_IF_NO_PEER_CERT, nullptr);
    }

    // Remote Shell with persistent cwd & interactive sudo
    node_svr.set_keep_alive_max_count(10000);
    node_svr.set_keep_alive_timeout(30);
    node_svr.Post("/node/exec", [&](const httplib::Request& req, httplib::Response& res) {
        nlohmann::json body;
        try {
            body = nlohmann::json::parse(req.body);
        } catch (...) {
            res.status = 400;
            res.set_content(R"({"error":"Invalid JSON"})", "application/json");
            return;
        }
        const std::string cmd = body.value("command", "");
        std::optional<std::string> sudo_pw;
        if (body.contains("sudo_password") && body["sudo_password"].is_string()) {
            sudo_pw = body["sudo_password"].get<std::string>();
        }

        const auto exec_res = shell_session.execute(cmd, sudo_pw);
        if (!exec_res.ok) {
            res.status = 400;
            res.set_content(nlohmann::json({{"error", exec_res.error}}).dump(), "application/json");
            return;
        }
        if (exec_res.requires_password) {
            res.status = 200;
            res.set_content(nlohmann::json({
                {"requires_password", true},
                {"prompt", exec_res.prompt},
                {"cwd", exec_res.cwd}
            }).dump(), "application/json");
            return;
        }

        res.status = 200;
        res.set_content(nlohmann::json({
            {"requires_password", false},
            {"exit_code", exec_res.exit_code},
            {"cwd", exec_res.cwd},
            {"output", exec_res.output}
        }).dump(), "application/json");
    });

    // Remote Desktop Single Frame Capture
    node_svr.Get("/node/desktop/frame", [](const httplib::Request& req, httplib::Response& res) {
        int quality = 65;
        if (req.has_param("quality")) {
            try { quality = std::stoi(req.get_param_value("quality")); } catch (...) {}
        }
        const std::string format = req.has_param("format") ? req.get_param_value("format") : "json";

        const auto frame = capture_desktop_jpeg(quality);
        if (!frame.ok) {
            res.status = 500;
            res.set_content(nlohmann::json({{"error", frame.error}}).dump(), "application/json");
            return;
        }

        if (format == "jpeg" || format == "raw") {
            res.status = 200;
            res.set_content(
                reinterpret_cast<const char*>(frame.jpeg_bytes.data()),
                frame.jpeg_bytes.size(),
                "image/jpeg");
            return;
        }

        res.status = 200;
        res.set_content(nlohmann::json({
            {"width", frame.width},
            {"height", frame.height},
            {"frame_b64", crypto::base64_encode(frame.jpeg_bytes)}
        }).dump(), "application/json");
    });

        // Remote Desktop 60 FPS Hardware-Friendly H.264 Annex-B Stream
    node_svr.Get("/node/desktop/h264", [](const httplib::Request& req, httplib::Response& res) {
        int fps = 60;
        int bitrate = 4500;
        int max_width = 1920;
        if (req.has_param("fps")) { try { fps = std::stoi(req.get_param_value("fps")); } catch (...) {} }
        if (req.has_param("bitrate")) { try { bitrate = std::stoi(req.get_param_value("bitrate")); } catch (...) {} }
        if (req.has_param("scale")) { try { max_width = std::stoi(req.get_param_value("scale")); } catch (...) {} }

        res.set_header("Cache-Control", "no-store, no-cache");
        res.set_chunked_content_provider(
            "application/octet-stream",
            [fps, bitrate, max_width](size_t, httplib::DataSink& sink) -> bool {
                stream_desktop_h264(fps, bitrate, max_width, [&](const uint8_t* data, std::size_t len) -> bool {
                    if (!sink.is_writable()) return false;
                    return sink.write(reinterpret_cast<const char*>(data), len);
                });
                sink.done();
                return false;
            });
    });

    // Remote Desktop 30 FPS Live MJPEG Stream (zero disk I/O via ffmpeg pipe:1)
    node_svr.Get("/node/desktop/stream", [](const httplib::Request& req, httplib::Response& res) {
        int fps = 30;
        int quality = 60;
        int max_width = 1280;
        if (req.has_param("fps")) {
            try { fps = std::stoi(req.get_param_value("fps")); } catch (...) {}
        }
        if (req.has_param("quality")) {
            try { quality = std::stoi(req.get_param_value("quality")); } catch (...) {}
        }
        if (req.has_param("scale")) {
            try { max_width = std::stoi(req.get_param_value("scale")); } catch (...) {}
        }

        res.set_header("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0");
        res.set_header("Pragma", "no-cache");

        res.set_chunked_content_provider(
            "multipart/x-mixed-replace; boundary=massframe",
            [fps, quality, max_width](size_t, httplib::DataSink& sink) -> bool {
                stream_desktop_mjpeg(fps, quality, max_width, [&](const std::vector<uint8_t>& jpeg) -> bool {
                    if (!sink.is_writable()) return false;
                    const std::string header =
                        "--massframe\r\n"
                        "Content-Type: image/jpeg\r\n"
                        "Content-Length: " + std::to_string(jpeg.size()) + "\r\n\r\n";
                    if (!sink.write(header.data(), header.size())) return false;
                    if (!sink.write(reinterpret_cast<const char*>(jpeg.data()), jpeg.size())) return false;
                    if (!sink.write("\r\n", 2)) return false;
                    return true;
                });
                sink.done();
                return false;
            });
    });

    // Remote Desktop Touch-to-Mouse/Keyboard Input
    node_svr.Post("/node/desktop/input", [](const httplib::Request& req, httplib::Response& res) {
        nlohmann::json body;
        try {
            body = nlohmann::json::parse(req.body);
        } catch (...) {
            res.status = 400;
            res.set_content(R"({"error":"Invalid JSON"})", "application/json");
            return;
        }

        DesktopInputEvent ev;
        ev.type    = body.value("type", "");
        ev.x_norm  = body.value("x_norm", 0.0);
        ev.y_norm  = body.value("y_norm", 0.0);
        ev.button  = body.value("button", 1);
        ev.delta_y = body.value("delta_y", 0);
        ev.key     = body.value("key", "");
        ev.text    = body.value("text", "");

        const auto r = inject_desktop_input(ev);
        res.status = r.ok ? 200 : 500;
        res.set_content(nlohmann::json({
            {"ok", r.ok},
            {"mapped_x", r.mapped_x},
            {"mapped_y", r.mapped_y},
            {"backend", r.backend},
            {"error", r.error}
        }).dump(), "application/json");
    });

    // Encrypted SHA-256 File Transfer handlers
    node_svr.Post("/node/files/read", [](const httplib::Request& req, httplib::Response& res) {
        nlohmann::json body;
        try { body = nlohmann::json::parse(req.body); } catch (...) { res.status = 400; return; }
        const std::string path = body.value("path", "");
        std::ifstream ifs(path, std::ios::binary);
        if (!ifs.is_open()) {
            res.status = 404;
            res.set_content(R"({"error":"File not found"})", "application/json");
            return;
        }
        std::vector<uint8_t> bytes((std::istreambuf_iterator<char>(ifs)), std::istreambuf_iterator<char>());
        res.status = 200;
        res.set_content(nlohmann::json({
            {"content_b64", crypto::base64_encode(bytes)},
            {"sha256", crypto::sha256_hex(bytes)}
        }).dump(), "application/json");
    });

    node_svr.Post("/node/files/write", [](const httplib::Request& req, httplib::Response& res) {
        nlohmann::json body;
        try { body = nlohmann::json::parse(req.body); } catch (...) { res.status = 400; return; }
        const std::string path = body.value("path", "");
        const std::string b64  = body.value("content_b64", "");
        const std::string expected_sha = body.value("sha256", "");

        auto bytes = crypto::base64_decode(b64);
        if (!bytes || crypto::sha256_hex(*bytes) != expected_sha) {
            res.status = 400;
            res.set_content(R"({"error":"Invalid payload or SHA-256 mismatch"})", "application/json");
            return;
        }
        std::ofstream ofs(path, std::ios::binary | std::ios::trunc);
        if (!ofs.is_open()) {
            res.status = 500;
            res.set_content(R"({"error":"Cannot write destination file"})", "application/json");
            return;
        }
        ofs.write(reinterpret_cast<const char*>(bytes->data()), static_cast<std::streamsize>(bytes->size()));
        res.status = 200;
        res.set_content(nlohmann::json({{"status", "written"}, {"sha256", expected_sha}}).dump(), "application/json");
    });

    // 2. 5s Telemetry Pulse + Exponential Backoff Auto-Reconnect Loop
    std::atomic<bool> running{true};
    std::thread telemetry_thread([&]() {
        bool registered = false;
        int backoff_sec = 1;
        constexpr int kMaxBackoffSec = 30;

        while (running.load()) {
            httplib::SSLClient master_cli(
                cfg.master_host, cfg.master_mtls_port, cfg.cert_path, cfg.key_path);
            master_cli.set_ca_cert_path(cfg.ca_cert_path);
            master_cli.enable_server_certificate_verification(true);
            master_cli.set_connection_timeout(3, 0);
            master_cli.set_read_timeout(5, 0);

            const auto snap = collect_local_telemetry(cfg.node_id, cfg.role, cfg.advertised_ip);

            if (!registered) {
                nlohmann::json reg_body = {
                    {"node_id", cfg.node_id},
                    {"hostname", snap.hostname},
                    {"ip", cfg.advertised_ip},
                    {"role", cfg.role},
                    {"public_key", "mTLS-X509"},
                    {"control_url", "https://" + cfg.advertised_ip + ":" + std::to_string(cfg.listen_port)}
                };
                auto reg_res = master_cli.Post("/internal/nodes/register", reg_body.dump(), "application/json");
                if (reg_res && reg_res->status == 200) {
                    registered = true;
                    backoff_sec = 1;
                    std::cout << "[MASS Node v2] Connected & registered with Master as " << cfg.node_id << "\n";
                } else {
                    std::cerr << "[MASS Node v2] Master mTLS unreachable ("
                              << (reg_res ? ("HTTP " + std::to_string(reg_res->status)) : httplib::to_string(reg_res.error()))
                              << "), retrying in " << backoff_sec << "s...\n";
                    std::this_thread::sleep_for(std::chrono::seconds(backoff_sec));
                    backoff_sec = std::min(backoff_sec * 2, kMaxBackoffSec);
                    continue;
                }
            }

            nlohmann::json tel = {
                {"node_id", snap.node_id},
                {"hostname", snap.hostname},
                {"ip", snap.ip},
                {"role", snap.role},
                {"cpu_percent", snap.cpu_percent},
                {"cpu_temp_c", snap.cpu_temp_c},
                {"gpu_percent", snap.gpu_percent},
                {"gpu_temp_c", snap.gpu_temp_c},
                {"gpu_vram_used_gb", snap.gpu_vram_used_gb},
                {"gpu_vram_total_gb", snap.gpu_vram_total_gb},
                {"gpu_name", snap.gpu_name},
                {"ram_used_gb", snap.ram_used_gb},
                {"ram_total_gb", snap.ram_total_gb},
                {"disk_used_gb", snap.disk_used_gb},
                {"disk_total_gb", snap.disk_total_gb},
                {"uptime", snap.uptime},
                {"os_info", snap.os_info},
                {"last_sync", snap.last_sync},
                {"si_status", {
                    {"ollama_online", snap.si_info.ollama_online},
                    {"state", snap.si_info.state},
                    {"loaded_model", snap.si_info.loaded_model},
                    {"vram_used_gb", snap.si_info.vram_used_gb},
                    {"available_models_count", snap.si_info.available_models_count},
                    {"inference_gpu_percent", snap.si_info.inference_gpu_percent},
                    {"inference_gpu_temp_c", snap.si_info.inference_gpu_temp_c}
                }}
            };

            nlohmann::json gpus_j = nlohmann::json::array();
            for (const auto& g : snap.gpus) {
                gpus_j.push_back({
                    {"name", g.name}, {"kind", g.kind}, {"util_percent", g.util_percent},
                    {"temp_c", g.temp_c}, {"vram_used_gb", g.vram_used_gb}, {"vram_total_gb", g.vram_total_gb}
                });
            }
            nlohmann::json disks_j = nlohmann::json::array();
            for (const auto& d : snap.disks) {
                disks_j.push_back({
                    {"device", d.device}, {"mount", d.mount}, {"used_gb", d.used_gb},
                    {"total_gb", d.total_gb}, {"percent", d.percent}
                });
            }
            nlohmann::json ports_j = nlohmann::json::array();
            for (const auto& p : snap.network_ports) {
                ports_j.push_back({{"name", p.name}, {"detail", p.detail}, {"active", p.active}});
            }
            tel["gpus"] = std::move(gpus_j);
            tel["disks"] = std::move(disks_j);
            tel["network_ports"] = std::move(ports_j);

            auto tel_res = master_cli.Post("/internal/nodes/telemetry", tel.dump(), "application/json");
            if (!tel_res || tel_res->status != 200) {
                std::cerr << "[MASS Node v2] Telemetry push failed ("
                          << (tel_res ? ("HTTP " + std::to_string(tel_res->status)) : httplib::to_string(tel_res.error()))
                          << "); triggering auto-reconnect (backoff " << backoff_sec << "s)...\n";
                registered = false;
                std::this_thread::sleep_for(std::chrono::seconds(backoff_sec));
                backoff_sec = std::min(backoff_sec * 2, kMaxBackoffSec);
                continue;
            }

            backoff_sec = 1;
            std::this_thread::sleep_for(std::chrono::seconds(cfg.telemetry_interval_sec));
        }
    });

    std::cout << "[MASS Node v2] mTLS Control Listener on https://"
              << cfg.listen_host << ":" << cfg.listen_port << "\n";
    const bool ok = node_svr.listen(cfg.listen_host, cfg.listen_port);
    running = false;
    if (telemetry_thread.joinable()) telemetry_thread.join();
    return ok ? 0 : 1;
}

} // namespace mass::node
