#include "mass/remote_desktop.hpp"

#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <mutex>
#include <regex>
#include <sstream>
#include <thread>

#ifndef _WIN32
#include <signal.h>
#include <sys/wait.h>
#include <unistd.h>
#endif

namespace mass::node {

namespace {

bool command_exists(const std::string& bin) {
#ifdef _WIN32
    (void)bin;
    return false;
#else
    const std::string cmd = "command -v " + bin + " >/dev/null 2>&1";
    return std::system(cmd.c_str()) == 0;
#endif
}

bool is_wayland_session() {
    static const bool wl = []() {
        const char* v = std::getenv("WAYLAND_DISPLAY");
        return v != nullptr && v[0] != '\0';
    }();
    return wl;
}

std::string run_capture_stdout(const std::string& cmd) {
#ifdef _WIN32
    (void)cmd;
    return {};
#else
    FILE* pipe = popen(cmd.c_str(), "r");
    if (!pipe) return {};
    std::string out;
    std::array<char, 512> buf{};
    while (fgets(buf.data(), static_cast<int>(buf.size()), pipe) != nullptr) {
        out += buf.data();
    }
    pclose(pipe);
    return out;
#endif
}

std::string shell_single_quote(const std::string& s) {
    std::string out = "'";
    for (char c : s) {
        if (c == '\'') out += "'\\''";
        else out.push_back(c);
    }
    out += "'";
    return out;
}

#ifndef _WIN32
// Persistent `xdotool -` stdin pipe: executes mousemove/click/scroll/key in ~0.2ms
// instead of spawning a new shell + xdotool process (~80ms) on every touch event!
class PersistentXdotool {
public:
    bool send_line(const std::string& line) {
        std::lock_guard<std::mutex> lock(mu_);
        if (!pipe_) {
            pipe_ = popen("xdotool - >/dev/null 2>&1", "w");
            if (!pipe_) return false;
            setvbuf(pipe_, nullptr, _IONBF, 0);
        }
        const std::string payload = line + "\n";
        if (fwrite(payload.data(), 1, payload.size(), pipe_) != payload.size() ||
            fflush(pipe_) != 0) {
            pclose(pipe_);
            pipe_ = popen("xdotool - >/dev/null 2>&1", "w");
            if (!pipe_) return false;
            setvbuf(pipe_, nullptr, _IONBF, 0);
            return fwrite(payload.data(), 1, payload.size(), pipe_) == payload.size() &&
                   fflush(pipe_) == 0;
        }
        return true;
    }

    ~PersistentXdotool() {
        if (pipe_) pclose(pipe_);
    }

private:
    std::mutex mu_;
    FILE* pipe_ = nullptr;
};

PersistentXdotool& xdotool_pipe() {
    static PersistentXdotool instance;
    return instance;
}
#endif

} // namespace

std::pair<int, int> map_normalized_coords(double x_norm, double y_norm, int screen_w, int screen_h) {
    const double cx = std::clamp(x_norm, 0.0, 1.0);
    const double cy = std::clamp(y_norm, 0.0, 1.0);
    const int x = static_cast<int>(std::lround(cx * static_cast<double>(std::max(1, screen_w - 1))));
    const int y = static_cast<int>(std::lround(cy * static_cast<double>(std::max(1, screen_h - 1))));
    return {x, y};
}

std::pair<int, int> detect_screen_resolution() {
    static std::mutex res_mu;
    static std::pair<int, int> cached{0, 0};
    static auto last_check = std::chrono::steady_clock::time_point{};

    std::lock_guard<std::mutex> lock(res_mu);
    const auto now = std::chrono::steady_clock::now();
    if (cached.first > 0 && (now - last_check) < std::chrono::seconds(30)) {
        return cached;
    }

    const std::string xrandr_out = run_capture_stdout("xrandr --current 2>/dev/null | grep '\\*'");
    static const std::regex res_re(R"((\d{3,5})x(\d{3,5}))");
    std::smatch m;
    if (std::regex_search(xrandr_out, m, res_re)) {
        cached = {std::stoi(m[1].str()), std::stoi(m[2].str())};
        last_check = now;
        return cached;
    }

    const std::string wlr_out = run_capture_stdout("wlr-randr 2>/dev/null | grep 'current'");
    if (std::regex_search(wlr_out, m, res_re)) {
        cached = {std::stoi(m[1].str()), std::stoi(m[2].str())};
        last_check = now;
        return cached;
    }

    cached = {1920, 1080};
    last_check = now;
    return cached;
}

std::vector<std::vector<uint8_t>> extract_jpeg_frames_from_buffer(std::vector<uint8_t>& buffer) {
    std::vector<std::vector<uint8_t>> frames;
    std::size_t pos = 0;

    while (pos + 3 < buffer.size()) {
        std::size_t soi = std::string::npos;
        for (std::size_t i = pos; i + 1 < buffer.size(); ++i) {
            if (buffer[i] == 0xFF && buffer[i + 1] == 0xD8) {
                soi = i;
                break;
            }
        }
        if (soi == std::string::npos) {
            if (!buffer.empty() && buffer.back() == 0xFF) {
                buffer.assign({0xFF});
            } else {
                buffer.clear();
            }
            return frames;
        }

        std::size_t eoi = std::string::npos;
        for (std::size_t i = soi + 2; i + 1 < buffer.size(); ++i) {
            if (buffer[i] == 0xFF && buffer[i + 1] == 0xD9) {
                eoi = i + 2;
                break;
            }
        }
        if (eoi == std::string::npos) {
            if (soi > 0) {
                buffer.erase(buffer.begin(), buffer.begin() + static_cast<std::ptrdiff_t>(soi));
            }
            return frames;
        }

        frames.emplace_back(
            buffer.begin() + static_cast<std::ptrdiff_t>(soi),
            buffer.begin() + static_cast<std::ptrdiff_t>(eoi));
        pos = eoi;
    }

    if (pos > 0) {
        buffer.erase(buffer.begin(), buffer.begin() + static_cast<std::ptrdiff_t>(pos));
    }
    return frames;
}

DesktopFrame capture_desktop_jpeg(int quality) {
    DesktopFrame frame;
    const int q = std::clamp(quality, 10, 100);
    const auto [w, h] = detect_screen_resolution();
    frame.width = w;
    frame.height = h;

#ifdef _WIN32
    frame.error = "Remote desktop capture is supported on Linux X11/Wayland nodes";
    return frame;
#else
    const auto tmp_path = std::filesystem::temp_directory_path() /
                          ("mass_frame_" + std::to_string(getpid()) + ".jpg");
    std::error_code ec;
    std::filesystem::remove(tmp_path, ec);

    std::string cmd;
    if (is_wayland_session() && command_exists("grim")) {
        cmd = "grim -t jpeg -q " + std::to_string(q) + " " + shell_single_quote(tmp_path.string()) + " 2>/dev/null";
    } else if (command_exists("ffmpeg")) {
        const char* disp = std::getenv("DISPLAY");
        const std::string display = (disp && disp[0]) ? std::string(disp) : ":0.0";
        const int qv = std::clamp(31 - (q * 29 / 100), 2, 31);
        cmd = "ffmpeg -y -loglevel quiet -f x11grab -video_size " + std::to_string(w) + "x" + std::to_string(h) +
              " -i " + display + " -frames:v 1 -q:v " + std::to_string(qv) + " " +
              shell_single_quote(tmp_path.string()) + " 2>/dev/null";
    } else if (command_exists("scrot")) {
        cmd = "scrot -q " + std::to_string(q) + " -o " + shell_single_quote(tmp_path.string()) + " 2>/dev/null";
    } else {
        frame.error = "No supported screen capture tool found (install ffmpeg, grim, or scrot)";
        return frame;
    }

    if (std::system(cmd.c_str()) != 0 || !std::filesystem::exists(tmp_path, ec)) {
        frame.error = "Screen capture command failed (check DISPLAY / WAYLAND_DISPLAY)";
        return frame;
    }

    std::ifstream ifs(tmp_path, std::ios::binary);
    if (!ifs.is_open()) {
        frame.error = "Failed to read captured JPEG frame";
        return frame;
    }
    frame.jpeg_bytes.assign(std::istreambuf_iterator<char>(ifs), std::istreambuf_iterator<char>());
    std::filesystem::remove(tmp_path, ec);

    frame.ok = !frame.jpeg_bytes.empty();
    if (!frame.ok) frame.error = "Captured JPEG frame was empty";
    return frame;
#endif
}

void stream_desktop_h264(
    int fps,
    int bitrate_kbps,
    int max_width,
    const std::function<bool(const uint8_t*, std::size_t)>& on_chunk) {
#ifdef _WIN32
    (void)fps; (void)bitrate_kbps; (void)max_width; (void)on_chunk;
    return;
#else
    const int target_fps = std::clamp(fps, 15, 60);
    const int kbps = std::clamp(bitrate_kbps, 1000, 40000);
    const auto [w, h] = detect_screen_resolution();
    if (is_wayland_session() || !command_exists("ffmpeg")) return;

    const char* disp = std::getenv("DISPLAY");
    const std::string display = (disp && disp[0]) ? std::string(disp) : ":0.0";
    const std::string size_arg = std::to_string(w) + "x" + std::to_string(h);
    const std::string fps_arg = std::to_string(target_fps);
    const std::string gop_arg = std::to_string(target_fps);
    const std::string bv_arg = std::to_string(kbps) + "k";
    const std::string maxrate_arg = std::to_string(kbps + kbps / 3) + "k";
    const std::string bufsize_arg = std::to_string(kbps) + "k";
    const std::string scale_filter = (max_width > 0 && w > max_width)
        ? ("scale=" + std::to_string(max_width) + ":-2")
        : "null";

    int pipefd[2] = {-1, -1};
    if (pipe(pipefd) != 0) return;

    const pid_t pid = fork();
    if (pid == 0) {
        dup2(pipefd[1], STDOUT_FILENO);
        close(pipefd[0]);
        close(pipefd[1]);
        execlp("ffmpeg", "ffmpeg",
               "-loglevel", "quiet",
               "-fflags", "nobuffer",
               "-flags", "low_delay",
               "-probesize", "32",
               "-f", "x11grab",
               "-framerate", fps_arg.c_str(),
               "-video_size", size_arg.c_str(),
               "-i", display.c_str(),
               "-vf", scale_filter.c_str(),
               "-c:v", "libx264",
               "-preset", "ultrafast",
               "-tune", "zerolatency",
               "-profile:v", "baseline",
               "-pix_fmt", "yuv420p",
               "-g", gop_arg.c_str(),
               "-keyint_min", gop_arg.c_str(),
               "-b:v", bv_arg.c_str(),
               "-maxrate", maxrate_arg.c_str(),
               "-bufsize", bufsize_arg.c_str(),
               "-f", "h264",
               "pipe:1",
               static_cast<char*>(nullptr));
        _exit(127);
    }

    close(pipefd[1]);
    if (pid < 0) {
        close(pipefd[0]);
        return;
    }

    std::array<uint8_t, 16384> chunk{};
    while (true) {
        const ssize_t n = read(pipefd[0], chunk.data(), chunk.size());
        if (n <= 0) break;
        if (!on_chunk(chunk.data(), static_cast<std::size_t>(n))) break;
    }

    close(pipefd[0]);
    kill(pid, SIGTERM);
    int status = 0;
    waitpid(pid, &status, 0);
#endif
}

void stream_desktop_mjpeg(
    int fps,
    int quality,
    int max_width,
    const std::function<bool(const std::vector<uint8_t>&)>& on_frame) {
#ifdef _WIN32
    (void)fps; (void)quality; (void)max_width; (void)on_frame;
    return;
#else
    const int target_fps = std::clamp(fps, 1, 60);
    const int q = std::clamp(quality, 10, 100);
    const int qv = std::clamp(31 - (q * 29 / 100), 2, 31);
    const auto [w, h] = detect_screen_resolution();

    // Ultra-low-latency ffmpeg x11grab -> MJPEG pipe:1 (-fflags nobuffer -flags low_delay)
    if (!is_wayland_session() && command_exists("ffmpeg")) {
        const char* disp = std::getenv("DISPLAY");
        const std::string display = (disp && disp[0]) ? std::string(disp) : ":0.0";
        const std::string size_arg = std::to_string(w) + "x" + std::to_string(h);
        const std::string fps_arg = std::to_string(target_fps);
        const std::string qv_arg = std::to_string(qv);
        const std::string scale_filter = (max_width > 0 && w > max_width)
            ? ("scale=" + std::to_string(max_width) + ":-2")
            : "null";

        int pipefd[2] = {-1, -1};
        if (pipe(pipefd) != 0) return;

        const pid_t pid = fork();
        if (pid == 0) {
            dup2(pipefd[1], STDOUT_FILENO);
            close(pipefd[0]);
            close(pipefd[1]);
            execlp("ffmpeg", "ffmpeg",
                   "-loglevel", "quiet",
                   "-fflags", "nobuffer",
                   "-flags", "low_delay",
                   "-probesize", "32",
                   "-f", "x11grab",
                   "-framerate", fps_arg.c_str(),
                   "-video_size", size_arg.c_str(),
                   "-i", display.c_str(),
                   "-vf", scale_filter.c_str(),
                   "-f", "mjpeg",
                   "-q:v", qv_arg.c_str(),
                   "pipe:1",
                   static_cast<char*>(nullptr));
            _exit(127);
        }

        close(pipefd[1]);
        if (pid < 0) {
            close(pipefd[0]);
            return;
        }

        std::vector<uint8_t> accum;
        accum.reserve(512 * 1024);
        std::array<uint8_t, 65536> chunk{};
        bool keep_going = true;

        while (keep_going) {
            const ssize_t n = read(pipefd[0], chunk.data(), chunk.size());
            if (n <= 0) break;
            accum.insert(accum.end(), chunk.begin(), chunk.begin() + n);

            auto frames = extract_jpeg_frames_from_buffer(accum);
            if (!frames.empty()) {
                // Only emit the newest frame if multiple arrived in one read burst (zero lag!)
                if (!on_frame(frames.back())) {
                    keep_going = false;
                    break;
                }
            }
            if (accum.size() > 8 * 1024 * 1024) {
                accum.clear();
            }
        }

        close(pipefd[0]);
        kill(pid, SIGTERM);
        int status = 0;
        waitpid(pid, &status, 0);
        return;
    }

    const auto frame_period = std::chrono::milliseconds(1000 / target_fps);
    while (true) {
        const auto t0 = std::chrono::steady_clock::now();
        const auto f = capture_desktop_jpeg(q);
        if (!f.ok || !on_frame(f.jpeg_bytes)) {
            break;
        }
        const auto elapsed = std::chrono::steady_clock::now() - t0;
        if (elapsed < frame_period) {
            std::this_thread::sleep_for(frame_period - elapsed);
        }
    }
#endif
}

DesktopInputResult inject_desktop_input(const DesktopInputEvent& ev) {
    DesktopInputResult res;
    const auto [w, h] = detect_screen_resolution();
    const auto [x, y] = map_normalized_coords(ev.x_norm, ev.y_norm, w, h);
    res.mapped_x = x;
    res.mapped_y = y;

#ifdef _WIN32
    res.error = "Desktop input injection is supported on Linux X11/Wayland nodes";
    return res;
#else
    static const bool has_xdotool = command_exists("xdotool");
    static const bool has_ydotool = command_exists("ydotool");
    static const bool has_wtype   = command_exists("wtype");

    // Fast path: persistent `xdotool -` pipe (~0.2ms per event, zero fork/exec lag!)
    if (!is_wayland_session() && has_xdotool) {
        res.backend = "xdotool-pipe";
        std::string line;
        if (ev.type == "move" || ev.type == "drag_move") {
            line = "mousemove " + std::to_string(x) + " " + std::to_string(y);
        } else if (ev.type == "click") {
            line = "mousemove " + std::to_string(x) + " " + std::to_string(y) +
                   " click " + std::to_string(ev.button > 0 ? ev.button : 1);
        } else if (ev.type == "double_click") {
            line = "mousemove " + std::to_string(x) + " " + std::to_string(y) +
                   " click --repeat 2 --delay 60 1";
        } else if (ev.type == "right_click") {
            line = "mousemove " + std::to_string(x) + " " + std::to_string(y) + " click 3";
        } else if (ev.type == "drag_start") {
            line = "mousemove " + std::to_string(x) + " " + std::to_string(y) + " mousedown 1";
        } else if (ev.type == "drag_end") {
            line = "mousemove " + std::to_string(x) + " " + std::to_string(y) + " mouseup 1";
        } else if (ev.type == "scroll") {
            const int btn = (ev.delta_y >= 0) ? 4 : 5;
            const int steps = std::clamp(std::abs(ev.delta_y), 1, 10);
            line = "mousemove " + std::to_string(x) + " " + std::to_string(y) +
                   " click --repeat " + std::to_string(steps) + " --delay 10 " + std::to_string(btn);
        } else if (ev.type == "key" && !ev.key.empty()) {
            std::string k = ev.key;
            if (k == "Ctrl+C") k = "ctrl+c";
            else if (k == "Super") k = "Super_L";
            line = "key " + k;
        } else if (ev.type == "text" && !ev.text.empty()) {
            // Text typing uses single-shot xdotool to safely handle arbitrary unicode/quotes
            const std::string cmd =
                "xdotool type --clearmodifiers --delay 5 -- " + shell_single_quote(ev.text) + " >/dev/null 2>&1";
            res.ok = (std::system(cmd.c_str()) == 0);
            if (!res.ok) res.error = "xdotool type failed";
            return res;
        } else {
            res.error = "Unsupported input event type: " + ev.type;
            return res;
        }

        res.ok = xdotool_pipe().send_line(line);
        if (!res.ok) res.error = "Persistent xdotool pipe write failed";
        return res;
    }

    // Wayland fallback
    if (has_ydotool || has_wtype) {
        std::string cmd;
        if (ev.type == "text" && !ev.text.empty() && has_wtype) {
            res.backend = "wtype";
            cmd = "wtype -- " + shell_single_quote(ev.text);
        } else if (has_ydotool) {
            res.backend = "ydotool";
            if (ev.type == "move" || ev.type == "drag_move") {
                cmd = "ydotool mousemove --absolute -x " + std::to_string(x) + " -y " + std::to_string(y);
            } else if (ev.type == "click") {
                cmd = "ydotool mousemove --absolute -x " + std::to_string(x) + " -y " + std::to_string(y) +
                      " && ydotool click 0xC0";
            } else if (ev.type == "double_click") {
                cmd = "ydotool mousemove --absolute -x " + std::to_string(x) + " -y " + std::to_string(y) +
                      " && ydotool click --repeat 2 0xC0";
            } else if (ev.type == "right_click") {
                cmd = "ydotool mousemove --absolute -x " + std::to_string(x) + " -y " + std::to_string(y) +
                      " && ydotool click 0xC1";
            } else if (ev.type == "drag_start") {
                cmd = "ydotool mousemove --absolute -x " + std::to_string(x) + " -y " + std::to_string(y) +
                      " && ydotool click 0x40";
            } else if (ev.type == "drag_end") {
                cmd = "ydotool mousemove --absolute -x " + std::to_string(x) + " -y " + std::to_string(y) +
                      " && ydotool click 0x80";
            } else if (ev.type == "scroll") {
                cmd = "ydotool mousemove -w -- 0 " + std::to_string(ev.delta_y);
            } else if (ev.type == "text" && !ev.text.empty()) {
                cmd = "ydotool type -- " + shell_single_quote(ev.text);
            } else {
                res.error = "Unsupported ydotool input event type: " + ev.type;
                return res;
            }
        } else {
            res.error = "Wayland input requires ydotool or wtype";
            return res;
        }
        cmd += " >/dev/null 2>&1";
        res.ok = (std::system(cmd.c_str()) == 0);
        if (!res.ok) res.error = "Input injection command exited with non-zero status";
        return res;
    }

    res.error = "No input injection backend found (install xdotool, ydotool, or wtype)";
    return res;
#endif
}

} // namespace mass::node
