#include "mass/shell_session.hpp"

#include <array>
#include <cstring>
#include <filesystem>
#include <regex>

#ifndef _WIN32
#include <sys/wait.h>
#include <unistd.h>
#endif

namespace mass::node {

namespace {

constexpr const char* kCwdMarker = "__MASS_CWD_MARKER_9F2A__";

std::string rewrite_sudo_for_stdin(const std::string& cmd) {
    // Replaces standalone `sudo` tokens with `sudo -S -p ''` so password is read from stdin cleanly
    static const std::regex sudo_re(R"((^|[;&|]\s*)sudo(\s+|$))");
    return std::regex_replace(cmd, sudo_re, "$1sudo -S -p ''$2");
}

} // namespace

ShellSession::ShellSession(std::string initial_cwd) {
    if (!initial_cwd.empty() && std::filesystem::exists(initial_cwd)) {
        cwd_ = std::move(initial_cwd);
    } else {
        std::error_code ec;
        cwd_ = std::filesystem::current_path(ec).string();
        if (cwd_.empty()) cwd_ = "/";
    }
}

std::string ShellSession::current_working_directory() const {
    std::lock_guard<std::mutex> lock(mutex_);
    return cwd_;
}

bool ShellSession::command_uses_sudo(const std::string& command) {
    static const std::regex sudo_re(R"((^|[;&|]\s*)sudo(\s+|$))");
    return std::regex_search(command, sudo_re);
}

ShellExecResult ShellSession::execute(
    const std::string& command,
    const std::optional<std::string>& sudo_password) {
    ShellExecResult res;

    if (command.empty()) {
        res.error = "Empty command";
        return res;
    }

    const bool needs_sudo = command_uses_sudo(command);
    if (needs_sudo && (!sudo_password.has_value() || sudo_password->empty())) {
        res.ok = true;
        res.requires_password = true;
        res.prompt = "[sudo] password:";
        res.cwd = current_working_directory();
        return res;
    }

    std::lock_guard<std::mutex> lock(mutex_);

#ifdef _WIN32
    res.error = "Interactive bash shell session is supported on Linux nodes";
    res.cwd = cwd_;
    return res;
#else
    const std::string effective_cmd = needs_sudo ? rewrite_sudo_for_stdin(command) : command;
    // Execute inside persisted cwd, capture exit status, then emit new pwd after sentinel marker
    const std::string wrapped =
        "cd -- \"$MASS_CWD\" 2>/dev/null || true\n" +
        effective_cmd + "\n"
        "__mass_rc=$?\n"
        "printf '\\n" + std::string(kCwdMarker) + "%s\\n' \"$PWD\"\n"
        "exit $__mass_rc\n";

    int stdin_pipe[2] = {-1, -1};
    int stdout_pipe[2] = {-1, -1};
    if (pipe(stdin_pipe) != 0 || pipe(stdout_pipe) != 0) {
        res.error = "Failed to create pipes";
        res.cwd = cwd_;
        return res;
    }

    const pid_t pid = fork();
    if (pid < 0) {
        close(stdin_pipe[0]); close(stdin_pipe[1]);
        close(stdout_pipe[0]); close(stdout_pipe[1]);
        res.error = "fork() failed";
        res.cwd = cwd_;
        return res;
    }

    if (pid == 0) {
        // Child process
        dup2(stdin_pipe[0], STDIN_FILENO);
        dup2(stdout_pipe[1], STDOUT_FILENO);
        dup2(stdout_pipe[1], STDERR_FILENO);

        close(stdin_pipe[0]); close(stdin_pipe[1]);
        close(stdout_pipe[0]); close(stdout_pipe[1]);

        setenv("MASS_CWD", cwd_.c_str(), 1);
        execl("/bin/bash", "bash", "-c", wrapped.c_str(), static_cast<char*>(nullptr));
        _exit(127);
    }

    // Parent process
    close(stdin_pipe[0]);
    close(stdout_pipe[1]);

    if (needs_sudo && sudo_password.has_value()) {
        std::string pw_line = *sudo_password + "\n";
        [[maybe_unused]] const auto written = write(stdin_pipe[1], pw_line.data(), pw_line.size());
        // Scrub password copy from stack memory immediately
        std::fill(pw_line.begin(), pw_line.end(), '\0');
    }
    close(stdin_pipe[1]);

    std::string raw_output;
    std::array<char, 4096> buf{};
    ssize_t n = 0;
    while ((n = read(stdout_pipe[0], buf.data(), buf.size())) > 0) {
        raw_output.append(buf.data(), static_cast<std::size_t>(n));
    }
    close(stdout_pipe[0]);

    int status = 0;
    waitpid(pid, &status, 0);
    res.exit_code = WIFEXITED(status) ? WEXITSTATUS(status) : -1;

    // Extract updated working directory from sentinel marker
    const std::string marker(kCwdMarker);
    const auto pos = raw_output.rfind(marker);
    if (pos != std::string::npos) {
        std::string new_cwd = raw_output.substr(pos + marker.size());
        while (!new_cwd.empty() && (new_cwd.back() == '\n' || new_cwd.back() == '\r')) {
            new_cwd.pop_back();
        }
        if (!new_cwd.empty() && std::filesystem::exists(new_cwd)) {
            cwd_ = new_cwd;
        }
        // Strip sentinel line from visible output
        std::size_t cut = pos;
        if (cut > 0 && raw_output[cut - 1] == '\n') --cut;
        raw_output.erase(cut);
    }

    res.ok = true;
    res.cwd = cwd_;
    res.output = std::move(raw_output);
    return res;
#endif
}

} // namespace mass::node
