#include "mass/master_server.hpp"

#include <algorithm>
#include <array>
#include <chrono>
#include <cstdio>
#include <filesystem>
#include <fstream>
#include <httplib.h>
#include <iomanip>
#include <nlohmann/json.hpp>
#include <set>
#include <sstream>
#include <string>

#ifndef _WIN32
#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/statvfs.h>
#include <unistd.h>
#endif

namespace mass::node {

namespace {

std::string current_utc_iso() {
    const auto now = std::chrono::system_clock::now();
    const std::time_t tt = std::chrono::system_clock::to_time_t(now);
    std::tm tm{};
#ifdef _WIN32
    gmtime_s(&tm, &tt);
#else
    gmtime_r(&tt, &tm);
#endif
    std::ostringstream oss;
    oss << std::put_time(&tm, "%Y-%m-%dT%H:%M:%SZ");
    return oss.str();
}

std::string trim(std::string s) {
    while (!s.empty() && (s.back() == '\r' || s.back() == '\n' || s.back() == ' ' || s.back() == '\t')) {
        s.pop_back();
    }
    while (!s.empty() && (s.front() == ' ' || s.front() == '\t')) {
        s.erase(s.begin());
    }
    return s;
}

double read_cpu_usage_delta_percent() {
    static uint64_t prev_total = 0;
    static uint64_t prev_idle = 0;

    std::ifstream ifs("/proc/stat");
    if (!ifs.is_open()) return 0.0;

    std::string cpu_label;
    uint64_t user = 0, nice = 0, system = 0, idle = 0, iowait = 0, irq = 0, softirq = 0, steal = 0;
    ifs >> cpu_label >> user >> nice >> system >> idle >> iowait >> irq >> softirq >> steal;
    if (cpu_label != "cpu") return 0.0;

    const uint64_t idle_all = idle + iowait;
    const uint64_t total = user + nice + system + idle + iowait + irq + softirq + steal;

    double pct = 0.0;
    if (prev_total > 0 && total > prev_total) {
        const uint64_t d_total = total - prev_total;
        const uint64_t d_idle  = (idle_all >= prev_idle) ? (idle_all - prev_idle) : 0;
        pct = (static_cast<double>(d_total - d_idle) / static_cast<double>(d_total)) * 100.0;
    }
    prev_total = total;
    prev_idle = idle_all;
    return std::clamp(pct, 0.0, 100.0);
}

double read_cpu_temp_celsius() {
    namespace fs = std::filesystem;
    std::error_code ec;
    if (fs::exists("/sys/class/hwmon", ec)) {
        for (const auto& entry : fs::directory_iterator("/sys/class/hwmon", ec)) {
            std::ifstream name_ifs(entry.path() / "name");
            std::string name;
            std::getline(name_ifs, name);
            name = trim(name);
            if (name == "k10temp" || name == "coretemp" || name == "zenpower" || name == "cpu_thermal") {
                std::ifstream t_ifs(entry.path() / "temp1_input");
                long milli = 0;
                if (t_ifs >> milli && milli > 0) {
                    return static_cast<double>(milli) / 1000.0;
                }
            }
        }
    }
    if (fs::exists("/sys/class/thermal", ec)) {
        for (const auto& entry : fs::directory_iterator("/sys/class/thermal", ec)) {
            const std::string fname = entry.path().filename().string();
            if (fname.rfind("thermal_zone", 0) == 0) {
                std::ifstream t_ifs(entry.path() / "temp");
                long milli = 0;
                if (t_ifs >> milli && milli > 0) {
                    return static_cast<double>(milli) / 1000.0;
                }
            }
        }
    }
    return 0.0;
}

std::pair<double, double> read_ram_used_total_gb() {
    std::ifstream ifs("/proc/meminfo");
    if (!ifs.is_open()) return {0.0, 0.0};

    uint64_t mem_total_kb = 0;
    uint64_t mem_avail_kb = 0;
    std::string line;
    while (std::getline(ifs, line)) {
        if (line.rfind("MemTotal:", 0) == 0) {
            std::istringstream iss(line.substr(9));
            iss >> mem_total_kb;
        } else if (line.rfind("MemAvailable:", 0) == 0) {
            std::istringstream iss(line.substr(13));
            iss >> mem_avail_kb;
        }
    }
    const double total_gb = static_cast<double>(mem_total_kb) / (1024.0 * 1024.0);
    const double used_gb  = (mem_total_kb >= mem_avail_kb)
        ? static_cast<double>(mem_total_kb - mem_avail_kb) / (1024.0 * 1024.0)
        : 0.0;
    return {used_gb, total_gb};
}

uint64_t read_uptime_seconds() {
    std::ifstream ifs("/proc/uptime");
    double up = 0.0;
    if (ifs >> up) return static_cast<uint64_t>(up);
    return 0;
}

std::string read_os_info() {
    std::ifstream ifs("/etc/os-release");
    std::string line;
    while (std::getline(ifs, line)) {
        if (line.rfind("PRETTY_NAME=", 0) == 0) {
            std::string val = trim(line.substr(12));
            if (val.size() >= 2 && val.front() == '"' && val.back() == '"') {
                val = val.substr(1, val.size() - 2);
            }
            return val;
        }
    }
    return "Linux";
}

// Collect ALL GPUs (prioritizing dedicated NVIDIA / AMD GPUs over integrated iGPUs!)
void collect_all_gpus(master::NodeTelemetrySnapshot& snap) {
#ifndef _WIN32
    // 1. All dedicated NVIDIA GPUs via nvidia-smi (multi-GPU loop!)
    FILE* pipe = popen(
        "nvidia-smi --query-gpu=name,utilization.gpu,temperature.gpu,memory.used,memory.total "
        "--format=csv,noheader,nounits 2>/dev/null",
        "r");
    if (pipe) {
        std::array<char, 512> buf{};
        while (fgets(buf.data(), static_cast<int>(buf.size()), pipe) != nullptr) {
            const std::string line = trim(buf.data());
            if (line.empty()) continue;
            std::istringstream iss(line);
            std::string name, util, temp, used_mb, total_mb;
            if (std::getline(iss, name, ',') &&
                std::getline(iss, util, ',') &&
                std::getline(iss, temp, ',') &&
                std::getline(iss, used_mb, ',') &&
                std::getline(iss, total_mb, ',')) {
                try {
                    master::GpuInfo g;
                    g.name          = trim(name);
                    g.kind          = "dedicated";
                    g.util_percent  = std::stod(trim(util));
                    g.temp_c        = std::stod(trim(temp));
                    g.vram_used_gb  = std::stod(trim(used_mb)) / 1024.0;
                    g.vram_total_gb = std::stod(trim(total_mb)) / 1024.0;
                    snap.gpus.push_back(std::move(g));
                } catch (...) {}
            }
        }
        pclose(pipe);
    }

    // 2. Scan AMD / Intel DRM cards via /sys/class/drm/card*/device
    namespace fs = std::filesystem;
    std::error_code ec;
    if (fs::exists("/sys/class/drm", ec)) {
        for (const auto& entry : fs::directory_iterator("/sys/class/drm", ec)) {
            const std::string cname = entry.path().filename().string();
            if (cname.rfind("card", 0) != 0 || cname.find('-') != std::string::npos) continue;
            const auto dev = entry.path() / "device";
            if (!fs::exists(dev / "vendor", ec)) continue;

            std::ifstream v_ifs(dev / "vendor");
            std::string vendor;
            std::getline(v_ifs, vendor);
            vendor = trim(vendor);
            // Skip NVIDIA here (already read with full stats via nvidia-smi)
            if (vendor == "0x10de" && !snap.gpus.empty()) continue;

            master::GpuInfo g;
            if (fs::exists(dev / "gpu_busy_percent", ec)) {
                std::ifstream b_ifs(dev / "gpu_busy_percent");
                b_ifs >> g.util_percent;
            }
            if (fs::exists(dev / "mem_info_vram_used", ec)) {
                uint64_t vu = 0;
                std::ifstream(dev / "mem_info_vram_used") >> vu;
                g.vram_used_gb = static_cast<double>(vu) / (1024.0 * 1024.0 * 1024.0);
            }
            if (fs::exists(dev / "mem_info_vram_total", ec)) {
                uint64_t vt = 0;
                std::ifstream(dev / "mem_info_vram_total") >> vt;
                g.vram_total_gb = static_cast<double>(vt) / (1024.0 * 1024.0 * 1024.0);
            }
            // Read GPU hwmon temp if present
            if (fs::exists(dev / "hwmon", ec)) {
                for (const auto& hw : fs::directory_iterator(dev / "hwmon", ec)) {
                    long milli = 0;
                    if (std::ifstream(hw.path() / "temp1_input") >> milli && milli > 0) {
                        g.temp_c = static_cast<double>(milli) / 1000.0;
                        break;
                    }
                }
            }

            const bool is_dedicated = (vendor == "0x1002" && g.vram_total_gb >= 1.5);
            g.kind = is_dedicated ? "dedicated" : "integrated";
            if (vendor == "0x1002") g.name = is_dedicated ? ("AMD Radeon dGPU (" + cname + ")") : ("AMD Radeon iGPU (" + cname + ")");
            else if (vendor == "0x8086") g.name = "Intel Graphics (" + cname + ")";
            else g.name = "GPU (" + cname + ")";

            snap.gpus.push_back(std::move(g));
        }
    }

    // Sort so dedicated GPUs always appear FIRST!
    std::stable_sort(snap.gpus.begin(), snap.gpus.end(), [](const master::GpuInfo& a, const master::GpuInfo& b) {
        if (a.kind != b.kind) return a.kind == "dedicated";
        return a.vram_total_gb > b.vram_total_gb;
    });

    // Populate primary summary fields from the highest-priority (dedicated) GPU
    if (!snap.gpus.empty()) {
        const auto& primary = snap.gpus.front();
        snap.gpu_name          = primary.name;
        snap.gpu_percent       = primary.util_percent;
        snap.gpu_temp_c        = primary.temp_c;
        snap.gpu_vram_used_gb  = primary.vram_used_gb;
        snap.gpu_vram_total_gb = primary.vram_total_gb;
    }
#endif
}

// Collect ALL physical SSD / NVMe / HDD mounts via /proc/mounts
void collect_all_disks(master::NodeTelemetrySnapshot& snap) {
#ifndef _WIN32
    std::ifstream ifs("/proc/mounts");
    std::set<std::string> seen_devices;
    std::string line;
    double agg_used = 0.0;
    double agg_total = 0.0;

    while (std::getline(ifs, line)) {
        std::istringstream iss(line);
        std::string dev, mount, fstype;
        iss >> dev >> mount >> fstype;
        if (dev.rfind("/dev/", 0) != 0) continue;
        if (dev.find("/dev/loop") == 0) continue;
        if (fstype == "squashfs" || fstype == "tmpfs" || fstype == "devtmpfs" || fstype == "overlay") continue;
        if (!seen_devices.insert(dev).second) continue;

        struct statvfs vfs{};
        if (statvfs(mount.c_str(), &vfs) == 0 && vfs.f_blocks > 0) {
            const double total_gb = (static_cast<double>(vfs.f_blocks) * vfs.f_frsize) / (1024.0 * 1024.0 * 1024.0);
            if (total_gb < 1.0) continue; // skip tiny EFI/boot partitions < 1GB
            const double avail_gb = (static_cast<double>(vfs.f_bavail) * vfs.f_frsize) / (1024.0 * 1024.0 * 1024.0);
            const double used_gb  = std::max(0.0, total_gb - avail_gb);
            const double pct      = (total_gb > 0.0) ? (used_gb / total_gb) * 100.0 : 0.0;

            master::DiskInfo d;
            d.device   = dev.substr(5); // strip "/dev/" -> e.g. "nvme0n1p2", "sda1"
            d.mount    = mount;
            d.used_gb  = used_gb;
            d.total_gb = total_gb;
            d.percent  = pct;
            snap.disks.push_back(std::move(d));

            agg_used  += used_gb;
            agg_total += total_gb;
        }
    }

    snap.disk_used_gb  = agg_used;
    snap.disk_total_gb = agg_total;
#endif
}

bool is_local_tcp_port_open(int port) {
#ifndef _WIN32
    int fd = socket(AF_INET, SOCK_STREAM, 0);
    if (fd < 0) return false;
    struct timeval tv{0, 120000};
    setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
    setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof(tv));

    sockaddr_in addr{};
    addr.sin_family = AF_INET;
    addr.sin_port = htons(static_cast<uint16_t>(port));
    inet_pton(AF_INET, "127.0.0.1", &addr.sin_addr);

    const bool ok = (connect(fd, reinterpret_cast<sockaddr*>(&addr), sizeof(addr)) == 0);
    close(fd);
    return ok;
#else
    (void)port;
    return false;
#endif
}

// Collect physical network interfaces (Ethernet/Wi-Fi cable/link status) + key service ports
void collect_network_and_ports(master::NodeTelemetrySnapshot& snap) {
#ifndef _WIN32
    namespace fs = std::filesystem;
    std::error_code ec;
    if (fs::exists("/sys/class/net", ec)) {
        for (const auto& entry : fs::directory_iterator("/sys/class/net", ec)) {
            const std::string iface = entry.path().filename().string();
            if (iface == "lo" || iface.rfind("veth", 0) == 0 || iface.rfind("docker", 0) == 0 || iface.rfind("br-", 0) == 0) {
                continue;
            }
            int carrier = 0;
            std::ifstream(entry.path() / "carrier") >> carrier;
            long speed = -1;
            std::ifstream(entry.path() / "speed") >> speed;

            std::string detail = (carrier == 1) ? "BAĞLI" : "KOPUK";
            if (carrier == 1 && speed > 0) {
                detail = std::to_string(speed) + "M";
            }
            snap.network_ports.push_back(master::PortStatusInfo{iface, detail, carrier == 1});
        }
    }

    // Critical service ports
    const std::array<std::pair<int, const char*>, 5> svc_ports = {{
        {6277, "Portal :6277"},
        {8444, "mTLS :8444"},
        {8445, "Node :8445"},
        {11434, "Ollama :11434"},
        {22, "SSH :22"}
    }};
    for (const auto& [port, label] : svc_ports) {
        const bool open = is_local_tcp_port_open(port);
        snap.network_ports.push_back(master::PortStatusInfo{label, open ? "AÇIK" : "KAPALI", open});
    }
#endif
}

void collect_si_ollama_status(master::NodeTelemetrySnapshot& snap) {
    httplib::Client cli("127.0.0.1", 11434);
    cli.set_connection_timeout(0, 500000);
    cli.set_read_timeout(1, 0);

    if (auto tags_res = cli.Get("/api/tags")) {
        if (tags_res->status == 200) {
            snap.si_info.ollama_online = true;
            snap.si_info.state = "idle";
            try {
                auto j = nlohmann::json::parse(tags_res->body);
                if (j.contains("models") && j["models"].is_array()) {
                    snap.si_info.available_models_count = static_cast<int>(j["models"].size());
                }
            } catch (...) {}
        }
    } else {
        snap.si_info.ollama_online = false;
        snap.si_info.state = "offline";
        return;
    }

    if (auto ps_res = cli.Get("/api/ps")) {
        if (ps_res->status == 200) {
            try {
                auto j = nlohmann::json::parse(ps_res->body);
                if (j.contains("models") && j["models"].is_array() && !j["models"].empty()) {
                    const auto& m = j["models"].at(0);
                    snap.si_info.state = "active";
                    snap.si_info.loaded_model = m.value("name", "");
                    snap.si_info.vram_used_gb = m.value("size_vram", 0.0) / (1024.0 * 1024.0 * 1024.0);
                    snap.si_info.inference_gpu_percent = snap.gpu_percent;
                    snap.si_info.inference_gpu_temp_c = snap.gpu_temp_c;
                }
            } catch (...) {}
        }
    }
}

} // namespace

master::NodeTelemetrySnapshot collect_local_telemetry(
    const std::string& node_id,
    const std::string& role,
    const std::string& advertised_ip) {
    master::NodeTelemetrySnapshot snap;
    snap.node_id = node_id;
    snap.role = role;
    snap.ip = advertised_ip;
    snap.last_sync = current_utc_iso();

#ifndef _WIN32
    char host[256] = {};
    if (gethostname(host, sizeof(host) - 1) == 0) snap.hostname = host;

    snap.cpu_percent = read_cpu_usage_delta_percent();
    snap.cpu_temp_c  = read_cpu_temp_celsius();

    const auto [ram_used, ram_total] = read_ram_used_total_gb();
    snap.ram_used_gb  = ram_used;
    snap.ram_total_gb = ram_total;

    snap.uptime  = read_uptime_seconds();
    snap.os_info = read_os_info();
#endif

    collect_all_gpus(snap);
    collect_all_disks(snap);
    collect_network_and_ports(snap);
    collect_si_ollama_status(snap);
    return snap;
}

} // namespace mass::node
