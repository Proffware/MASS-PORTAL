#!/usr/bin/env bash
# MASS Backend v2.9 "Ripple" — Clean Launcher (Master + Node + 4G/5G Tunnel)
set -euo pipefail

C_CYAN='\033[1;36m'
C_GREEN='\033[1;32m'
C_RED='\033[1;31m'
C_DIM='\033[0;90m'
C_BOLD='\033[1m'
C_RST='\033[0m'

ok()   { printf "\r\033[K  ${C_GREEN}✔${C_RST} %s\n" "$1"; }
fail() { printf "\r\033[K  ${C_RED}✖${C_RST} %s\n" "$1"; exit 1; }

# Wave Loading Animation: "Mass", "mAss", "maSs", "masS", "maSs", "mAss"
WAVE_PID=""
start_wave() {
    local msg="$1"
    (
        local frames=("Mass" "mAss" "maSs" "masS" "maSs" "mAss")
        local i=0
        while true; do
            printf "\r\033[K  ${C_CYAN}[%s]${C_RST} %s" "${frames[$i]}" "${msg}"
            i=$(( (i + 1) % ${#frames[@]} ))
            sleep 0.14
        done
    ) &
    WAVE_PID=$!
}

stop_wave() {
    if [[ -n "${WAVE_PID}" ]]; then
        kill "${WAVE_PID}" >/dev/null 2>&1 || true
        wait "${WAVE_PID}" >/dev/null 2>&1 || true
        WAVE_PID=""
        printf "\r\033[K"
    fi
}
trap stop_wave EXIT

clear 2>/dev/null || true
printf "${C_CYAN}"
cat << 'BANNER'
█   █  ███   ████  ████     █ ████   ███  ████  █████  ███  █
██ ██░█ ░░█ █ ░░░░█ ░░░░   █ ░█░░░█ █ ░░█ █░░░█  ░█░░░█ ░░█ █░
█░█ █░█████░ ███░░░███░░░ █ ░ ████░░█░ ░█░████░░  █░░░█████░█░░
█░░░█░█░░░█░░ ░░█   ░░█  █ ░ ░█░░░░ █░░ █░█░░█░ ░ █░░ █░░░█░█░░
█░░ █░█░░░█░████░░████░░█ ░ ░ █░░░░░ ███ ░█░░░█░  █░░ █░░░█░█████
 ░░  ░░░░  ░░░░░░ ░░░░░ ░░ ░   ░░     ░░░ ░░░  ░   ░░  ░░  ░░░░░░░
  ░   ░ ░   ░ ░░░░  ░░░░  ░     ░      ░░░  ░   ░   ░   ░   ░ ░░░░░
BANNER
printf "${C_BOLD}                      v2.9 • Ripple${C_RST}\n\n"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR=""
for candidate in \
    "${SCRIPT_DIR}" \
    "${SCRIPT_DIR}/mass-backend" \
    "/home/${USER}/Masaüstü/MASS_BACKEND/mass-backend-V2.9-Ripple" \
    "/home/${USER}/Masaüstü/MASS_BACKEND/mass-backend-V2.9"; do
    if [[ -f "${candidate}/CMakeLists.txt" ]]; then
        PROJECT_DIR="${candidate}"
        break
    fi
done
[[ -n "${PROJECT_DIR}" ]] || fail "v2.9 proje klasörü (CMakeLists.txt) bulunamadı."

# Kullanıcıdan bu cihazın adını ve rolünü sor
DEFAULT_NAME="$(hostname 2>/dev/null || echo 'mass-master')"
printf "  ${C_BOLD}Bu cihazı nasıl tanımlamak istersiniz?${C_RST}\n"
read -r -p "  Cihaz adı [${DEFAULT_NAME}]: " CUSTOM_NODE_ID
NODE_ID="${CUSTOM_NODE_ID:-$DEFAULT_NAME}"

printf "  Cihaz rolü seçin: ${C_DIM}(1) Ana Sunucu  (2) Server Rack  (3) Workstation  (4) NAS  (5) Kişisel PC${C_RST}\n"
read -r -p "  Seçim [1]: " ROLE_CHOICE
case "${ROLE_CHOICE:-1}" in
    2) NODE_ROLE="rack" ;;
    3) NODE_ROLE="workstation" ;;
    4) NODE_ROLE="nas" ;;
    5) NODE_ROLE="pc" ;;
    *) NODE_ROLE="server" ;;
esac
echo ""

cd "${PROJECT_DIR}"
LOG_FILE="${PROJECT_DIR}/mass_setup.log"
: > "${LOG_FILE}"

sudo -v

start_wave "Eski servisler temizleniyor..."
sudo systemctl stop mass-master mass-node mass-tunnel >/dev/null 2>&1 || true
sudo pkill -9 mass_master >/dev/null 2>&1 || true
sudo pkill -9 mass_node >/dev/null 2>&1 || true
sudo pkill -9 cloudflared >/dev/null 2>&1 || true
stop_wave
ok "Eski süreçler temizlendi"

chmod +x scripts/mass_server.sh scripts/mass_node.sh
start_wave "v2.9 Ripple derleniyor, sertifikalar ve servisler hazırlanıyor..."
if ./scripts/mass_server.sh --skip-deps --node-id "${NODE_ID}" --role "${NODE_ROLE}" "$@" >>"${LOG_FILE}" 2>&1; then
    stop_wave
    ok "C++20 derleme ve birim testleri tamamlandı"
    ok "TLS 1.3 / mTLS sertifikaları ve donanım lisansı doğrulandı"
    ok "Master (:6277), Node (${NODE_ID} • ${NODE_ROLE}) ve 4G/5G Tünel aktif"
else
    stop_wave
    printf "  ${C_RED}✖ Kurulum başarısız oldu. Son log satırları:${C_RST}\n"
    tail -n 20 "${LOG_FILE}"
    exit 1
fi

LAN_IP="$(hostname -I 2>/dev/null | awk '{print $1}' || echo '127.0.0.1')"
TUNNEL_URL="$(grep -oE 'https://[a-zA-Z0-9-]+\.trycloudflare\.com' "${PROJECT_DIR}/mass_tunnel.log" 2>/dev/null | tail -n 1 || true)"
PAIR_OUT="$("${PROJECT_DIR}/build/mass-cli" --db "${PROJECT_DIR}/mass_state.db" device pair-code 2>/dev/null || true)"
PAIR_CODE="$(echo "${PAIR_OUT}" | grep -oE '[0-9]{6}' | tail -n 1 || true)"

echo ""
printf "  ${C_BOLD}Cihaz        :${C_RST} %s (%s)\n" "${NODE_ID}" "${NODE_ROLE}"
printf "  ${C_BOLD}Wi-Fi (LAN)  :${C_RST} https://%s:6277\n" "${LAN_IP}"
if [[ -n "${TUNNEL_URL}" ]]; then
    printf "  ${C_BOLD}4G/5G Tünel  :${C_RST} %s ${C_DIM}(otomatik senkronize olur)${C_RST}\n" "${TUNNEL_URL}"
fi
if [[ -n "${PAIR_CODE}" ]]; then
    printf "  ${C_BOLD}Eşleştirme   :${C_RST} ${C_GREEN}%s${C_RST} ${C_DIM}(60 sn)${C_RST}\n" "${PAIR_CODE}"
else
    printf "  ${C_BOLD}Eşleştirme   :${C_RST} ${C_GREEN}Kayıtlı cihaz aktif${C_RST}\n"
fi
echo ""
