# MASS v2.9 "Ripple" — Başlangıç Kılavuzu (`starter_guide.md`)

**MASS Server Portal**, tamamen kendi bilgisayarında/sunucunda çalışan, bulut veritabanı gerektirmeyen, **TLS 1.3 + Android Keystore (ECDSA P-256)** korumalı sunucu izleme, çoklu terminal, yerel AI (SSA) ve **1080p 60 FPS donanım H.264** uzak masaüstü sistemidir.

## 1. Ana Bilgisayarda Kurulum (Tek Komut)

ZIP arşivini açtığın klasörde şu komutu çalıştır:

```bash
chmod +x start_mass_v2_9.bash && ./start_mass_v2_9.bash
```

Kurulum sırasında betik sana şu iki soruyu sorar:
1. **Cihaz adı** (örn. `ev-pc`, `ana-sunucu`)
2. **Cihaz rolü** (`Ana Sunucu`, `Server Rack`, `Workstation`, `NAS` veya `Kişisel PC`)

Ardından otomatik olarak C++20 çekirdeğini derler, TLS 1.3/mTLS sertifikalarını üretir, donanım lisansını imzalar, `mass-master`, `mass-node` ve **4G/5G Tünel** servislerini başlatır ve ekrana **Wi-Fi (LAN) adresi**, **4G/5G Tünel adresi** ve **6 haneli eşleştirme kodunu** basar.

## 2. Android Uygulamasını Bağlama

1. Uygulamada **Ayarlar → MASS Master URL / IP** alanına terminalde çıkan Wi-Fi adresini yaz (örn. `https://192.168.1.109:6277`).
2. **Sunucu CA Sertifikası** kutusunu boş bırak.
3. Terminalde çıkan **6 haneli eşleştirme kodunu** girip **Cihazı Eşleştir** butonuna bas.
4. **Otomatik 4G/5G Senkronu:** Telefonun Wi-Fi'dayken Master PC'den güncel 4G/5G tünel adresini otomatik alır. Evden çıkıp mobil veriye geçtiğinde uygulama otomatik olarak 4G/5G tüneline (`DynamicBandWidth`), eve döndüğünde ise tekrar **25 Mbps LAN Wi-Fi** moduna geçer.

## 3. Yeni Bir Server Rack / Workstation / NAS Ekleme

1. Ana bilgisayardaki `certs/ca.crt`, `certs/node.crt` ve `certs/node.key` dosyalarını yeni cihazdaki `mass-backend/certs/` klasörüne kopyala.
2. Yeni cihazda şu komutu çalıştır:
   ```bash
   chmod +x setup_mass_node_v2_9.bash && ./setup_mass_node_v2_9.bash
   ```
3. Cihaz adını, rolünü ve ana Master IP'sini gir; düğüm saniyeler içinde Dashboard'daki donanım ağacında görünür.

## 4. Uzak Masaüstü Dokunmatik Hareketler

- **1 Parmak:** Dokun (sol tık), çift dokun (çift tık), uzun bas (sağ tık), sürükle (taşı/seç).
- **2 Parmak:** Hızlı dokun (sağ tık), yukarı/aşağı sürükle (kaydırma).
- **3 Parmak:** Sola/sağa (`Alt+Tab` uygulama değiştir), yukarı (`Super` menü), aşağı (`Super+D` masaüstü).
- **Sağ Kenar Çubuğu:** `FPS` (30 ↔ 60 geçişi), `Kaydır` (yan kaydırma çubuğu), `Klavye` (kısayollar & metin girişi), `×` (çıkış).

## 5. Faydalı Yönetim Komutları

- **Yeni 6 haneli eşleştirme kodu al:**
  ```bash
  ./build/mass-cli --db mass_state.db device revoke && ./build/mass-cli --db mass_state.db device pair-code
  ```
- **Servis durumlarını gör:**
  ```bash
  sudo systemctl status mass-master mass-node mass-tunnel --no-pager
  ```

## Üçüncü Parti Açık Kaynak Bileşenler

OpenSSL 3 (Apache-2.0), SQLite3 (Public Domain), cpp-httplib (MIT), nlohmann/json (MIT), GoogleTest (BSD-3-Clause), FFmpeg & cloudflared (harici çalışma zamanı araçları).
