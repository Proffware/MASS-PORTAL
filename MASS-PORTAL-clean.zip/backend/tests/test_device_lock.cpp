#include "mass/crypto.hpp"
#include "mass/db.hpp"

#include <filesystem>
#include <gtest/gtest.h>

TEST(DeviceLockTest, SingleDeviceExclusiveLockAndRevoke) {
    const auto temp_db = std::filesystem::temp_directory_path() / "mass_test_lock.db";
    std::filesystem::remove(temp_db);

    mass::storage::Database db(temp_db);
    ASSERT_TRUE(db.init_schema());

    auto dev1 = mass::crypto::generate_ecdsa_p256_keypair();
    auto dev2 = mass::crypto::generate_ecdsa_p256_keypair();
    ASSERT_TRUE(dev1.has_value());
    ASSERT_TRUE(dev2.has_value());

    EXPECT_EQ(db.pair_device_exclusive(dev1->public_pem), mass::storage::PairResult::Success);
    EXPECT_EQ(db.pair_device_exclusive(dev2->public_pem), mass::storage::PairResult::AlreadyPaired);

    EXPECT_TRUE(db.revoke_paired_device());
    EXPECT_EQ(db.pair_device_exclusive(dev2->public_pem), mass::storage::PairResult::Success);

    std::filesystem::remove(temp_db);
}

TEST(DeviceLockTest, NodeDeduplicationByIpAndHostname) {
    const auto temp_db = std::filesystem::temp_directory_path() / "mass_test_dedup.db";
    std::filesystem::remove(temp_db);

    mass::storage::Database db(temp_db);
    ASSERT_TRUE(db.init_schema());

    mass::storage::NodeRecord n1{"node-a", "srv-01", "192.168.1.50", "server", "online", "pk1", ""};
    mass::storage::NodeRecord n1_restarted{"node-b", "srv-01", "192.168.1.50", "server", "online", "pk2", ""};

    EXPECT_EQ(db.register_or_update_node(n1, 1), mass::storage::NodeRegisterResult::Registered);
    // Same IP + hostname after restart should UPSERT rather than duplicate or fail max_nodes=1
    EXPECT_EQ(db.register_or_update_node(n1_restarted, 1), mass::storage::NodeRegisterResult::Updated);
    EXPECT_EQ(db.list_nodes().size(), 1u);
    EXPECT_EQ(db.list_nodes().front().node_id, "node-b");

    std::filesystem::remove(temp_db);
}
