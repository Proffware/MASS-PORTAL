#include "mass/crypto.hpp"
#include "mass/license.hpp"

#include <gtest/gtest.h>

TEST(LicenseTest, ValidEd25519HardwareBoundLicensePasses) {
    auto kp = mass::crypto::generate_ed25519_keypair();
    ASSERT_TRUE(kp.has_value());

    mass::licensing::LicensePayload payload;
    payload.master_machine_id = "mass-hw-abc123def456";
    payload.max_nodes = 4;
    payload.expires_at = "2099-12-31T23:59:59Z";
    payload.features = {true, true, true, true};

    auto signed_json = mass::licensing::create_signed_license_json(payload, kp->private_pem);
    ASSERT_TRUE(signed_json.has_value());

    auto res = mass::licensing::verify_license_json(
        *signed_json, "mass-hw-abc123def456", kp->public_pem);
    EXPECT_TRUE(res.valid) << res.error;
    ASSERT_TRUE(res.payload.has_value());
    EXPECT_EQ(res.payload->max_nodes, 4);
    EXPECT_TRUE(res.payload->features.ssa);
}

TEST(LicenseTest, HardwareMismatchIsRejected) {
    auto kp = mass::crypto::generate_ed25519_keypair();
    ASSERT_TRUE(kp.has_value());

    mass::licensing::LicensePayload payload;
    payload.master_machine_id = "mass-hw-original";
    payload.max_nodes = 2;
    payload.expires_at = "2099-12-31T23:59:59Z";

    auto signed_json = mass::licensing::create_signed_license_json(payload, kp->private_pem);
    ASSERT_TRUE(signed_json.has_value());

    auto res = mass::licensing::verify_license_json(
        *signed_json, "mass-hw-different-host", kp->public_pem);
    EXPECT_FALSE(res.valid);
}

TEST(LicenseTest, ExpiredLicenseIsRejected) {
    auto kp = mass::crypto::generate_ed25519_keypair();
    ASSERT_TRUE(kp.has_value());

    mass::licensing::LicensePayload payload;
    payload.master_machine_id = "mass-hw-abc123";
    payload.max_nodes = 2;
    payload.expires_at = "2020-01-01T00:00:00Z";

    auto signed_json = mass::licensing::create_signed_license_json(payload, kp->private_pem);
    ASSERT_TRUE(signed_json.has_value());

    auto res = mass::licensing::verify_license_json(
        *signed_json, "mass-hw-abc123", kp->public_pem);
    EXPECT_FALSE(res.valid);
}

TEST(LicenseTest, TamperedPayloadFailsEd25519Verification) {
    auto kp = mass::crypto::generate_ed25519_keypair();
    ASSERT_TRUE(kp.has_value());

    mass::licensing::LicensePayload payload;
    payload.master_machine_id = "mass-hw-abc123";
    payload.max_nodes = 1;
    payload.expires_at = "2099-12-31T23:59:59Z";

    auto signed_json = mass::licensing::create_signed_license_json(payload, kp->private_pem);
    ASSERT_TRUE(signed_json.has_value());

    // Tamper max_nodes from 1 to 99
    std::string tampered = *signed_json;
    auto pos = tampered.find("\"max_nodes\": 1");
    ASSERT_NE(pos, std::string::npos);
    tampered.replace(pos, 14, "\"max_nodes\": 99");

    auto res = mass::licensing::verify_license_json(
        tampered, "mass-hw-abc123", kp->public_pem);
    EXPECT_FALSE(res.valid);
}
