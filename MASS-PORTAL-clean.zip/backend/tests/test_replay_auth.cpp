#include "mass/auth.hpp"
#include "mass/crypto.hpp"

#include <gtest/gtest.h>
#include <thread>

TEST(ReplayAuthTest, NonceIsStrictlySingleUse) {
    mass::auth::NonceStore store(std::chrono::seconds{30});
    const std::string nonce = store.issue();
    ASSERT_FALSE(nonce.empty());
    EXPECT_EQ(store.active_count(), 1u);

    // First consume succeeds and immediately deletes nonce
    EXPECT_TRUE(store.consume(nonce));
    EXPECT_EQ(store.active_count(), 0u);

    // Replay attempt must fail
    EXPECT_FALSE(store.consume(nonce));
}

TEST(ReplayAuthTest, ExpiredNonceIsRejected) {
    mass::auth::NonceStore store(std::chrono::seconds{1});
    const std::string nonce = store.issue();
    std::this_thread::sleep_for(std::chrono::milliseconds{1150});
    EXPECT_FALSE(store.consume(nonce));
}

TEST(ReplayAuthTest, EcdsaP256SignatureAndReplayProtection) {
    auto kp = mass::crypto::generate_ecdsa_p256_keypair();
    ASSERT_TRUE(kp.has_value());

    mass::auth::NonceStore store(std::chrono::seconds{30});
    const std::string nonce = store.issue();

    const std::string method = "POST";
    const std::string path   = "/v1/console/exec";
    const std::string body   = R"({"target_node_id":"node-1","command":"uptime"})";

    const std::string canonical =
        method + "\n" + path + "\n" + nonce + "\n" + mass::crypto::sha256_hex(body);
    const std::span<const uint8_t> msg_span(
        reinterpret_cast<const uint8_t*>(canonical.data()), canonical.size());

    auto sig = mass::crypto::sign_ecdsa_p256(kp->private_pem, msg_span);
    ASSERT_TRUE(sig.has_value());
    const std::string sig_b64 = mass::crypto::base64_encode(*sig);

    // First authenticated request succeeds
    auto res1 = mass::auth::verify_request_signature(
        store, kp->public_pem, method, path, body, nonce, sig_b64);
    EXPECT_TRUE(res1.ok) << res1.error;

    // Exact same signed request replayed must be rejected with 401
    auto res2 = mass::auth::verify_request_signature(
        store, kp->public_pem, method, path, body, nonce, sig_b64);
    EXPECT_FALSE(res2.ok);
    EXPECT_EQ(res2.http_status, 401);
}
