#include "mass/remote_desktop.hpp"
#include "mass/shell_session.hpp"
#include "mass/ssa.hpp"

#include <gtest/gtest.h>

TEST(V2ShellTest, PersistentWorkingDirectoryAndPipes) {
    mass::node::ShellSession session("/tmp");
    auto r1 = session.execute("pwd");
    ASSERT_TRUE(r1.ok);
    EXPECT_EQ(r1.cwd, "/tmp");

    auto r2 = session.execute("cd / && pwd | tr -d '\\n'");
    ASSERT_TRUE(r2.ok);
    EXPECT_EQ(r2.cwd, "/");
    EXPECT_EQ(r2.output, "/");
}

TEST(V2ShellTest, InteractiveSudoPromptsWhenPasswordAbsent) {
    mass::node::ShellSession session("/tmp");
    EXPECT_TRUE(mass::node::ShellSession::command_uses_sudo("sudo systemctl status mass-master"));
    EXPECT_FALSE(mass::node::ShellSession::command_uses_sudo("echo hello"));

    auto res = session.execute("sudo whoami");
    ASSERT_TRUE(res.ok);
    EXPECT_TRUE(res.requires_password);
    EXPECT_EQ(res.prompt, "[sudo] password:");
}

TEST(V2DesktopTest, NormalizedCoordinateMappingClampsSafely) {
    const auto [x0, y0] = mass::node::map_normalized_coords(0.0, 0.0, 1920, 1080);
    EXPECT_EQ(x0, 0);
    EXPECT_EQ(y0, 0);

    const auto [xc, yc] = mass::node::map_normalized_coords(0.5, 0.5, 1920, 1080);
    EXPECT_NEAR(xc, 960, 1);
    EXPECT_NEAR(yc, 540, 1);

    const auto [xm, ym] = mass::node::map_normalized_coords(1.5, -0.2, 1920, 1080);
    EXPECT_EQ(xm, 1919);
    EXPECT_EQ(ym, 0);
}

TEST(V2DesktopTest, ExtractsMultipleJpegFramesFromMjpegStreamBuffer) {
    std::vector<uint8_t> buf = {
        0x00, 0x11,                   // leading garbage
        0xFF, 0xD8, 0xAA, 0xBB, 0xFF, 0xD9, // frame 1
        0xFF, 0xD8, 0xCC, 0xFF, 0xD9,       // frame 2
        0xFF, 0xD8, 0xDD                    // partial frame 3 (must remain in buffer)
    };
    auto frames = mass::node::extract_jpeg_frames_from_buffer(buf);
    ASSERT_EQ(frames.size(), 2u);
    EXPECT_EQ(frames[0].size(), 6u);
    EXPECT_EQ(frames[1].size(), 5u);
    EXPECT_EQ(buf.size(), 3u);
    EXPECT_EQ(buf[0], 0xFF);
    EXPECT_EQ(buf[1], 0xD8);
}

TEST(V2SsaTest, PreservesAndWrapsOverthinkerThinkingBlocks) {
    const std::string wrapped = mass::ssa::format_overthinker_response(
        "Checking thermal zone and GPU VRAM...",
        "CPU is at 54°C and VRAM usage is healthy.");
    EXPECT_NE(wrapped.find("<think>"), std::string::npos);
    EXPECT_NE(wrapped.find("</think>"), std::string::npos);
    EXPECT_NE(wrapped.find("CPU is at 54°C"), std::string::npos);

    const std::string inline_think = "<think>step 1</think>\nFinal answer.";
    EXPECT_EQ(mass::ssa::format_overthinker_response("ignored", inline_think), inline_think);
}
