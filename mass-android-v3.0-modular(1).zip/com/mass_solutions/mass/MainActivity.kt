package com.mass_solutions.mass

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.unit.dp
import com.mass_solutions.mass.animations.MassRippleLoader
import com.mass_solutions.mass.network.MassApiClient
import com.mass_solutions.mass.security.MassKeystoreManager
import com.mass_solutions.mass.security.PortalPrefs
import com.mass_solutions.mass.security.SecurityGuard
import com.mass_solutions.mass.state.*
import com.mass_solutions.mass.theme.PortalDarkColorScheme
import com.mass_solutions.mass.theme.PortalPalette
import com.mass_solutions.mass.theme.PortalTypography
import com.mass_solutions.mass.ui.ConsoleScreen
import com.mass_solutions.mass.ui.DashboardScreen
import com.mass_solutions.mass.ui.DesktopRemoteDialog
import com.mass_solutions.mass.ui.PortalGuideDialog
import com.mass_solutions.mass.ui.PrivacyPolicyScreen
import com.mass_solutions.mass.ui.SettingsScreen
import com.mass_solutions.mass.ui.SsaScreen
import com.mass_solutions.mass.ui.WelcomeScreen
import com.mass_solutions.mass.ui.isTurkish
import com.mass_solutions.mass.ui.theme.MASSTheme
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.json.JSONObject

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MASSTheme {
                MaterialTheme(colorScheme = PortalDarkColorScheme) {
                    MassPortalApp()
                }
            }
        }
    }
}

@Composable
fun MassPortalApp() {
    val context = LocalContext.current
    val tr = isTurkish()
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    MassPortalSession.ensureInitialized(context)
    var state by MassPortalSession.stateHolder
    var desktopNodeId by MassPortalSession.desktopNodeIdHolder
    var showGuide by remember { mutableStateOf(false) }

    // Akıllı birleştirmeli (coalescing) uzak masaüstü giriş kuyruğu — gecikme biriktirmez
    val inputQueue = remember { Channel<JSONObject>(capacity = Channel.UNLIMITED) }
    LaunchedEffect(Unit) {
        for (first in inputQueue) {
            var current = first
            // Peş peşe gelen move/drag_move paketlerinde eski ara noktaları atla, en son konumu gönder
            if (current.optString("type") in setOf("move", "drag_move")) {
                while (true) {
                    val next = inputQueue.tryReceive().getOrNull() ?: break
                    val nextType = next.optString("type")
                    if (nextType == "move" || nextType == "drag_move") {
                        current = next
                    } else {
                        val s0 = state
                        runCatching {
                            MassApiClient.signedRequest(
                                baseUrl = s0.effectiveEndpoint,
                                path = "/v1/desktop/input",
                                method = "POST",
                                caCertPem = s0.caCertPem,
                                jsonBody = current.toString()
                            )
                        }
                        current = next
                        break
                    }
                }
            }
            val s = state
            runCatching {
                MassApiClient.signedRequest(
                    baseUrl = s.effectiveEndpoint,
                    path = "/v1/desktop/input",
                    method = "POST",
                    caCertPem = s.caCertPem,
                    jsonBody = current.toString()
                )
            }
        }
    }

    fun showToast(msg: String) {
        scope.launch { snackbarHostState.showSnackbar(msg) }
    }

    fun dispatch(intent: MassIntent) {
        when (intent) {
            is MassIntent.Navigate -> state = state.copy(currentScreen = intent.screen)
            is MassIntent.UpdateSearchQuery -> state = state.copy(searchQuery = intent.query)
            is MassIntent.UpdateNodeFilter -> state = state.copy(nodeFilter = intent.filter)
            is MassIntent.SelectNodeForConsole -> {
                val updatedTerms = state.terminals.map {
                    if (it.id == state.activeTerminalId) it.copy(targetNodeId = intent.nodeId) else it
                }
                state = state.copy(selectedNodeId = intent.nodeId, terminals = updatedTerms)
            }
            is MassIntent.ClearConsole -> {
                val updatedTerms = state.terminals.map {
                    if (it.id == state.activeTerminalId) it.copy(entries = emptyList(), pendingSudoCommand = null) else it
                }
                state = state.copy(terminals = updatedTerms)
            }
            is MassIntent.CancelSudoPrompt -> {
                val updatedTerms = state.terminals.map {
                    if (it.id == state.activeTerminalId) it.copy(pendingSudoCommand = null) else it
                }
                state = state.copy(terminals = updatedTerms)
            }
            is MassIntent.CreateTerminal -> {
                val num = state.nextTerminalNumber
                val newTerm = TerminalSession(
                    id = "term-$num",
                    title = "Terminal $num",
                    targetNodeId = state.selectedNodeId
                )
                state = state.copy(
                    terminals = state.terminals + newTerm,
                    activeTerminalId = newTerm.id,
                    nextTerminalNumber = num + 1
                )
            }
            is MassIntent.SelectTerminal -> state = state.copy(activeTerminalId = intent.terminalId)
            is MassIntent.CloseTerminal -> {
                if (state.terminals.size > 1) {
                    val remaining = state.terminals.filterNot { it.id == intent.terminalId }
                    val newActive = if (state.activeTerminalId == intent.terminalId) remaining.first().id else state.activeTerminalId
                    state = state.copy(terminals = remaining, activeTerminalId = newActive)
                }
            }
            is MassIntent.SelectLocalAiModel -> state = state.copy(selectedAiModelId = intent.modelId)
            is MassIntent.SelectLocalAiScopeNode -> state = state.copy(selectedAiScopeNodeId = intent.nodeId)
            is MassIntent.ClearLocalAiChat -> state = state.copy(localAiMessages = emptyList())
            is MassIntent.ToggleSafeMode -> state = state.copy(safeModeEnabled = intent.enabled)

            is MassIntent.UpdateEndpoint -> {
                val norm = SecurityGuard.normalizeServerAddress(intent.endpoint)
                val err = SecurityGuard.validateHttpsEndpoint(norm, tr)
                if (err != null) {
                    state = state.copy(endpointError = err)
                } else {
                    PortalPrefs.saveEndpoint(context, norm)
                    state = state.copy(apiEndpoint = norm, endpointError = null, usingRemoteRoute = false)
                }
            }
            is MassIntent.UpdateRemoteEndpoint -> {
                val trimmed = intent.endpoint.trim()
                val norm = if (trimmed.isEmpty()) "" else SecurityGuard.normalizeServerAddress(trimmed)
                PortalPrefs.saveRemoteEndpoint(context, norm)
                state = state.copy(remoteEndpoint = norm)
            }
            is MassIntent.UpdateCaCertPem -> {
                PortalPrefs.saveCaPem(context, intent.pem.trim())
                state = state.copy(caCertPem = intent.pem.trim())
                showToast(if (tr) "CA sertifikası kaydedildi" else "CA certificate saved")
            }
            is MassIntent.ResetLocalPairing -> {
                PortalPrefs.savePaired(context, false)
                state = state.copy(isDevicePaired = false, isConnected = false, devices = emptyList())
                showToast(if (tr) "Yerel eşleştirme sıfırlandı" else "Local pairing reset")
            }

            is MassIntent.PairDevice -> {
                scope.launch {
                    state = state.copy(isBusy = true)
                    runCatching {
                        val payload = JSONObject().apply {
                            put("pair_code", intent.pairCode)
                            put("device_public_key", MassKeystoreManager.getPublicKeyPem())
                        }
                        val res = MassApiClient.request(
                            baseUrl = state.effectiveEndpoint,
                            path = "/v1/device/pair",
                            method = "POST",
                            caCertPem = state.caCertPem,
                            jsonBody = payload.toString()
                        )
                        if (res.statusCode in 200..299) {
                            PortalPrefs.savePaired(context, true)
                            state = state.copy(isDevicePaired = true, isConnected = true, isBusy = false, currentScreen = Screen.Dashboard)
                            showToast(if (tr) "Cihaz başarıyla eşleştirildi" else "Device paired successfully")
                            dispatch(MassIntent.CheckServerHealth)
                            dispatch(MassIntent.FetchDevices)
                        } else {
                            state = state.copy(isBusy = false)
                            showToast(parseErrorMsg(res.body, "HTTP ${res.statusCode}"))
                        }
                    }.onFailure { e ->
                        state = state.copy(isBusy = false)
                        showToast(e.message ?: (if (tr) "Eşleştirme hatası" else "Pairing error"))
                    }
                }
            }

            is MassIntent.CheckServerHealth -> {
                scope.launch {
                    state = state.copy(isBusy = true)
                    val lanOk = MassApiClient.quickProbe(state.apiEndpoint, state.caCertPem, 1800)
                    val targetRouteRemote = if (lanOk) {
                        false
                    } else if (state.remoteEndpoint.isNotBlank() && MassApiClient.quickProbe(state.remoteEndpoint, state.caCertPem, 2500)) {
                        true
                    } else {
                        state.usingRemoteRoute
                    }
                    state = state.copy(usingRemoteRoute = targetRouteRemote)

                    runCatching {
                        val res = MassApiClient.signedRequest(
                            baseUrl = state.effectiveEndpoint,
                            path = "/v1/health",
                            method = "GET",
                            caCertPem = state.caCertPem
                        )
                        if (res.statusCode in 200..299) {
                            val obj = JSONObject(res.body)
                            val remoteUrl = obj.optString("remote_url", "").trim()
                            if (remoteUrl.startsWith("https://") && remoteUrl != state.remoteEndpoint) {
                                PortalPrefs.saveRemoteEndpoint(context, remoteUrl)
                                state = state.copy(remoteEndpoint = remoteUrl)
                            }
                            val quotaObj = obj.optJSONObject("quota")
                            val quotaTxt = if (quotaObj != null) {
                                "${quotaObj.optInt("used_nodes", 0)}/${quotaObj.optInt("max_nodes", 0)} nodes"
                            } else "OK"
                            state = state.copy(isConnected = true, licenseQuotaText = quotaTxt, isBusy = false)
                            MassApiClient.prefetchNonces(state.effectiveEndpoint, state.caCertPem)
                        } else {
                            state = state.copy(isConnected = false, isBusy = false)
                        }
                    }.onFailure {
                        state = state.copy(isConnected = false, isBusy = false)
                    }
                }
            }

            is MassIntent.FetchDevices -> {
                scope.launch {
                    runCatching {
                        val res = MassApiClient.signedRequest(
                            baseUrl = state.effectiveEndpoint,
                            path = "/v1/nodes",
                            method = "GET",
                            caCertPem = state.caCertPem
                        )
                        if (res.statusCode in 200..299) {
                            val nodes = parseNodesFromJson(res.body)
                            val nextCpuHist = state.cpuHistory.toMutableMap()
                            val nextGpuHist = state.gpuHistory.toMutableMap()
                            nodes.forEach { n ->
                                nextCpuHist[n.id] = (nextCpuHist[n.id].orEmpty() + n.cpuPercent.toFloat()).takeLast(20)
                                nextGpuHist[n.id] = (nextGpuHist[n.id].orEmpty() + n.gpuPercent.toFloat()).takeLast(20)
                            }
                            state = state.copy(
                                devices = nodes,
                                cpuHistory = nextCpuHist,
                                gpuHistory = nextGpuHist,
                                isConnected = true,
                                selectedNodeId = state.selectedNodeId.ifBlank { nodes.firstOrNull()?.id ?: "" }
                            )
                        }
                    }
                }
            }

            is MassIntent.ExecuteCommand -> {
                if (state.safeModeEnabled) {
                    showToast(if (tr) "Güvenli mod aktif" else "Safe mode is active")
                    return
                }
                val termId = state.activeTerminalId
                val nodeName = state.devices.find { it.id == intent.targetNodeId }?.hostname ?: intent.targetNodeId
                if (intent.sudoPassword == null) {
                    val cmdEntry = ConsoleEntry(targetHostname = nodeName, text = intent.command, type = LogEntryType.Command)
                    state = state.copy(
                        terminals = state.terminals.map {
                            if (it.id == termId) it.copy(entries = (it.entries + cmdEntry).takeLast(200), pendingSudoCommand = null) else it
                        }
                    )
                }
                scope.launch {
                    state = state.copy(isBusy = true)
                    runCatching {
                        val payload = JSONObject().apply {
                            put("target_node_id", intent.targetNodeId)
                            put("session_id", termId)
                            put("command", intent.command)
                            if (intent.sudoPassword != null) put("sudo_password", intent.sudoPassword)
                        }
                        val res = MassApiClient.signedRequest(
                            baseUrl = state.effectiveEndpoint,
                            path = "/v1/console/exec",
                            method = "POST",
                            caCertPem = state.caCertPem,
                            jsonBody = payload.toString()
                        )
                        if (res.statusCode in 200..299) {
                            val obj = JSONObject(res.body)
                            val requiresPw = obj.optBoolean("requires_password", false)
                            val newCwd = obj.optString("cwd", "~").ifBlank { "~" }
                            val output = obj.optString("output", "")
                            val prompt = obj.optString("prompt", "[sudo] password:")
                            state = state.copy(
                                isBusy = false,
                                terminals = state.terminals.map { term ->
                                    if (term.id != termId) term
                                    else if (requiresPw) {
                                        term.copy(cwd = newCwd, pendingSudoCommand = intent.command, sudoPromptLabel = prompt)
                                    } else {
                                        val nextEntries = if (output.isNotBlank()) {
                                            (term.entries + ConsoleEntry(targetHostname = nodeName, text = output.trimEnd(), type = LogEntryType.Response)).takeLast(200)
                                        } else term.entries
                                        term.copy(cwd = newCwd, entries = nextEntries, pendingSudoCommand = null)
                                    }
                                }
                            )
                        } else {
                            val err = parseErrorMsg(res.body, "HTTP ${res.statusCode}")
                            state = state.copy(
                                isBusy = false,
                                terminals = state.terminals.map { term ->
                                    if (term.id == termId) term.copy(
                                        entries = (term.entries + ConsoleEntry(targetHostname = nodeName, text = "Hata: $err", type = LogEntryType.Response)).takeLast(200),
                                        pendingSudoCommand = null
                                    ) else term
                                }
                            )
                        }
                    }.onFailure { e ->
                        state = state.copy(isBusy = false)
                        showToast(e.message ?: "Terminal error")
                    }
                }
            }

            is MassIntent.ScanLocalAiModels -> {
                scope.launch {
                    state = state.copy(isBusy = true)
                    runCatching {
                        val res = MassApiClient.signedRequest(
                            baseUrl = state.effectiveEndpoint,
                            path = "/v1/ssa/models",
                            method = "GET",
                            caCertPem = state.caCertPem
                        )
                        if (res.statusCode in 200..299) {
                            val models = parseModelsFromJson(res.body)
                            state = state.copy(
                                localAiAvailable = models.isNotEmpty(),
                                localAiModels = models,
                                selectedAiModelId = state.selectedAiModelId.ifBlank { models.firstOrNull()?.id ?: "" },
                                isBusy = false
                            )
                        } else {
                            state = state.copy(isBusy = false)
                        }
                    }.onFailure { state = state.copy(isBusy = false) }
                }
            }

            is MassIntent.SendLocalAiQuery -> {
                val userMsg = LocalAiMessage(
                    senderLabel = if (tr) "Sen" else "You",
                    text = intent.query,
                    isFromUser = true
                )
                state = state.copy(
                    localAiMessages = state.localAiMessages + userMsg,
                    ssaThinkingStartMs = System.currentTimeMillis()
                )
                scope.launch {
                    runCatching {
                        var activeModelId = state.selectedAiModelId.ifBlank { state.localAiModels.firstOrNull()?.id ?: "" }
                        if (activeModelId.isBlank()) {
                            val mRes = MassApiClient.signedRequest(
                                baseUrl = state.effectiveEndpoint,
                                path = "/v1/ssa/models",
                                method = "GET",
                                caCertPem = state.caCertPem
                            )
                            if (mRes.statusCode in 200..299) {
                                val models = parseModelsFromJson(mRes.body)
                                activeModelId = models.firstOrNull()?.id ?: ""
                                if (models.isNotEmpty()) {
                                    state = state.copy(
                                        localAiAvailable = true,
                                        localAiModels = models,
                                        selectedAiModelId = activeModelId
                                    )
                                }
                            }
                        }
                        if (activeModelId.isBlank()) {
                            throw IllegalStateException(if (tr) "Ollama üzerinde aktif model bulunamadı." else "No active Ollama model found.")
                        }
                        val payload = JSONObject().apply {
                            put("model_id", activeModelId)
                            if (!state.selectedAiScopeNodeId.isNullOrBlank()) {
                                put("scope_node_id", state.selectedAiScopeNodeId)
                            } else {
                                put("scope_node_id", JSONObject.NULL)
                            }
                            put("query", intent.query)
                        }
                        val res = MassApiClient.signedRequest(
                            baseUrl = state.effectiveEndpoint,
                            path = "/v1/ssa/query",
                            method = "POST",
                            caCertPem = state.caCertPem,
                            jsonBody = payload.toString()
                        )
                        val rawReply = if (res.statusCode in 200..299) {
                            val obj = JSONObject(res.body)
                            obj.optString("response").ifBlank { obj.optString("answer", res.body) }
                        } else {
                            parseErrorMsg(res.body, "HTTP ${res.statusCode}")
                        }
                        val (think, answer) = splitThinkAndAnswer(rawReply)
                        val aiMsg = LocalAiMessage(
                            senderLabel = "MASS SI",
                            text = answer,
                            thinkingText = think,
                            isFromUser = false
                        )
                        state = state.copy(
                            localAiMessages = state.localAiMessages + aiMsg,
                            ssaThinkingStartMs = null
                        )
                    }.onFailure { e ->
                        val errMsg = LocalAiMessage(
                            senderLabel = "MASS SI",
                            text = e.message ?: (if (tr) "Yanıt alınamadı" else "Failed to query SI"),
                            isFromUser = false
                        )
                        state = state.copy(
                            localAiMessages = state.localAiMessages + errMsg,
                            ssaThinkingStartMs = null
                        )
                    }
                }
            }
        }
    }

    // İlk açılış kontrolü
    LaunchedEffect(Unit) {
        if (state.isDevicePaired) {
            state = state.copy(currentScreen = Screen.Dashboard)
            dispatch(MassIntent.CheckServerHealth)
            dispatch(MassIntent.FetchDevices)
            dispatch(MassIntent.ScanLocalAiModels)
        }
    }

    // Canlı telemetri döngüsü (3 sn) + Wi-Fi'a otomatik dönüş bekçisi
    LaunchedEffect(state.isDevicePaired, state.currentScreen) {
        if (!state.isDevicePaired) return@LaunchedEffect
        while (isActive) {
            delay(3000L)
            if (state.usingRemoteRoute && MassApiClient.quickProbe(state.apiEndpoint, state.caCertPem, 1200)) {
                state = state.copy(usingRemoteRoute = false)
            }
            if (state.currentScreen == Screen.Dashboard) {
                dispatch(MassIntent.FetchDevices)
            }
        }
    }

    if (desktopNodeId != null) {
        DesktopRemoteDialog(
            nodeId = desktopNodeId!!,
            state = state,
            onSendInput = { inputQueue.trySend(it) },
            onDismiss = { desktopNodeId = null }
        )
    }

    if (showGuide) {
        PortalGuideDialog(onDismiss = { showGuide = false })
    }

    val showChrome = state.currentScreen != Screen.Welcome && state.currentScreen != Screen.PrivacyPolicy

    Scaffold(
        containerColor = PortalPalette.Background,
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        topBar = {
            if (showChrome) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(PortalPalette.Background)
                        .statusBarsPadding()
                        .padding(horizontal = 16.dp, vertical = 10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "MASS",
                            style = PortalTypography.brandTitle,
                            color = PortalPalette.TextPrimary
                        )
                        Text(
                            text = "v3.0",
                            style = PortalTypography.monoCaption,
                            color = PortalPalette.TextSecondary
                        )
                    }
                    AnimatedVisibility(
                        visible = state.isBusy || state.ssaThinkingStartMs != null,
                        enter = fadeIn(),
                        exit = fadeOut()
                    ) {
                        MassRippleLoader(modifier = Modifier.padding(top = 6.dp))
                    }
                }
            }
        },
        bottomBar = {
            if (showChrome) {
                FlatMatteBottomBar(
                    current = state.currentScreen,
                    onSelect = { dispatch(MassIntent.Navigate(it)) }
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(PortalPalette.Background)
        ) {
            when (state.currentScreen) {
                Screen.Welcome -> WelcomeScreen(
                    state = state,
                    onContinue = {
                        dispatch(MassIntent.Navigate(Screen.Dashboard))
                        dispatch(MassIntent.CheckServerHealth)
                        dispatch(MassIntent.FetchDevices)
                    },
                    onOpenSettings = { dispatch(MassIntent.Navigate(Screen.Settings)) },
                    onOpenPrivacy = { dispatch(MassIntent.Navigate(Screen.PrivacyPolicy)) }
                )
                Screen.Dashboard -> DashboardScreen(
                    state = state,
                    onIntent = ::dispatch,
                    onOpenDesktop = { desktopNodeId = it },
                    onOpenGuide = { showGuide = true }
                )
                Screen.Console -> ConsoleScreen(state = state, onIntent = ::dispatch)
                Screen.SsaAgent -> SsaScreen(state = state, onIntent = ::dispatch)
                Screen.Settings -> SettingsScreen(
                    state = state,
                    onIntent = ::dispatch,
                    onOpenGuide = { showGuide = true }
                )
                Screen.PrivacyPolicy -> PrivacyPolicyScreen(
                    onBack = { dispatch(MassIntent.Navigate(if (state.isDevicePaired) Screen.Settings else Screen.Welcome)) }
                )
            }
        }
    }
}

@Composable
private fun FlatMatteBottomBar(
    current: Screen,
    onSelect: (Screen) -> Unit
) {
    val tr = isTurkish()
    val haptic = LocalHapticFeedback.current
    val tabs = remember(tr) {
        listOf(
            Screen.Dashboard to (if (tr) "Özet" else "Nodes"),
            Screen.Console to (if (tr) "Terminal" else "Console"),
            Screen.SsaAgent to "SI",
            Screen.Settings to (if (tr) "Ayarlar" else "Settings")
        )
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(PortalPalette.SurfaceCard)
            .navigationBarsPadding()
    ) {
        HorizontalDivider(thickness = 0.5.dp, color = PortalPalette.Hairline)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            tabs.forEach { (screen, label) ->
                val selected = current == screen
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .clickable {
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            onSelect(screen)
                        },
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Box(
                        modifier = Modifier
                            .width(28.dp)
                            .height(2.dp)
                            .background(if (selected) PortalPalette.Accent else PortalPalette.SurfaceCard)
                    )
                    Text(
                        text = label,
                        style = PortalTypography.monoMetric,
                        color = if (selected) PortalPalette.TextPrimary else PortalPalette.TextSecondary
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                }
            }
        }
    }
}
