package com.mass_solutions.mass.animations

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mass_solutions.mass.theme.PortalPalette
import com.mass_solutions.mass.theme.PortalTypography
import kotlin.math.abs

/**
 * Sade MASS Su Damlası Yükleme Animasyonu:
 * Alt çizgi, parlama veya halesi olmadan yalnızca M A S S karakterleri soldan sağa akar;
 * ortanın biraz solundaki kırılma noktasında yükselip büyür, sağa giderken küçülerek sönümlenir.
 */
@Composable
fun MassRippleLoader(modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "MassRippleLoader")
    val phase by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1500, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "RipplePhase"
    )
    val letters = remember { listOf("M", "A", "S", "S") }
    val dropletCenter = 0.36f

    BoxWithConstraints(
        modifier = modifier
            .fillMaxWidth()
            .height(24.dp),
        contentAlignment = Alignment.CenterStart
    ) {
        val totalW = maxWidth
        letters.forEachIndexed { idx, ch ->
            val p = ((phase + (idx - 3) * 0.085f) % 1f + 1f) % 1f
            val dist = abs(p - dropletCenter)
            val lensBoost = (1f - (dist / 0.18f).coerceIn(0f, 1f))
            val baseShrink = (1.0f - p * 0.65f).coerceAtLeast(0.28f)
            val scale = baseShrink + lensBoost * 0.48f
            val liftDp = (-4.5f * lensBoost).dp
            val alpha = when {
                p < 0.08f -> p / 0.08f
                p > 0.72f -> ((1f - p) / 0.28f).coerceIn(0f, 1f)
                else -> 1f
            }
            Text(
                text = ch,
                fontFamily = FontFamily.SansSerif,
                fontWeight = if (lensBoost > 0.35f) FontWeight.Normal else FontWeight.Light,
                fontSize = 12.sp,
                color = PortalPalette.TextPrimary.copy(alpha = 0.9f),
                modifier = Modifier
                    .align(Alignment.CenterStart)
                    .offset(x = totalW * p, y = liftDp)
                    .graphicsLayer {
                        scaleX = scale
                        scaleY = scale
                        this.alpha = alpha
                    }
            )
        }
    }
}

/**
 * İnce 3 dp çizgisel metrik çubuğu (düz, keskin, göz yormayan).
 */
@Composable
fun ThinMetricBar(
    label: String,
    valueText: String,
    progress: Float,
    isWarning: Boolean = false,
    modifier: Modifier = Modifier
) {
    val animProgress by animateFloatAsState(
        targetValue = progress.coerceIn(0f, 1f),
        animationSpec = tween(durationMillis = 480, easing = FastOutSlowInEasing),
        label = "ThinMetricAnim"
    )
    val barColor = if (isWarning) PortalPalette.StatusOffline else PortalPalette.Accent

    Column(modifier = modifier) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = label,
                style = PortalTypography.sectionOverline,
                color = PortalPalette.TextSecondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f, fill = false)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = valueText,
                style = PortalTypography.monoMetric,
                color = if (isWarning) PortalPalette.StatusOffline else PortalPalette.TextPrimary
            )
        }
        Spacer(modifier = Modifier.height(6.dp))
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(3.dp)
        ) {
            drawLine(
                color = PortalPalette.Hairline,
                start = Offset(0f, size.height / 2f),
                end = Offset(size.width, size.height / 2f),
                strokeWidth = size.height,
                cap = StrokeCap.Butt
            )
            val fillW = size.width * animProgress
            if (fillW > 0f) {
                drawLine(
                    color = barColor,
                    start = Offset(0f, size.height / 2f),
                    end = Offset(fillW, size.height / 2f),
                    strokeWidth = size.height,
                    cap = StrokeCap.Butt
                )
            }
        }
    }
}

/**
 * Sıfır harici kütüphaneli sade tek çizgi canlı sparkline grafiği (son 20 ölçüm).
 */
@Composable
fun MiniSparkline(
    values: List<Float>,
    lineColor: Color = PortalPalette.Accent,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier) {
        if (values.size < 2) return@Canvas
        val path = Path()
        val stepX = size.width / (values.size - 1).coerceAtLeast(1)
        values.forEachIndexed { idx, v ->
            val norm = (v / 100f).coerceIn(0f, 1f)
            val x = idx * stepX
            val y = size.height * (1f - norm)
            if (idx == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        drawPath(
            path = path,
            color = lineColor.copy(alpha = 0.85f),
            style = Stroke(width = 1.6.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
        )
    }
}
