package com.mass_solutions.mass.network

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaCodec
import android.media.MediaFormat
import android.os.Build
import android.view.Surface
import com.mass_solutions.mass.security.MassKeystoreManager
import com.mass_solutions.mass.security.SecurityGuard
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.net.InetAddress
import java.net.Socket
import java.net.URL
import java.net.URLEncoder
import java.security.KeyStore
import java.security.SecureRandom
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate
import java.util.Locale
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.atomic.AtomicReference
import javax.net.ssl.HostnameVerifier
import javax.net.ssl.HttpsURLConnection
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLEngine
import javax.net.ssl.SSLSocket
import javax.net.ssl.SSLSocketFactory
import javax.net.ssl.TrustManager
import javax.net.ssl.TrustManagerFactory
import javax.net.ssl.X509ExtendedTrustManager

data class ApiResponse(val statusCode: Int, val body: String)

data class BandwidthProfile(
    val label: String,
    val bitrateKbps: Int,
    val fps: Int,
    val scaleWidth: Int
)

object DynamicBandWidth {
    val LAN_MAX = BandwidthProfile("LAN 25M", bitrateKbps = 25000, fps = 60, scaleWidth = 1920)

    private val mobileTiers = listOf(
        BandwidthProfile("4G 2.2M", bitrateKbps = 2200,  fps = 30, scaleWidth = 1280),
        BandwidthProfile("4G 4.5M", bitrateKbps = 4500,  fps = 45, scaleWidth = 1920),
        BandwidthProfile("4G 7.5M", bitrateKbps = 7500,  fps = 60, scaleWidth = 1920),
        BandwidthProfile("5G 12M",  bitrateKbps = 12000, fps = 60, scaleWidth = 1920)
    )

    @Volatile
    private var currentMobileTierIndex = 2

    fun currentProfile(isMobileRemote: Boolean, requestedFps: Int): BandwidthProfile {
        if (!isMobileRemote) return LAN_MAX.copy(fps = requestedFps.coerceIn(30, 60))
        val tier = mobileTiers[currentMobileTierIndex.coerceIn(0, mobileTiers.lastIndex)]
        return tier.copy(fps = minOf(tier.fps, requestedFps.coerceIn(30, 60)))
    }

    fun adaptMobile(measuredFps: Int, targetFps: Int, stalled: Boolean): Boolean {
        val prev = currentMobileTierIndex
        if (stalled || (measuredFps in 1 until (targetFps * 0.65).toInt())) {
            currentMobileTierIndex = (currentMobileTierIndex - 1).coerceAtLeast(0)
        } else if (measuredFps >= (targetFps * 0.90).toInt()) {
            currentMobileTierIndex = (currentMobileTierIndex + 1).coerceAtMost(mobileTiers.lastIndex)
        }
        return currentMobileTierIndex != prev
    }
}

private class Tls13SocketFactory(private val delegate: SSLSocketFactory) : SSLSocketFactory() {
    override fun getDefaultCipherSuites(): Array<String> = delegate.defaultCipherSuites
    override fun getSupportedCipherSuites(): Array<String> = delegate.supportedCipherSuites

    private fun patch(socket: Socket): Socket {
        if (socket is SSLSocket) {
            val supported = socket.supportedProtocols.toSet()
            val preferred = listOf("TLSv1.3", "TLSv1.2").filter { it in supported }
            if (preferred.isNotEmpty()) socket.enabledProtocols = preferred.toTypedArray()
        }
        return socket
    }

    override fun createSocket(s: Socket, host: String, port: Int, autoClose: Boolean): Socket =
        patch(delegate.createSocket(s, host, port, autoClose))
    override fun createSocket(host: String, port: Int): Socket = patch(delegate.createSocket(host, port))
    override fun createSocket(host: String, port: Int, localHost: InetAddress, localPort: Int): Socket =
        patch(delegate.createSocket(host, port, localHost, localPort))
    override fun createSocket(host: InetAddress, port: Int): Socket = patch(delegate.createSocket(host, port))
    override fun createSocket(address: InetAddress, port: Int, localAddress: InetAddress, localPort: Int): Socket =
        patch(delegate.createSocket(address, port, localAddress, localPort))
}

object MassApiClient {
    private data class CachedNonce(val nonce: String, val expiresAtMs: Long)
    private val noncePool = ConcurrentLinkedQueue<CachedNonce>()

    @Volatile private var cachedSslPem: String? = null
    @Volatile private var cachedSslFactory: SSLSocketFactory? = null

    private fun buildSslSocketFactory(caCertPem: String): SSLSocketFactory {
        val trimmed = caCertPem.trim()
        val existing = cachedSslFactory
        if (existing != null && cachedSslPem == trimmed) return existing
        val sslCtx = if (trimmed.isNotEmpty()) {
            val cf = CertificateFactory.getInstance("X.509")
            val cert = cf.generateCertificate(ByteArrayInputStream(trimmed.toByteArray(Charsets.UTF_8)))
            val ks = KeyStore.getInstance(KeyStore.getDefaultType()).apply {
                load(null, null)
                setCertificateEntry("mass_ca", cert)
            }
            val tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm()).apply { init(ks) }
            SSLContext.getInstance("TLS").apply { init(null, tmf.trustManagers, SecureRandom()) }
        } else {
            val trustAll = arrayOf<TrustManager>(
                object : X509ExtendedTrustManager() {
                    override fun checkClientTrusted(c: Array<out X509Certificate>?, a: String?) {}
                    override fun checkServerTrusted(c: Array<out X509Certificate>?, a: String?) {}
                    override fun checkClientTrusted(c: Array<out X509Certificate>?, a: String?, s: Socket?) {}
                    override fun checkServerTrusted(c: Array<out X509Certificate>?, a: String?, s: Socket?) {}
                    override fun checkClientTrusted(c: Array<out X509Certificate>?, a: String?, e: SSLEngine?) {}
                    override fun checkServerTrusted(c: Array<out X509Certificate>?, a: String?, e: SSLEngine?) {}
                    override fun getAcceptedIssuers(): Array<X509Certificate> = emptyArray()
                }
            )
            SSLContext.getInstance("TLS").apply { init(null, trustAll, SecureRandom()) }
        }
        val factory = Tls13SocketFactory(sslCtx.socketFactory)
        cachedSslPem = trimmed
        cachedSslFactory = factory
        return factory
    }

    suspend fun quickProbe(baseUrl: String, caCertPem: String, timeoutMs: Int = 2000): Boolean =
        withContext(Dispatchers.IO) {
            val trimmed = baseUrl.trim()
            if (trimmed.isEmpty()) return@withContext false
            runCatching {
                val cleanBase = SecurityGuard.normalizeServerAddress(trimmed).trimEnd('/')
                val conn = (URL("$cleanBase/v1/auth/challenge").openConnection() as? HttpsURLConnection)
                    ?: return@withContext false
                try {
                    conn.sslSocketFactory = buildSslSocketFactory(caCertPem)
                    conn.hostnameVerifier = HostnameVerifier { _, _ -> true }
                    conn.requestMethod = "GET"
                    conn.connectTimeout = timeoutMs
                    conn.readTimeout = timeoutMs
                    conn.responseCode in 200..299
                } finally {
                    conn.disconnect()
                }
            }.getOrDefault(false)
        }

    suspend fun request(
        baseUrl: String,
        path: String,
        method: String,
        caCertPem: String,
        jsonBody: String? = null,
        headers: Map<String, String> = emptyMap()
    ): ApiResponse = withContext(Dispatchers.IO) {
        val cleanBase = SecurityGuard.normalizeServerAddress(baseUrl).trimEnd('/')
        val conn = (URL("$cleanBase$path").openConnection() as? HttpsURLConnection)
            ?: throw IllegalStateException("Yalnızca HTTPS bağlantıları desteklenir.")
        try {
            conn.sslSocketFactory = buildSslSocketFactory(caCertPem)
            conn.hostnameVerifier = HostnameVerifier { _, _ -> true }
            conn.requestMethod = method
            conn.connectTimeout = 8000
            conn.readTimeout = if (path.startsWith("/v1/ssa/query")) 900_000 else 15_000
            conn.setRequestProperty("Accept", "application/json")
            conn.setRequestProperty("Connection", "keep-alive")
            headers.forEach { (k, v) -> conn.setRequestProperty(k, v) }

            if (jsonBody != null) {
                conn.doOutput = true
                conn.setRequestProperty("Content-Type", "application/json")
                conn.outputStream.use { it.write(jsonBody.toByteArray(Charsets.UTF_8)) }
            }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            if (code !in 200..299) conn.disconnect()
            ApiResponse(code, text)
        } catch (e: Exception) {
            conn.disconnect()
            throw e
        }
    }

    suspend fun prefetchNonces(baseUrl: String, caCertPem: String, targetCount: Int = 12) {
        val now = System.currentTimeMillis()
        while (noncePool.peek()?.let { it.expiresAtMs <= now } == true) noncePool.poll()
        val needed = (targetCount - noncePool.size).coerceAtLeast(0)
        repeat(needed) {
            runCatching {
                val res = request(baseUrl, "/v1/auth/challenge", "GET", caCertPem)
                if (res.statusCode in 200..299) {
                    val n = JSONObject(res.body).optString("nonce", "")
                    if (n.isNotEmpty()) noncePool.offer(CachedNonce(n, System.currentTimeMillis() + 22_000L))
                }
            }
        }
    }

    private suspend fun acquireNonce(baseUrl: String, caCertPem: String): Pair<String?, ApiResponse?> {
        val now = System.currentTimeMillis()
        while (true) {
            val item = noncePool.poll() ?: break
            if (item.expiresAtMs > now) return item.nonce to null
        }
        val challengeRes = request(baseUrl, "/v1/auth/challenge", "GET", caCertPem)
        if (challengeRes.statusCode !in 200..299) return null to challengeRes
        return JSONObject(challengeRes.body).optString("nonce", "") to null
    }

    suspend fun signedRequest(
        baseUrl: String,
        path: String,
        method: String,
        caCertPem: String,
        jsonBody: String? = null
    ): ApiResponse {
        val (fetchedNonce, errRes) = acquireNonce(baseUrl, caCertPem)
        if (errRes != null) return errRes
        val nonce = fetchedNonce ?: ""
        if (nonce.isEmpty()) return ApiResponse(500, """{"error":"Challenge yanıtında nonce bulunamadı"}""")
        val sig = MassKeystoreManager.signCanonicalRequestBase64(
            method = method.uppercase(Locale.ROOT),
            path = path.substringBefore("?"),
            nonce = nonce,
            body = jsonBody ?: ""
        )
        return request(
            baseUrl = baseUrl,
            path = path,
            method = method,
            caCertPem = caCertPem,
            jsonBody = jsonBody,
            headers = mapOf("X-MASS-Nonce" to nonce, "X-MASS-Signature" to sig)
        )
    }

    suspend fun streamDesktopH264(
        baseUrl: String,
        nodeId: String,
        fps: Int,
        bitrateKbps: Int,
        scaleWidth: Int,
        caCertPem: String,
        surface: Surface,
        onFrameRendered: () -> Unit
    ) = withContext(Dispatchers.IO) {
        val (fetchedNonce, errRes) = acquireNonce(baseUrl, caCertPem)
        if (errRes != null || fetchedNonce.isNullOrEmpty()) {
            throw IllegalStateException("Challenge HTTP ${errRes?.statusCode ?: 500}")
        }
        val encodedNode = URLEncoder.encode(nodeId, "UTF-8")
        val pathOnly = "/v1/desktop/h264"
        val fullPath = "$pathOnly?node_id=$encodedNode&fps=$fps&bitrate=$bitrateKbps&scale=$scaleWidth"
        val sig = MassKeystoreManager.signCanonicalRequestBase64("GET", pathOnly, fetchedNonce, "")

        val cleanBase = SecurityGuard.normalizeServerAddress(baseUrl).trimEnd('/')
        val conn = (URL("$cleanBase$fullPath").openConnection() as? HttpsURLConnection)
            ?: throw IllegalStateException("Yalnızca HTTPS desteklenir.")

        var codec: MediaCodec? = null
        try {
            conn.sslSocketFactory = buildSslSocketFactory(caCertPem)
            conn.hostnameVerifier = HostnameVerifier { _, _ -> true }
            conn.requestMethod = "GET"
            conn.connectTimeout = 8000
            conn.readTimeout = 15000
            conn.setRequestProperty("Accept", "application/octet-stream")
            conn.setRequestProperty("X-MASS-Nonce", fetchedNonce)
            conn.setRequestProperty("X-MASS-Signature", sig)

            val code = conn.responseCode
            if (code !in 200..299) {
                val errBody = runCatching { conn.errorStream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: "" }.getOrDefault("")
                throw IllegalStateException("H264 HTTP $code: $errBody")
            }

            val format = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, scaleWidth, (scaleWidth * 9) / 16)
            if (Build.VERSION.SDK_INT >= 30) format.setInteger(MediaFormat.KEY_LOW_LATENCY, 1)
            val dec = MediaCodec.createDecoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
            dec.configure(format, surface, null, 0)
            dec.start()
            codec = dec

            val info = MediaCodec.BufferInfo()
            fun feedNal(nalBytes: ByteArray) {
                if (nalBytes.size < 5) return
                val inIdx = dec.dequeueInputBuffer(10_000L)
                if (inIdx >= 0) {
                    val buf = dec.getInputBuffer(inIdx)
                    if (buf != null && buf.capacity() >= nalBytes.size) {
                        buf.clear()
                        buf.put(nalBytes)
                        dec.queueInputBuffer(inIdx, 0, nalBytes.size, System.nanoTime() / 1000L, 0)
                    } else {
                        dec.queueInputBuffer(inIdx, 0, 0, 0L, 0)
                    }
                }
                while (true) {
                    val outIdx = dec.dequeueOutputBuffer(info, 0L)
                    if (outIdx >= 0) {
                        dec.releaseOutputBuffer(outIdx, true)
                        onFrameRendered()
                    } else break
                }
            }

            conn.inputStream.use { input ->
                val readBuf = ByteArray(32768)
                val nalOut = ByteArrayOutputStream(131072)
                var zeroCount = 0
                var started = false
                while (currentCoroutineContext().isActive) {
                    val count = input.read(readBuf)
                    if (count <= 0) break
                    for (i in 0 until count) {
                        val b = readBuf[i].toInt() and 0xFF
                        if (b == 0) {
                            zeroCount++
                            if (started) nalOut.write(0)
                        } else if (b == 1 && zeroCount >= 3) {
                            if (started) {
                                val raw = nalOut.toByteArray()
                                val trimLen = (raw.size - zeroCount).coerceAtLeast(0)
                                if (trimLen > 4) feedNal(raw.copyOf(trimLen))
                            }
                            nalOut.reset()
                            nalOut.write(0); nalOut.write(0); nalOut.write(0); nalOut.write(1)
                            started = true
                            zeroCount = 0
                        } else {
                            zeroCount = 0
                            if (started) nalOut.write(b)
                        }
                        if (nalOut.size() > 2 * 1024 * 1024) {
                            nalOut.reset()
                            started = false
                        }
                    }
                }
            }
        } finally {
            runCatching { codec?.stop() }
            runCatching { codec?.release() }
            conn.disconnect()
        }
    }

    suspend fun streamDesktopMjpeg(
        baseUrl: String,
        nodeId: String,
        fps: Int,
        quality: Int,
        scaleWidth: Int,
        caCertPem: String,
        onFrame: (Bitmap) -> Unit
    ) = withContext(Dispatchers.IO) {
        val (fetchedNonce, errRes) = acquireNonce(baseUrl, caCertPem)
        if (errRes != null || fetchedNonce.isNullOrEmpty()) {
            throw IllegalStateException("Challenge HTTP ${errRes?.statusCode ?: 500}")
        }
        val encodedNode = URLEncoder.encode(nodeId, "UTF-8")
        val pathOnly = "/v1/desktop/stream"
        val fullPath = "$pathOnly?node_id=$encodedNode&fps=$fps&quality=$quality&scale=$scaleWidth"
        val sig = MassKeystoreManager.signCanonicalRequestBase64("GET", pathOnly, fetchedNonce, "")

        val cleanBase = SecurityGuard.normalizeServerAddress(baseUrl).trimEnd('/')
        val conn = (URL("$cleanBase$fullPath").openConnection() as? HttpsURLConnection)
            ?: throw IllegalStateException("Yalnızca HTTPS desteklenir.")

        try {
            conn.sslSocketFactory = buildSslSocketFactory(caCertPem)
            conn.hostnameVerifier = HostnameVerifier { _, _ -> true }
            conn.requestMethod = "GET"
            conn.connectTimeout = 8000
            conn.readTimeout = 15000
            conn.setRequestProperty("Accept", "multipart/x-mixed-replace")
            conn.setRequestProperty("X-MASS-Nonce", fetchedNonce)
            conn.setRequestProperty("X-MASS-Signature", sig)

            val code = conn.responseCode
            if (code !in 200..299) {
                val errBody = runCatching { conn.errorStream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: "" }.getOrDefault("")
                throw IllegalStateException("Stream HTTP $code: $errBody")
            }

            val decodeOpts = BitmapFactory.Options().apply { inPreferredConfig = Bitmap.Config.RGB_565 }
            val latestJpeg = AtomicReference<ByteArray?>(null)
            val decoderJob = CoroutineScope(currentCoroutineContext() + Dispatchers.Default).launch {
                while (isActive) {
                    val frameBytes = latestJpeg.getAndSet(null)
                    if (frameBytes != null) {
                        val bmp = BitmapFactory.decodeByteArray(frameBytes, 0, frameBytes.size, decodeOpts)
                        if (bmp != null) withContext(Dispatchers.Main.immediate) { onFrame(bmp) }
                    } else delay(4)
                }
            }
            try {
                conn.inputStream.use { input ->
                    val readBuf = ByteArray(65536)
                    val jpegOut = ByteArrayOutputStream(131072)
                    var inFrame = false
                    var prevByte = -1
                    while (currentCoroutineContext().isActive) {
                        val count = input.read(readBuf)
                        if (count <= 0) break
                        for (i in 0 until count) {
                            val b = readBuf[i].toInt() and 0xFF
                            if (!inFrame) {
                                if (prevByte == 0xFF && b == 0xD8) {
                                    jpegOut.reset(); jpegOut.write(0xFF); jpegOut.write(0xD8); inFrame = true
                                }
                            } else {
                                jpegOut.write(b)
                                if (prevByte == 0xFF && b == 0xD9) {
                                    latestJpeg.set(jpegOut.toByteArray()); inFrame = false
                                } else if (jpegOut.size() > 4 * 1024 * 1024) {
                                    jpegOut.reset(); inFrame = false
                                }
                            }
                            prevByte = b
                        }
                    }
                }
            } finally {
                decoderJob.cancel()
            }
        } finally {
            conn.disconnect()
        }
    }
}
