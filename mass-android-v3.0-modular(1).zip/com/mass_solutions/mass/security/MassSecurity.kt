package com.mass_solutions.mass.security

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.net.URI
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.MessageDigest
import java.security.PrivateKey
import java.security.Signature
import java.security.spec.ECGenParameterSpec

object MassKeystoreManager {
    private const val ANDROID_KEYSTORE = "AndroidKeyStore"
    private const val KEY_ALIAS = "mass_portal_device_ec_p256"

    private fun ensureKeyPair(): KeyStore.PrivateKeyEntry {
        val ks = KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }
        val existing = ks.getEntry(KEY_ALIAS, null) as? KeyStore.PrivateKeyEntry
        if (existing != null) return existing

        val kpg = KeyPairGenerator.getInstance(KeyProperties.KEY_ALGORITHM_EC, ANDROID_KEYSTORE)
        val spec = KeyGenParameterSpec.Builder(
            KEY_ALIAS,
            KeyProperties.PURPOSE_SIGN or KeyProperties.PURPOSE_VERIFY
        )
            .setAlgorithmParameterSpec(ECGenParameterSpec("secp256r1"))
            .setDigests(KeyProperties.DIGEST_SHA256)
            .build()
        kpg.initialize(spec)
        kpg.generateKeyPair()
        return ks.getEntry(KEY_ALIAS, null) as KeyStore.PrivateKeyEntry
    }

    fun getPublicKeyPem(): String {
        val entry = ensureKeyPair()
        val encoded = Base64.encodeToString(entry.certificate.publicKey.encoded, Base64.NO_WRAP)
        val wrapped = encoded.chunked(64).joinToString("\n")
        return "-----BEGIN PUBLIC KEY-----\n$wrapped\n-----END PUBLIC KEY-----"
    }

    private fun sha256Hex(input: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
            .digest(input.toByteArray(Charsets.UTF_8))
        return digest.joinToString("") { "%02x".format(it) }
    }

    fun signCanonicalRequestBase64(
        method: String,
        path: String,
        nonce: String,
        body: String
    ): String {
        val entry = ensureKeyPair()
        val privateKey: PrivateKey = entry.privateKey
        val canonicalMsg = "$method\n$path\n$nonce\n${sha256Hex(body)}"
        val sig = Signature.getInstance("SHA256withECDSA").apply {
            initSign(privateKey)
            update(canonicalMsg.toByteArray(Charsets.UTF_8))
        }
        return Base64.encodeToString(sig.sign(), Base64.NO_WRAP)
    }
}

object SecurityGuard {
    const val MAX_INPUT_LENGTH = 512

    fun normalizeServerAddress(rawInput: String): String {
        var s = rawInput.trim().trimEnd('/')
        if (s.isEmpty()) return ""
        if (s.startsWith("http://", ignoreCase = true)) {
            s = "https://" + s.substring(7)
        } else if (!s.startsWith("https://", ignoreCase = true)) {
            s = "https://$s"
        }
        return try {
            val uri = URI(s)
            val host = uri.host ?: return s
            val isIpOrLocal = host == "localhost" || host.all { it.isDigit() || it == '.' }
            if (uri.port == -1 && isIpOrLocal) "https://$host:6277" else s
        } catch (_: Exception) {
            s
        }
    }

    fun validateHttpsEndpoint(rawUrl: String, isTr: Boolean): String? {
        val trimmed = rawUrl.trim()
        if (trimmed.isEmpty()) {
            return if (isTr) "Endpoint adresi boş bırakılamaz." else "Endpoint URL cannot be empty."
        }
        return try {
            val uri = URI(trimmed)
            when {
                !uri.scheme.equals("https", ignoreCase = true) ->
                    if (isTr) "Yalnızca HTTPS protokolü kabul edilir." else "Only HTTPS protocol is permitted."
                uri.host.isNullOrBlank() ->
                    if (isTr) "Geçerli bir sunucu IP veya alan adı girin." else "Enter a valid server host or IP."
                else -> null
            }
        } catch (_: Exception) {
            if (isTr) "Geçersiz URL biçimi." else "Invalid URL format."
        }
    }
}

object PortalPrefs {
    private const val PREF_NAME = "mass_portal_prefs"
    private const val KEY_ENDPOINT = "api_endpoint"
    private const val KEY_REMOTE_ENDPOINT = "remote_api_endpoint"
    private const val KEY_CA_PEM = "ca_cert_pem"
    private const val KEY_PAIRED = "is_paired"

    fun loadEndpoint(ctx: Context): String =
        ctx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            .getString(KEY_ENDPOINT, "https://192.168.1.109:6277") ?: "https://192.168.1.109:6277"

    fun loadRemoteEndpoint(ctx: Context): String =
        ctx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            .getString(KEY_REMOTE_ENDPOINT, "") ?: ""

    fun loadCaPem(ctx: Context): String =
        ctx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            .getString(KEY_CA_PEM, "") ?: ""

    fun loadPaired(ctx: Context): Boolean =
        ctx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            .getBoolean(KEY_PAIRED, false)

    fun saveEndpoint(ctx: Context, value: String) {
        ctx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE).edit().putString(KEY_ENDPOINT, value).apply()
    }

    fun saveRemoteEndpoint(ctx: Context, value: String) {
        ctx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE).edit().putString(KEY_REMOTE_ENDPOINT, value).apply()
    }

    fun saveCaPem(ctx: Context, value: String) {
        ctx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE).edit().putString(KEY_CA_PEM, value).apply()
    }

    fun savePaired(ctx: Context, paired: Boolean) {
        ctx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE).edit().putBoolean(KEY_PAIRED, paired).apply()
    }
}
