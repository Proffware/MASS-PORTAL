package com.mass_solutions.mass.state

import android.content.Context
import androidx.compose.runtime.mutableStateOf
import com.mass_solutions.mass.security.PortalPrefs
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import java.util.UUID
import kotlin.math.roundToInt

enum class Screen { Welcome, Dashboard, Console, SsaAgent, Settings, PrivacyPolicy }
enum class NodeStatus { Online, Degraded, Offline }
enum class NodeFilter { All, Online, Offline }
enum class LogEntryType { Command, Response }

data class GpuMetric(
    val name: String,
    val kind: String,
    val utilPercent: Int,
    val tempCelsius: Int,
    val vramUsedGb: Double,
    val vramTotalGb: Double
)

data class DiskMetric(
    val device: String,
    val mount: String,
    val usedGb: Double,
    val totalGb: Double,
    val percent: Int
)

data class PortMetric(
    val name: String,
    val detail: String,
    val active: Boolean
)

data class DeviceInfo(
    val id: String,
    val hostname: String,
    val role: String,
    val status: NodeStatus,
    val cpuPercent: Int,
    val tempCelsius: Int,
    val ramUsedGb: Double,
    val ramTotalGb: Double,
    val gpuName: String,
    val gpuPercent: Int,
    val gpuTempCelsius: Int,
    val gpuVramUsedGb: Double,
    val gpuVramTotalGb: Double,
    val diskSummary: String,
    val ipAddress: String,
    val uptime: String,
    val lastSync: String,
    val gpus: List<GpuMetric> = emptyList(),
    val disks: List<DiskMetric> = emptyList(),
    val ports: List<PortMetric> = emptyList()
)

data class ConsoleEntry(
    val id: String = UUID.randomUUID().toString(),
    val targetHostname: String,
    val text: String,
    val type: LogEntryType,
    val timestamp: Long = System.currentTimeMillis()
)

data class TerminalSession(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val targetNodeId: String = "",
    val entries: List<ConsoleEntry> = emptyList(),
    val cwd: String = "~",
    val pendingSudoCommand: String? = null,
    val sudoPromptLabel: String = "[sudo] password:"
)

data class LocalAiModel(
    val id: String,
    val name: String,
    val runtime: String,
    val quant: String,
    val contextWindow: String
)

data class LocalAiMessage(
    val id: String = UUID.randomUUID().toString(),
    val senderLabel: String,
    val text: String,
    val thinkingText: String? = null,
    val isFromUser: Boolean,
    val timestamp: Long = System.currentTimeMillis()
)

sealed interface MassIntent {
    data class Navigate(val screen: Screen) : MassIntent
    data class SelectNodeForConsole(val nodeId: String) : MassIntent
    data class UpdateSearchQuery(val query: String) : MassIntent
    data class UpdateNodeFilter(val filter: NodeFilter) : MassIntent
    data class ExecuteCommand(val command: String, val targetNodeId: String, val sudoPassword: String? = null) : MassIntent
    data object CancelSudoPrompt : MassIntent
    data object ClearConsole : MassIntent
    data object CreateTerminal : MassIntent
    data class SelectTerminal(val terminalId: String) : MassIntent
    data class CloseTerminal(val terminalId: String) : MassIntent
    data class SelectLocalAiModel(val modelId: String) : MassIntent
    data class SelectLocalAiScopeNode(val nodeId: String?) : MassIntent
    data class SendLocalAiQuery(val query: String) : MassIntent
    data object ScanLocalAiModels : MassIntent
    data object ClearLocalAiChat : MassIntent
    data object FetchDevices : MassIntent
    data object CheckServerHealth : MassIntent
    data class PairDevice(val pairCode: String) : MassIntent
    data object ResetLocalPairing : MassIntent
    data class UpdateEndpoint(val endpoint: String) : MassIntent
    data class UpdateRemoteEndpoint(val endpoint: String) : MassIntent
    data class UpdateCaCertPem(val pem: String) : MassIntent
    data class ToggleSafeMode(val enabled: Boolean) : MassIntent
}

data class MassPortalState(
    val currentScreen: Screen = Screen.Welcome,
    val devices: List<DeviceInfo> = emptyList(),
    val cpuHistory: Map<String, List<Float>> = emptyMap(),
    val gpuHistory: Map<String, List<Float>> = emptyMap(),
    val isConnected: Boolean = false,
    val isBusy: Boolean = false,
    val licenseQuotaText: String = "UNVERIFIED",
    val searchQuery: String = "",
    val nodeFilter: NodeFilter = NodeFilter.All,
    val selectedNodeId: String = "",
    val terminals: List<TerminalSession> = listOf(TerminalSession(id = "term-1", title = "Terminal 1")),
    val activeTerminalId: String = "term-1",
    val nextTerminalNumber: Int = 2,
    val ssaThinkingStartMs: Long? = null,
    val localAiAvailable: Boolean = false,
    val localAiModels: List<LocalAiModel> = emptyList(),
    val selectedAiModelId: String = "",
    val selectedAiScopeNodeId: String? = null,
    val localAiMessages: List<LocalAiMessage> = emptyList(),
    val apiEndpoint: String = "https://192.168.1.109:6277",
    val remoteEndpoint: String = "",
    val usingRemoteRoute: Boolean = false,
    val endpointError: String? = null,
    val caCertPem: String = "",
    val isDevicePaired: Boolean = false,
    val safeModeEnabled: Boolean = false
) {
    val activeTerminal: TerminalSession
        get() = terminals.find { it.id == activeTerminalId } ?: terminals.first()

    val effectiveEndpoint: String
        get() = if (usingRemoteRoute && remoteEndpoint.isNotBlank()) remoteEndpoint else apiEndpoint
}

object MassPortalSession {
    private var initialized = false
    val stateHolder = mutableStateOf(MassPortalState())
    val desktopNodeIdHolder = mutableStateOf<String?>(null)

    fun ensureInitialized(context: Context) {
        if (!initialized) {
            stateHolder.value = MassPortalState(
                apiEndpoint = PortalPrefs.loadEndpoint(context),
                remoteEndpoint = PortalPrefs.loadRemoteEndpoint(context),
                caCertPem = PortalPrefs.loadCaPem(context),
                isDevicePaired = PortalPrefs.loadPaired(context)
            )
            initialized = true
        }
    }
}

// ------------------------------------------------------------------
// JSON AYRIŞTIRMA YARDIMCILARI
// ------------------------------------------------------------------

fun splitThinkAndAnswer(raw: String): Pair<String?, String> {
    val sIdx = raw.indexOf("<think>", ignoreCase = true)
    val eIdx = raw.indexOf("</think>", ignoreCase = true)
    if (sIdx != -1 && eIdx != -1 && eIdx > sIdx) {
        val think = raw.substring(sIdx + 7, eIdx).trim()
        val answer = (raw.substring(0, sIdx) + raw.substring(eIdx + 8)).trim()
        return (think.ifEmpty { null }) to answer.ifEmpty { raw }
    }
    return null to raw.trim()
}

fun parseErrorMsg(body: String, fallback: String): String = try {
    val obj = JSONObject(body)
    obj.optString("error").ifBlank { obj.optString("message").ifBlank { fallback } }
} catch (_: Exception) {
    fallback
}

private fun normalizeMemoryGb(raw: Double): Double {
    if (!raw.isFinite() || raw <= 0.0) return 0.0
    val gb = when {
        raw > 1024.0 * 1024.0 * 512.0 -> raw / (1024.0 * 1024.0 * 1024.0)
        raw > 1024.0 * 512.0 -> raw / (1024.0 * 1024.0)
        raw > 2048.0 -> raw / 1024.0
        else -> raw
    }
    return ((gb * 10.0).roundToInt() / 10.0).coerceIn(0.0, 2048.0)
}

private fun normalizeTempCelsius(raw: Double): Int {
    if (!raw.isFinite() || raw <= 0.0) return 0
    val c = when {
        raw > 1000.0 -> raw / 1000.0
        raw > 200.0 -> raw / 10.0
        else -> raw
    }
    return c.roundToInt().coerceIn(0, 125)
}

private fun formatUptimeSec(uptimeSec: Long, fallback: String): String {
    if (uptimeSec <= 0L) return fallback
    val days = uptimeSec / 86400
    val hours = (uptimeSec % 86400) / 3600
    val mins = (uptimeSec % 3600) / 60
    return when {
        days > 0 -> "${days}g ${hours}s"
        hours > 0 -> "${hours}s ${mins}dk"
        else -> "${mins}dk"
    }
}

fun parseNodesFromJson(body: String): List<DeviceInfo> {
    val array = try {
        JSONObject(body).optJSONArray("nodes") ?: JSONArray()
    } catch (_: Exception) {
        JSONArray(body)
    }
    val list = mutableListOf<DeviceInfo>()
    for (i in 0 until array.length()) {
        val o = array.getJSONObject(i)
        val statusStr = o.optString("status", "online").lowercase(Locale.ROOT)
        val cpu = o.optDouble("cpu_percent", 0.0).let { if (it.isFinite()) it.roundToInt().coerceIn(0, 100) else 0 }
        val ramUsed = normalizeMemoryGb(o.optDouble("ram_used_gb", 0.0))
        val ramTotal = normalizeMemoryGb(o.optDouble("ram_total_gb", 0.0)).coerceAtLeast(if (ramUsed > 0) ramUsed else 1.0)
        val temp = normalizeTempCelsius(if (o.has("cpu_temp_c")) o.optDouble("cpu_temp_c", 0.0) else o.optDouble("temp_celsius", 0.0))
        val gpuPct = o.optDouble("gpu_percent", 0.0).let { if (it.isFinite()) it.roundToInt().coerceIn(0, 100) else 0 }
        val gpuTemp = normalizeTempCelsius(if (o.has("gpu_temp_c")) o.optDouble("gpu_temp_c", 0.0) else o.optDouble("gpu_temp_celsius", 0.0))
        val diskUsed = o.optDouble("disk_used_gb", 0.0)
        val diskTotal = o.optDouble("disk_total_gb", 0.0)
        val diskSummary = if (diskTotal > 0.0) String.format(Locale.US, "%.1f / %.1f GB", diskUsed, diskTotal)
        else o.optString("disk_summary", "-")
        val uptimeSec = if (o.has("uptime") && o.optLong("uptime", 0L) > 0L) o.optLong("uptime", 0L) else o.optLong("uptime_sec", 0L)

        val status = when {
            statusStr.contains("off") -> NodeStatus.Offline
            statusStr.contains("deg") || statusStr.contains("warn") || cpu >= 85 || temp >= 80 -> NodeStatus.Degraded
            else -> NodeStatus.Online
        }

        list.add(
            DeviceInfo(
                id = o.optString("node_id", o.optString("id", "node-$i")),
                hostname = o.optString("hostname", o.optString("node_id", "unknown")),
                role = o.optString("role", "server"),
                status = status,
                cpuPercent = cpu,
                tempCelsius = temp,
                ramUsedGb = ramUsed,
                ramTotalGb = ramTotal,
                gpuName = o.optString("gpu_name", "GPU"),
                gpuPercent = gpuPct,
                gpuTempCelsius = gpuTemp,
                gpuVramUsedGb = normalizeMemoryGb(o.optDouble("gpu_vram_used_gb", 0.0)),
                gpuVramTotalGb = normalizeMemoryGb(o.optDouble("gpu_vram_total_gb", 0.0)),
                diskSummary = diskSummary,
                ipAddress = o.optString("ip", "-"),
                uptime = formatUptimeSec(uptimeSec, o.optString("uptime", "-")),
                lastSync = o.optString("last_sync", o.optString("last_seen", "şimdi")),
                gpus = buildList {
                    val ga = o.optJSONArray("gpus") ?: return@buildList
                    for (j in 0 until ga.length()) {
                        val g = ga.optJSONObject(j) ?: continue
                        add(
                            GpuMetric(
                                name = g.optString("name", "GPU"),
                                kind = g.optString("kind", "dedicated"),
                                utilPercent = g.optDouble("util_percent", 0.0).roundToInt().coerceIn(0, 100),
                                tempCelsius = normalizeTempCelsius(g.optDouble("temp_c", 0.0)),
                                vramUsedGb = normalizeMemoryGb(g.optDouble("vram_used_gb", 0.0)),
                                vramTotalGb = normalizeMemoryGb(g.optDouble("vram_total_gb", 0.0))
                            )
                        )
                    }
                },
                disks = buildList {
                    val da = o.optJSONArray("disks") ?: return@buildList
                    for (j in 0 until da.length()) {
                        val d = da.optJSONObject(j) ?: continue
                        add(
                            DiskMetric(
                                device = d.optString("device", "disk"),
                                mount = d.optString("mount", "/"),
                                usedGb = normalizeMemoryGb(d.optDouble("used_gb", 0.0)),
                                totalGb = normalizeMemoryGb(d.optDouble("total_gb", 0.0)).coerceAtLeast(0.1),
                                percent = d.optDouble("percent", 0.0).roundToInt().coerceIn(0, 100)
                            )
                        )
                    }
                },
                ports = buildList {
                    val pa = o.optJSONArray("network_ports") ?: return@buildList
                    for (j in 0 until pa.length()) {
                        val pt = pa.optJSONObject(j) ?: continue
                        add(
                            PortMetric(
                                name = pt.optString("name", ""),
                                detail = pt.optString("detail", ""),
                                active = pt.optBoolean("active", false)
                            )
                        )
                    }
                }
            )
        )
    }

    return list
        .sortedByDescending { (if (it.ramTotalGb > 1.0) 1000 else 0) + it.cpuPercent + it.tempCelsius }
        .distinctBy { if (it.ipAddress != "-" && it.ipAddress != "127.0.0.1") it.ipAddress else it.hostname }
}

fun parseModelsFromJson(body: String): List<LocalAiModel> {
    val array = try {
        JSONObject(body).optJSONArray("models") ?: JSONArray()
    } catch (_: Exception) {
        JSONArray(body)
    }
    return buildList {
        for (i in 0 until array.length()) {
            val o = array.getJSONObject(i)
            add(
                LocalAiModel(
                    id = o.optString("id", "model-$i"),
                    name = o.optString("name", o.optString("id", "Local Model")),
                    runtime = o.optString("runtime", "Ollama"),
                    quant = o.optString("quant", "-"),
                    contextWindow = o.optString("context_window", "-")
                )
            )
        }
    }
}
