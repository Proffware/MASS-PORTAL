package com.mass_solutions.mass.theme

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.LocalIndication
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// ------------------------------------------------------------------
// MAT ANTRASİT PALET (SIFIR PARLAMA, SIFIR SAHTE CAM, TON FARKIYLA DERİNLİK)
// ------------------------------------------------------------------

object PortalPalette {
    val Background      = Color(0xFF0E1013) // Zemin
    val SurfaceCard     = Color(0xFF15181D) // Kart
    val SurfaceElevated = Color(0xFF1C2027) // İç satır / dal
    val Hairline        = Color(0xFF262B34) // 0.5 dp saç teli ayrım
    val TextPrimary     = Color(0xFFE4E7EC) // Göz yormayan kırık beyaz
    val TextSecondary   = Color(0xFF8B93A1) // Sakin ikincil gri
    val Accent          = Color(0xFF6BA3F7) // Tek dingin vurgu
    val AccentSoft      = Color(0xFF1A2536) // Yumuşak vurgu zemini
    val StatusOnline    = Color(0xFF34C77B)
    val StatusDegraded  = Color(0xFFE5A43B)
    val StatusOffline   = Color(0xFFE05A5A)
}

val PortalDarkColorScheme = darkColorScheme(
    primary = PortalPalette.Accent,
    onPrimary = Color(0xFF0A111C),
    primaryContainer = PortalPalette.AccentSoft,
    onPrimaryContainer = PortalPalette.TextPrimary,
    secondary = PortalPalette.TextSecondary,
    onSecondary = PortalPalette.Background,
    secondaryContainer = PortalPalette.SurfaceElevated,
    onSecondaryContainer = PortalPalette.TextPrimary,
    background = PortalPalette.Background,
    onBackground = PortalPalette.TextPrimary,
    surface = PortalPalette.SurfaceCard,
    onSurface = PortalPalette.TextPrimary,
    surfaceVariant = PortalPalette.SurfaceElevated,
    onSurfaceVariant = PortalPalette.TextSecondary,
    outline = PortalPalette.Hairline,
    outlineVariant = PortalPalette.Hairline,
    error = PortalPalette.StatusOffline,
    onError = Color.White
)

// ------------------------------------------------------------------
// İNCE, GÖZ YORMAYAN SANS-SERIF TİPOGRAFİ (SİSTEM ÖLÇEĞİNE UYUMLU)
// ------------------------------------------------------------------

object PortalTypography {
    val heroBrand = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Light,
        fontSize = 36.sp,
        letterSpacing = 6.sp
    )
    val brandTitle = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Normal,
        fontSize = 17.sp,
        letterSpacing = 3.sp
    )
    val pageTitle = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Light,
        fontSize = 23.sp,
        letterSpacing = (-0.2).sp
    )
    val sectionOverline = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Medium,
        fontSize = 10.5.sp,
        letterSpacing = 1.1.sp
    )
    val nodeTitle = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Normal,
        fontSize = 15.5.sp
    )
    val bodyThin = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Light,
        fontSize = 13.5.sp,
        lineHeight = 20.sp
    )
    val monoMetric = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Normal,
        fontSize = 12.sp,
        fontFeatureSettings = "tnum"
    )
    val monoCaption = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Light,
        fontSize = 11.sp,
        fontFeatureSettings = "tnum"
    )
    val terminalLine = TextStyle(
        fontFamily = FontFamily.Monospace,
        fontWeight = FontWeight.Normal,
        fontSize = 12.5.sp,
        lineHeight = 19.sp
    )
}

// ------------------------------------------------------------------
// MAT YÜZEY BİLEŞENLERİ (GÖLGESİZ, 0.5 DP SAÇ TELİ AYIRICILI)
// ------------------------------------------------------------------

@Composable
fun MatteCard(
    modifier: Modifier = Modifier,
    cornerRadius: Dp = 14.dp,
    containerColor: Color = PortalPalette.SurfaceCard,
    contentColor: Color = PortalPalette.TextPrimary,
    onClick: (() -> Unit)? = null,
    contentPadding: PaddingValues = PaddingValues(16.dp),
    content: @Composable ColumnScope.() -> Unit
) {
    val shape = remember(cornerRadius) { RoundedCornerShape(cornerRadius) }
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (isPressed && onClick != null) 0.985f else 1f,
        animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
        label = "MatteCardScale"
    )

    val clickMod = if (onClick != null) {
        Modifier.clickable(
            interactionSource = interactionSource,
            indication = LocalIndication.current,
            onClick = onClick
        )
    } else Modifier

    Box(
        modifier = modifier
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .clip(shape)
            .background(containerColor)
            .border(0.5.dp, PortalPalette.Hairline, shape)
            .then(clickMod)
    ) {
        CompositionLocalProvider(LocalContentColor provides contentColor) {
            Column(modifier = Modifier.padding(contentPadding), content = content)
        }
    }
}

@Composable
fun MatteButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    containerColor: Color = PortalPalette.Accent,
    contentColor: Color = Color(0xFF0A111C),
    cornerRadius: Dp = 12.dp,
    contentPadding: PaddingValues = PaddingValues(horizontal = 16.dp, vertical = 11.dp),
    content: @Composable RowScope.() -> Unit
) {
    val shape = remember(cornerRadius) { RoundedCornerShape(cornerRadius) }
    val haptic = LocalHapticFeedback.current
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()

    val scale by animateFloatAsState(
        targetValue = if (isPressed && enabled) 0.97f else 1f,
        animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
        label = "MatteBtnScale"
    )
    val bg by animateColorAsState(
        targetValue = if (enabled) containerColor else containerColor.copy(alpha = 0.3f),
        animationSpec = tween(160),
        label = "MatteBtnBg"
    )
    val fg by animateColorAsState(
        targetValue = if (enabled) contentColor else contentColor.copy(alpha = 0.45f),
        animationSpec = tween(160),
        label = "MatteBtnFg"
    )

    Box(
        modifier = modifier
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .clip(shape)
            .background(bg)
            .border(0.5.dp, PortalPalette.Hairline, shape)
            .clickable(
                enabled = enabled,
                interactionSource = interactionSource,
                indication = LocalIndication.current,
                onClick = {
                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    onClick()
                }
            )
            .padding(contentPadding),
        contentAlignment = Alignment.Center
    ) {
        CompositionLocalProvider(LocalContentColor provides fg) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center,
                content = content
            )
        }
    }
}

@Composable
fun HardwareTreeBranch(
    title: String,
    badge: String,
    expanded: Boolean,
    onToggle: () -> Unit,
    content: @Composable ColumnScope.() -> Unit
) {
    val haptic = LocalHapticFeedback.current
    val shape = remember { RoundedCornerShape(10.dp) }
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(PortalPalette.SurfaceElevated)
            .border(0.5.dp, PortalPalette.Hairline, shape)
            .animateContentSize(animationSpec = spring(stiffness = Spring.StiffnessMediumLow))
            .padding(horizontal = 12.dp, vertical = 9.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable {
                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    onToggle()
                },
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = (if (expanded) "▾  " else "▸  ") + title,
                style = PortalTypography.sectionOverline,
                color = PortalPalette.TextPrimary
            )
            Text(
                text = badge,
                style = PortalTypography.monoCaption,
                color = PortalPalette.TextSecondary
            )
        }
        if (expanded) {
            Spacer(modifier = Modifier.height(10.dp))
            content()
        }
    }
}
