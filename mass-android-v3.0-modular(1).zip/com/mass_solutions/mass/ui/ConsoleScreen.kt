package com.mass_solutions.mass.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.mass_solutions.mass.state.LogEntryType
import com.mass_solutions.mass.state.MassIntent
import com.mass_solutions.mass.state.MassPortalState
import com.mass_solutions.mass.theme.MatteButton
import com.mass_solutions.mass.theme.MatteCard
import com.mass_solutions.mass.theme.PortalPalette
import com.mass_solutions.mass.theme.PortalTypography

@Composable
fun ConsoleScreen(
    state: MassPortalState,
    onIntent: (MassIntent) -> Unit
) {
    val tr = isTurkish()
    val haptic = LocalHapticFeedback.current
    val activeTerm = state.activeTerminal
    val selectedNodeId = activeTerm.targetNodeId.ifBlank {
        state.selectedNodeId.ifBlank { state.devices.firstOrNull()?.id ?: "" }
    }
    val selectedNode = state.devices.find { it.id == selectedNodeId }

    var commandText by remember(activeTerm.id) { mutableStateOf("") }
    var sudoPassword by remember(activeTerm.pendingSudoCommand) { mutableStateOf("") }
    var nodeDropdownExpanded by remember { mutableStateOf(false) }
    var showQuickCommands by remember { mutableStateOf(false) }

    val listState = rememberLazyListState()
    LaunchedEffect(activeTerm.entries.size, activeTerm.id) {
        if (activeTerm.entries.isNotEmpty()) {
            listState.animateScrollToItem(activeTerm.entries.lastIndex)
        }
    }

    val quickCommands = remember {
        listOf("uptime", "free -h", "df -h", "ip -br a", "nvidia-smi", "systemctl status mass-master --no-pager")
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .imePadding()
            .padding(horizontal = 14.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Çoklu Terminal Sekme Çubuğu
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            state.terminals.forEach { term ->
                val isSelected = term.id == state.activeTerminalId
                val shape = RoundedCornerShape(10.dp)
                Row(
                    modifier = Modifier
                        .clip(shape)
                        .background(if (isSelected) PortalPalette.AccentSoft else PortalPalette.SurfaceCard)
                        .border(
                            0.5.dp,
                            if (isSelected) PortalPalette.Accent.copy(alpha = 0.6f) else PortalPalette.Hairline,
                            shape
                        )
                        .clickable {
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            onIntent(MassIntent.SelectTerminal(term.id))
                        }
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = term.title,
                        style = PortalTypography.monoCaption,
                        color = if (isSelected) PortalPalette.Accent else PortalPalette.TextSecondary
                    )
                    if (state.terminals.size > 1) {
                        Text(
                            text = "×",
                            style = PortalTypography.monoMetric,
                            color = PortalPalette.TextSecondary,
                            modifier = Modifier.clickable { onIntent(MassIntent.CloseTerminal(term.id)) }
                        )
                    }
                }
            }
            val addShape = RoundedCornerShape(10.dp)
            Box(
                modifier = Modifier
                    .clip(addShape)
                    .background(PortalPalette.SurfaceCard)
                    .border(0.5.dp, PortalPalette.Hairline, addShape)
                    .clickable {
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        onIntent(MassIntent.CreateTerminal)
                    }
                    .padding(horizontal = 10.dp, vertical = 6.dp)
            ) {
                Text(
                    text = if (tr) "+ Yeni" else "+ New",
                    style = PortalTypography.monoCaption,
                    color = PortalPalette.TextPrimary
                )
            }
        }

        // Hedef Sunucu + CWD + Kısayollar + Temizle
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box {
                val shape = RoundedCornerShape(10.dp)
                Row(
                    modifier = Modifier
                        .clip(shape)
                        .background(PortalPalette.SurfaceCard)
                        .border(0.5.dp, PortalPalette.Hairline, shape)
                        .clickable { nodeDropdownExpanded = true }
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "${selectedNode?.hostname ?: (if (tr) "Sunucu seç" else "Select node")} · ${activeTerm.cwd}",
                        style = PortalTypography.monoCaption,
                        color = PortalPalette.TextPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(text = "▾", style = PortalTypography.monoCaption, color = PortalPalette.TextSecondary)
                }

                DropdownMenu(
                    expanded = nodeDropdownExpanded,
                    onDismissRequest = { nodeDropdownExpanded = false },
                    modifier = Modifier.background(PortalPalette.SurfaceElevated)
                ) {
                    state.devices.forEach { dev ->
                        DropdownMenuItem(
                            text = {
                                Text(
                                    text = "${dev.hostname} (${dev.ipAddress})",
                                    style = PortalTypography.monoMetric,
                                    color = PortalPalette.TextPrimary
                                )
                            },
                            onClick = {
                                nodeDropdownExpanded = false
                                onIntent(MassIntent.SelectNodeForConsole(dev.id))
                            }
                        )
                    }
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = if (showQuickCommands) (if (tr) "Gizle" else "Hide") else (if (tr) "Komutlar" else "Quick"),
                    style = PortalTypography.monoCaption,
                    color = PortalPalette.Accent,
                    modifier = Modifier
                        .clickable { showQuickCommands = !showQuickCommands }
                        .padding(horizontal = 6.dp, vertical = 4.dp)
                )
                Text(
                    text = if (tr) "Temizle" else "Clear",
                    style = PortalTypography.monoCaption,
                    color = PortalPalette.TextSecondary,
                    modifier = Modifier
                        .clickable { onIntent(MassIntent.ClearConsole) }
                        .padding(horizontal = 6.dp, vertical = 4.dp)
                )
            }
        }

        if (showQuickCommands) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                quickCommands.forEach { cmd ->
                    val shape = RoundedCornerShape(8.dp)
                    Box(
                        modifier = Modifier
                            .clip(shape)
                            .background(PortalPalette.SurfaceElevated)
                            .border(0.5.dp, PortalPalette.Hairline, shape)
                            .clickable {
                                if (selectedNodeId.isNotBlank()) {
                                    onIntent(MassIntent.ExecuteCommand(cmd, selectedNodeId))
                                }
                            }
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text(text = cmd, style = PortalTypography.monoCaption, color = PortalPalette.TextPrimary)
                    }
                }
            }
        }

        // Terminal Çıktı Alanı (Mat, sakin, seçilebilir)
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(PortalPalette.SurfaceCard)
                .border(0.5.dp, PortalPalette.Hairline, RoundedCornerShape(12.dp))
                .padding(12.dp)
        ) {
            if (activeTerm.entries.isEmpty()) {
                Text(
                    text = if (tr) "Kalıcı bash oturumu hazır. Komut girin..." else "Persistent bash session ready. Enter a command...",
                    style = PortalTypography.bodyThin,
                    color = PortalPalette.TextSecondary,
                    modifier = Modifier.align(Alignment.TopStart)
                )
            } else {
                SelectionContainer {
                    LazyColumn(
                        state = listState,
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(activeTerm.entries, key = { it.id }) { entry ->
                            if (entry.type == LogEntryType.Command) {
                                Text(
                                    text = "$ ${entry.text}",
                                    style = PortalTypography.terminalLine,
                                    color = PortalPalette.Accent
                                )
                            } else {
                                Text(
                                    text = entry.text,
                                    style = PortalTypography.terminalLine,
                                    color = PortalPalette.TextPrimary
                                )
                            }
                        }
                    }
                }
            }
        }

        // Etkileşimli Sudo Parola Kutusu (yalnızca gerektiğinde görünür)
        if (activeTerm.pendingSudoCommand != null) {
            MatteCard(
                containerColor = PortalPalette.SurfaceElevated,
                contentPadding = PaddingValues(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = activeTerm.sudoPromptLabel,
                    style = PortalTypography.monoMetric,
                    color = PortalPalette.StatusDegraded
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = sudoPassword,
                        onValueChange = { sudoPassword = it },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        placeholder = {
                            Text(
                                text = if (tr) "Sudo parolası (kaydedilmez)" else "Sudo password (not stored)",
                                style = PortalTypography.monoCaption,
                                color = PortalPalette.TextSecondary
                            )
                        },
                        textStyle = PortalTypography.bodyThin.copy(color = PortalPalette.TextPrimary),
                        shape = RoundedCornerShape(10.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = PortalPalette.StatusDegraded,
                            unfocusedBorderColor = PortalPalette.Hairline,
                            focusedContainerColor = PortalPalette.Background,
                            unfocusedContainerColor = PortalPalette.Background
                        ),
                        modifier = Modifier.weight(1f)
                    )
                    MatteButton(
                        onClick = {
                            val cmd = activeTerm.pendingSudoCommand
                            val pw = sudoPassword
                            sudoPassword = ""
                            if (cmd != null && selectedNodeId.isNotBlank()) {
                                onIntent(MassIntent.ExecuteCommand(cmd, selectedNodeId, sudoPassword = pw))
                            }
                        },
                        containerColor = PortalPalette.Accent,
                        contentColor = PortalPalette.Background
                    ) {
                        Text(text = if (tr) "Onayla" else "Send", style = PortalTypography.monoMetric)
                    }
                    MatteButton(
                        onClick = {
                            sudoPassword = ""
                            onIntent(MassIntent.CancelSudoPrompt)
                        },
                        containerColor = PortalPalette.SurfaceCard,
                        contentColor = PortalPalette.TextSecondary
                    ) {
                        Text(text = "×", style = PortalTypography.monoMetric)
                    }
                }
            }
        }

        // Alt Komut Satırı
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = commandText,
                onValueChange = { commandText = it },
                placeholder = {
                    Text(
                        text = if (tr) "Komut yazın..." else "Type command...",
                        style = PortalTypography.bodyThin,
                        color = PortalPalette.TextSecondary
                    )
                },
                singleLine = true,
                textStyle = PortalTypography.terminalLine.copy(color = PortalPalette.TextPrimary),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(
                    onSend = {
                        val trimmed = commandText.trim()
                        if (trimmed.isNotEmpty() && selectedNodeId.isNotBlank()) {
                            commandText = ""
                            onIntent(MassIntent.ExecuteCommand(trimmed, selectedNodeId))
                        }
                    }
                ),
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = PortalPalette.Accent.copy(alpha = 0.7f),
                    unfocusedBorderColor = PortalPalette.Hairline,
                    focusedContainerColor = PortalPalette.SurfaceCard,
                    unfocusedContainerColor = PortalPalette.SurfaceCard,
                    cursorColor = PortalPalette.Accent
                ),
                modifier = Modifier.weight(1f)
            )

            MatteButton(
                onClick = {
                    val trimmed = commandText.trim()
                    if (trimmed.isNotEmpty() && selectedNodeId.isNotBlank()) {
                        commandText = ""
                        onIntent(MassIntent.ExecuteCommand(trimmed, selectedNodeId))
                    }
                },
                enabled = commandText.isNotBlank() && selectedNodeId.isNotBlank() && !state.safeModeEnabled,
                containerColor = PortalPalette.Accent,
                contentColor = PortalPalette.Background,
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp)
            ) {
                Text(text = if (tr) "Çalıştır" else "Run", style = PortalTypography.monoMetric)
            }
        }
    }
}
