package com.mass_solutions.mass.ui

import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mass_solutions.mass.animations.MiniSparkline
import com.mass_solutions.mass.animations.ThinMetricBar
import com.mass_solutions.mass.state.DeviceInfo
import com.mass_solutions.mass.state.MassIntent
import com.mass_solutions.mass.state.MassPortalState
import com.mass_solutions.mass.state.NodeFilter
import com.mass_solutions.mass.state.NodeStatus
import com.mass_solutions.mass.state.Screen
import com.mass_solutions.mass.theme.HardwareTreeBranch
import com.mass_solutions.mass.theme.MatteButton
import com.mass_solutions.mass.theme.MatteCard
import com.mass_solutions.mass.theme.PortalPalette
import com.mass_solutions.mass.theme.PortalTypography
import java.util.Locale

fun isTurkish(): Boolean = Locale.getDefault().language.equals("tr", ignoreCase = true)

@Composable
fun DashboardScreen(
    state: MassPortalState,
    onIntent: (MassIntent) -> Unit,
    onOpenDesktop: (String) -> Unit,
    onOpenGuide: () -> Unit
) {
    val tr = isTurkish()
    val haptic = LocalHapticFeedback.current
    val onlineCount = state.devices.count { it.status == NodeStatus.Online }
    val warnCount = state.devices.count { it.status == NodeStatus.Degraded }
    val avgCpu = if (state.devices.isNotEmpty()) state.devices.map { it.cpuPercent }.average().toInt() else 0

    val filteredDevices = remember(state.devices, state.searchQuery, state.nodeFilter) {
        state.devices.filter { dev ->
            val q = state.searchQuery.trim().lowercase(Locale.ROOT)
            val matchQuery = q.isEmpty() ||
                dev.hostname.lowercase(Locale.ROOT).contains(q) ||
                dev.ipAddress.lowercase(Locale.ROOT).contains(q) ||
                dev.role.lowercase(Locale.ROOT).contains(q)
            val matchFilter = when (state.nodeFilter) {
                NodeFilter.All -> true
                NodeFilter.Online -> dev.status != NodeStatus.Offline
                NodeFilter.Offline -> dev.status == NodeStatus.Offline
            }
            matchQuery && matchFilter
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Üst durum çubuğu: Bağlantı rotası + Hızlı Masaüstü + Yenile
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = if (tr) "Sistem Özeti" else "System Overview",
                        style = PortalTypography.pageTitle,
                        color = PortalPalette.TextPrimary
                    )
                    Spacer(modifier = Modifier.height(3.dp))
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(7.dp)
                                .clip(CircleShape)
                                .background(
                                    if (state.isConnected) PortalPalette.StatusOnline else PortalPalette.StatusOffline
                                )
                        )
                        val routeText = when {
                            !state.isConnected -> if (tr) "Bağlantı yok" else "Disconnected"
                            state.usingRemoteRoute -> if (tr) "4G/5G Tünel · Uyarlamalı" else "4G/5G Tunnel · Adaptive"
                            else -> if (tr) "Yerel LAN · 25 Mbps" else "Local LAN · 25 Mbps"
                        }
                        Text(
                            text = routeText,
                            style = PortalTypography.monoCaption,
                            color = PortalPalette.TextSecondary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    val primaryNode = state.devices.firstOrNull()
                    if (primaryNode != null && state.isConnected) {
                        MatteButton(
                            onClick = { onOpenDesktop(primaryNode.id) },
                            containerColor = PortalPalette.AccentSoft,
                            contentColor = PortalPalette.Accent,
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp)
                        ) {
                            Text(
                                text = if (tr) "Masaüstü" else "Desktop",
                                style = PortalTypography.monoMetric
                            )
                        }
                    }
                    MatteButton(
                        onClick = { onIntent(MassIntent.FetchDevices) },
                        containerColor = PortalPalette.SurfaceCard,
                        contentColor = PortalPalette.TextPrimary,
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp)
                    ) {
                        Text(
                            text = if (tr) "Yenile" else "Sync",
                            style = PortalTypography.monoMetric
                        )
                    }
                }
            }
        }

        // Mat KPI Satırı
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                MatteKpiTile(
                    label = if (tr) "AKTİF" else "ONLINE",
                    value = "$onlineCount/${state.devices.size}",
                    accentColor = PortalPalette.StatusOnline,
                    modifier = Modifier.weight(1f)
                )
                MatteKpiTile(
                    label = if (tr) "ORT. CPU" else "AVG CPU",
                    value = "%$avgCpu",
                    accentColor = if (avgCpu >= 85) PortalPalette.StatusOffline else PortalPalette.Accent,
                    modifier = Modifier.weight(1f)
                )
                MatteKpiTile(
                    label = if (tr) "UYARI" else "ALERTS",
                    value = "$warnCount",
                    accentColor = if (warnCount > 0) PortalPalette.StatusDegraded else PortalPalette.TextSecondary,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Arama + Filtre Çipleri
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = state.searchQuery,
                    onValueChange = { onIntent(MassIntent.UpdateSearchQuery(it)) },
                    placeholder = {
                        Text(
                            text = if (tr) "Cihaz, IP veya rol ara..." else "Search host, IP or role...",
                            style = PortalTypography.bodyThin,
                            color = PortalPalette.TextSecondary
                        )
                    },
                    singleLine = true,
                    textStyle = PortalTypography.bodyThin.copy(color = PortalPalette.TextPrimary),
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = PortalPalette.Accent.copy(alpha = 0.7f),
                        unfocusedBorderColor = PortalPalette.Hairline,
                        focusedContainerColor = PortalPalette.SurfaceCard,
                        unfocusedContainerColor = PortalPalette.SurfaceCard,
                        cursorColor = PortalPalette.Accent
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    listOf(
                        NodeFilter.All to (if (tr) "Tümü" else "All"),
                        NodeFilter.Online to (if (tr) "Çevrimiçi" else "Online"),
                        NodeFilter.Offline to (if (tr) "Çevrimdışı" else "Offline")
                    ).forEach { (filter, label) ->
                        val selected = state.nodeFilter == filter
                        val shape = RoundedCornerShape(10.dp)
                        Box(
                            modifier = Modifier
                                .clip(shape)
                                .background(if (selected) PortalPalette.AccentSoft else PortalPalette.SurfaceCard)
                                .border(
                                    0.5.dp,
                                    if (selected) PortalPalette.Accent.copy(alpha = 0.6f) else PortalPalette.Hairline,
                                    shape
                                )
                                .clickable {
                                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                    onIntent(MassIntent.UpdateNodeFilter(filter))
                                }
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = label,
                                style = PortalTypography.monoCaption,
                                color = if (selected) PortalPalette.Accent else PortalPalette.TextSecondary
                            )
                        }
                    }

                    Spacer(modifier = Modifier.weight(1f))

                    Text(
                        text = if (tr) "Kılavuz" else "Guide",
                        style = PortalTypography.monoCaption,
                        color = PortalPalette.TextSecondary,
                        modifier = Modifier
                            .clickable { onOpenGuide() }
                            .padding(horizontal = 6.dp, vertical = 4.dp)
                    )
                }
            }
        }

        // Cihaz Listesi veya Boş Durum
        if (filteredDevices.isEmpty()) {
            item {
                MatteCard(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = if (!state.isDevicePaired) {
                            if (tr) "Henüz eşleştirilmiş sunucu yok" else "No paired server yet"
                        } else if (!state.isConnected) {
                            if (tr) "Sunucuya ulaşılamıyor" else "Server unreachable"
                        } else {
                            if (tr) "Eşleşen düğüm bulunamadı" else "No matching nodes found"
                        },
                        style = PortalTypography.nodeTitle,
                        color = PortalPalette.TextPrimary
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = if (!state.isDevicePaired) {
                            if (tr) "Ayarlar sekmesinden 6 haneli kodla cihazınızı eşleştirin."
                            else "Pair this device using the 6-digit code in Settings."
                        } else {
                            state.effectiveEndpoint
                        },
                        style = PortalTypography.bodyThin,
                        color = PortalPalette.TextSecondary
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        MatteButton(
                            onClick = { onIntent(MassIntent.Navigate(Screen.Settings)) },
                            containerColor = PortalPalette.AccentSoft,
                            contentColor = PortalPalette.Accent
                        ) {
                            Text(
                                text = if (tr) "Ayarları Aç" else "Open Settings",
                                style = PortalTypography.monoMetric
                            )
                        }
                        if (state.isDevicePaired) {
                            MatteButton(
                                onClick = { onIntent(MassIntent.CheckServerHealth) },
                                containerColor = PortalPalette.SurfaceElevated,
                                contentColor = PortalPalette.TextPrimary
                            ) {
                                Text(
                                    text = if (tr) "Tekrar Dene" else "Retry",
                                    style = PortalTypography.monoMetric
                                )
                            }
                        }
                    }
                }
            }
        } else {
            items(filteredDevices, key = { it.id }) { dev ->
                DeviceCard(
                    device = dev,
                    cpuHistory = state.cpuHistory[dev.id].orEmpty(),
                    gpuHistory = state.gpuHistory[dev.id].orEmpty(),
                    onOpenConsole = {
                        onIntent(MassIntent.SelectNodeForConsole(dev.id))
                        onIntent(MassIntent.Navigate(Screen.Console))
                    },
                    onOpenDesktop = { onOpenDesktop(dev.id) }
                )
            }
        }
    }
}

@Composable
private fun MatteKpiTile(
    label: String,
    value: String,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    MatteCard(
        modifier = modifier,
        cornerRadius = 12.dp,
        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 11.dp)
    ) {
        Text(
            text = label,
            style = PortalTypography.sectionOverline,
            color = PortalPalette.TextSecondary,
            maxLines = 1
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = value,
            style = PortalTypography.pageTitle.copy(fontSize = 19.sp, fontWeight = FontWeight.Normal),
            color = accentColor,
            maxLines = 1
        )
    }
}

@Composable
private fun DeviceCard(
    device: DeviceInfo,
    cpuHistory: List<Float>,
    gpuHistory: List<Float>,
    onOpenConsole: () -> Unit,
    onOpenDesktop: () -> Unit
) {
    val tr = isTurkish()
    var expandSystem by remember(device.id) { mutableStateOf(false) }
    var expandGpu by remember(device.id) { mutableStateOf(false) }
    var expandDisk by remember(device.id) { mutableStateOf(false) }
    var expandNet by remember(device.id) { mutableStateOf(false) }

    val statusColor = when (device.status) {
        NodeStatus.Online -> PortalPalette.StatusOnline
        NodeStatus.Degraded -> PortalPalette.StatusDegraded
        NodeStatus.Offline -> PortalPalette.StatusOffline
    }

    MatteCard(
        modifier = Modifier
            .fillMaxWidth()
            .animateContentSize(animationSpec = spring(stiffness = Spring.StiffnessMediumLow))
    ) {
        // Başlık Satırı
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(statusColor)
                )
                Column {
                    Text(
                        text = device.hostname,
                        style = PortalTypography.nodeTitle,
                        color = PortalPalette.TextPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "${device.role} · ${device.ipAddress} · ${device.uptime}",
                        style = PortalTypography.monoCaption,
                        color = PortalPalette.TextSecondary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            if (device.tempCelsius > 0) {
                Text(
                    text = "${device.tempCelsius}°C",
                    style = PortalTypography.monoMetric,
                    color = if (device.tempCelsius >= 80) PortalPalette.StatusOffline else PortalPalette.TextSecondary
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // CPU + Canlı Sparkline
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.Bottom,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            ThinMetricBar(
                label = "CPU",
                valueText = "%${device.cpuPercent}",
                progress = device.cpuPercent / 100f,
                isWarning = device.cpuPercent >= 85,
                modifier = Modifier.weight(1f)
            )
            if (cpuHistory.size >= 2) {
                MiniSparkline(
                    values = cpuHistory,
                    lineColor = if (device.cpuPercent >= 85) PortalPalette.StatusOffline else PortalPalette.Accent,
                    modifier = Modifier
                        .width(68.dp)
                        .height(22.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // RAM Çubuğu
        val ramRatio = if (device.ramTotalGb > 0.0) (device.ramUsedGb / device.ramTotalGb).toFloat() else 0f
        ThinMetricBar(
            label = "RAM",
            valueText = String.format(Locale.US, "%.1f / %.1f GB", device.ramUsedGb, device.ramTotalGb),
            progress = ramRatio,
            isWarning = ramRatio >= 0.9f
        )

        // GPU Özeti + Sparkline (varsa)
        if (device.gpus.isNotEmpty() || device.gpuVramTotalGb > 0.0 || device.gpuPercent > 0) {
            Spacer(modifier = Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.Bottom,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                val gpuLabel = device.gpuName.take(22)
                val gpuVal = if (device.gpuTempCelsius > 0) "%${device.gpuPercent} · ${device.gpuTempCelsius}°C"
                else "%${device.gpuPercent}"
                ThinMetricBar(
                    label = gpuLabel,
                    valueText = gpuVal,
                    progress = device.gpuPercent / 100f,
                    isWarning = device.gpuTempCelsius >= 85,
                    modifier = Modifier.weight(1f)
                )
                if (gpuHistory.size >= 2) {
                    MiniSparkline(
                        values = gpuHistory,
                        lineColor = PortalPalette.StatusOnline,
                        modifier = Modifier
                            .width(68.dp)
                            .height(22.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Açılır Donanım Ağacı Dalları
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            HardwareTreeBranch(
                title = if (tr) "SİSTEM & BELLEK" else "SYSTEM & MEMORY",
                badge = "${device.lastSync}",
                expanded = expandSystem,
                onToggle = { expandSystem = !expandSystem }
            ) {
                InfoRow(if (tr) "Düğüm Kimliği" else "Node ID", device.id)
                InfoRow(if (tr) "IP Adresi" else "IP Address", device.ipAddress)
                InfoRow(if (tr) "Çalışma Süresi" else "Uptime", device.uptime)
                InfoRow(if (tr) "Ana Disk" else "Root Disk", device.diskSummary)
            }

            if (device.gpus.isNotEmpty()) {
                HardwareTreeBranch(
                    title = if (tr) "EKRAN KARTLARI" else "GPUS",
                    badge = "${device.gpus.size}",
                    expanded = expandGpu,
                    onToggle = { expandGpu = !expandGpu }
                ) {
                    device.gpus.forEachIndexed { i, g ->
                        if (i > 0) Spacer(modifier = Modifier.height(8.dp))
                        val vramText = if (g.vramTotalGb > 0.0) {
                            String.format(Locale.US, "%.1f/%.1f GB", g.vramUsedGb, g.vramTotalGb)
                        } else "-"
                        ThinMetricBar(
                            label = "${g.name} (${g.kind})",
                            valueText = "%${g.utilPercent} · ${g.tempCelsius}°C · $vramText",
                            progress = g.utilPercent / 100f,
                            isWarning = g.tempCelsius >= 85
                        )
                    }
                }
            }

            if (device.disks.isNotEmpty()) {
                HardwareTreeBranch(
                    title = if (tr) "DEPOLAMA / SSD" else "STORAGE / DISKS",
                    badge = "${device.disks.size}",
                    expanded = expandDisk,
                    onToggle = { expandDisk = !expandDisk }
                ) {
                    device.disks.forEachIndexed { i, d ->
                        if (i > 0) Spacer(modifier = Modifier.height(8.dp))
                        ThinMetricBar(
                            label = "${d.mount} (${d.device})",
                            valueText = String.format(Locale.US, "%.1f/%.1f GB (%%%d)", d.usedGb, d.totalGb, d.percent),
                            progress = d.percent / 100f,
                            isWarning = d.percent >= 90
                        )
                    }
                }
            }

            if (device.ports.isNotEmpty()) {
                val activePorts = device.ports.count { it.active }
                HardwareTreeBranch(
                    title = if (tr) "AĞ & PORTLAR" else "NETWORK & PORTS",
                    badge = "$activePorts/${device.ports.size}",
                    expanded = expandNet,
                    onToggle = { expandNet = !expandNet }
                ) {
                    device.ports.forEach { pt ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 3.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(6.dp)
                                        .clip(CircleShape)
                                        .background(if (pt.active) PortalPalette.StatusOnline else PortalPalette.StatusOffline)
                                )
                                Text(
                                    text = pt.name,
                                    style = PortalTypography.monoMetric,
                                    color = PortalPalette.TextPrimary
                                )
                            }
                            Text(
                                text = pt.detail,
                                style = PortalTypography.monoCaption,
                                color = PortalPalette.TextSecondary
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Alt Eylem Butonları
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            MatteButton(
                onClick = onOpenConsole,
                containerColor = PortalPalette.SurfaceElevated,
                contentColor = PortalPalette.TextPrimary,
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = if (tr) "Terminal" else "Console",
                    style = PortalTypography.monoMetric
                )
            }
            MatteButton(
                onClick = onOpenDesktop,
                containerColor = PortalPalette.AccentSoft,
                contentColor = PortalPalette.Accent,
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = if (tr) "Masaüstü" else "Desktop",
                    style = PortalTypography.monoMetric
                )
            }
        }
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, style = PortalTypography.monoCaption, color = PortalPalette.TextSecondary)
        Text(text = value, style = PortalTypography.monoMetric, color = PortalPalette.TextPrimary)
    }
}
