package com.mass_solutions.mass.ui

import android.app.Activity
import android.content.pm.ActivityInfo
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import android.view.Surface
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.WindowManager
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.DialogWindowProvider
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.mass_solutions.mass.network.DynamicBandWidth
import com.mass_solutions.mass.network.MassApiClient
import com.mass_solutions.mass.state.MassPortalState
import com.mass_solutions.mass.theme.MatteButton
import com.mass_solutions.mass.theme.PortalPalette
import com.mass_solutions.mass.theme.PortalTypography
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import org.json.JSONObject
import java.net.URLEncoder
import kotlin.math.abs

@Composable
fun DesktopRemoteDialog(
    nodeId: String,
    state: MassPortalState,
    onSendInput: (JSONObject) -> Unit,
    onDismiss: () -> Unit
) {
    val tr = isTurkish()
    val context = LocalContext.current
    val hostView = LocalView.current

    // Yön değiştirme sırasında Activity yeniden oluşursa yönü geri alma (sonsuz döngüyü önler)
    DisposableEffect(Unit) {
        val activity = context as? Activity
        activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        activity?.window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val controller = activity?.window?.let { WindowCompat.getInsetsController(it, hostView) }
        controller?.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        controller?.hide(WindowInsetsCompat.Type.systemBars())
        onDispose {
            if (activity != null && !activity.isChangingConfigurations) {
                activity.window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                controller?.show(WindowInsetsCompat.Type.systemBars())
                activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            }
        }
    }

    var targetFps by remember { mutableStateOf(60) }
    var useH264 by remember { mutableStateOf(true) }
    var activeSurface by remember { mutableStateOf<Surface?>(null) }
    var fallbackBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var streamStatus by remember { mutableStateOf(if (tr) "Akış başlatılıyor..." else "Starting stream...") }
    var liveFps by remember { mutableStateOf(0) }
    var bwLabel by remember { mutableStateOf(DynamicBandWidth.currentProfile(state.usingRemoteRoute, 60).label) }
    var bwEpoch by remember { mutableStateOf(0) }

    var showKeyboardDock by remember { mutableStateOf(false) }
    var showScrollStrip by remember { mutableStateOf(false) }
    var keyboardText by remember { mutableStateOf("") }
    var viewportSize by remember { mutableStateOf(IntSize(1, 1)) }

    val frameCounter = remember { java.util.concurrent.atomic.AtomicInteger(0) }

    // Dokunma/fare gecikmesini sıfıra indirmek için 24'lü sıcak nonce havuzu
    LaunchedEffect(state.effectiveEndpoint, state.caCertPem) {
        while (isActive) {
            MassApiClient.prefetchNonces(state.effectiveEndpoint, state.caCertPem, targetCount = 24)
            delay(250L)
        }
    }

    // FPS sayacı + 4G/5G dinamik bant genişliği uyarlaması
    LaunchedEffect(state.usingRemoteRoute, targetFps) {
        var lowTicks = 0
        while (isActive) {
            delay(1000L)
            val fpsNow = frameCounter.getAndSet(0)
            liveFps = fpsNow
            if (state.usingRemoteRoute) {
                if (fpsNow < (targetFps * 0.65).toInt()) lowTicks++ else lowTicks = 0
                val changed = DynamicBandWidth.adaptMobile(
                    measuredFps = fpsNow,
                    targetFps = targetFps,
                    stalled = lowTicks >= 3
                )
                bwLabel = DynamicBandWidth.currentProfile(true, targetFps).label
                if (changed) bwEpoch++
            } else {
                bwLabel = DynamicBandWidth.currentProfile(false, targetFps).label
            }
        }
    }

    // H.264 -> MJPEG -> Tek Kare (/v1/desktop/frame) dayanıklı akış döngüsü
    LaunchedEffect(nodeId, state.effectiveEndpoint, state.caCertPem, targetFps, useH264, activeSurface, state.usingRemoteRoute, bwEpoch) {
        var useFallbackPolling = false
        while (isActive) {
            val profile = DynamicBandWidth.currentProfile(state.usingRemoteRoute, targetFps)
            bwLabel = profile.label

            if (useH264) {
                val surf = activeSurface
                if (surf == null || !surf.isValid) {
                    delay(50L)
                    continue
                }
                streamStatus = "H.264 · ${profile.label}"
                try {
                    MassApiClient.streamDesktopH264(
                        baseUrl = state.effectiveEndpoint,
                        nodeId = nodeId,
                        fps = profile.fps,
                        bitrateKbps = profile.bitrateKbps,
                        scaleWidth = profile.scaleWidth,
                        caCertPem = state.caCertPem,
                        surface = surf,
                        onFrameRendered = { frameCounter.incrementAndGet() }
                    )
                } catch (e: Exception) {
                    val msg = e.localizedMessage ?: ""
                    val nodeOffline = msg.contains("not connected", ignoreCase = true)
                    if (msg.contains("404") && !nodeOffline) {
                        useH264 = false
                    } else {
                        if (state.usingRemoteRoute && DynamicBandWidth.adaptMobile(0, profile.fps, stalled = true)) {
                            bwEpoch++
                        }
                        streamStatus = if (nodeOffline) {
                            if (tr) "Düğüm (:8445) bağlı değil — yeniden deneniyor..." else "Node (:8445) not connected — retrying..."
                        } else {
                            if (tr) "H.264 yeniden bağlanıyor... (${msg.take(48)})" else "H.264 reconnecting... (${msg.take(48)})"
                        }
                        delay(900L)
                    }
                }
                continue
            }

            if (!useFallbackPolling) {
                streamStatus = "MJPEG · 30 FPS"
                try {
                    MassApiClient.streamDesktopMjpeg(
                        baseUrl = state.effectiveEndpoint,
                        nodeId = nodeId,
                        fps = profile.fps.coerceAtMost(30),
                        quality = if (state.usingRemoteRoute) 62 else 75,
                        scaleWidth = profile.scaleWidth,
                        caCertPem = state.caCertPem,
                        onFrame = { bmp ->
                            fallbackBitmap = bmp
                            frameCounter.incrementAndGet()
                        }
                    )
                } catch (e: Exception) {
                    val msg = e.localizedMessage ?: ""
                    val nodeOffline = msg.contains("not connected", ignoreCase = true)
                    if (msg.contains("404") && !nodeOffline) {
                        useFallbackPolling = true
                        streamStatus = if (tr) "Kare modu..." else "Frame mode..."
                    } else {
                        streamStatus = if (nodeOffline) {
                            if (tr) "Düğüm (:8445) bağlı değil — yeniden deneniyor..." else "Node (:8445) not connected — retrying..."
                        } else {
                            if (tr) "Akış yeniden bağlanıyor..." else "Stream reconnecting..."
                        }
                        delay(900L)
                    }
                }
            } else {
                runCatching {
                    val enc = URLEncoder.encode(nodeId, "UTF-8")
                    val res = MassApiClient.signedRequest(
                        baseUrl = state.effectiveEndpoint,
                        path = "/v1/desktop/frame?node_id=$enc&quality=65",
                        method = "GET",
                        caCertPem = state.caCertPem
                    )
                    if (res.statusCode in 200..299) {
                        val b64 = JSONObject(res.body).optString("frame_b64", "")
                        if (b64.isNotEmpty()) {
                            val bytes = Base64.decode(b64, Base64.DEFAULT)
                            val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                            if (bmp != null) {
                                fallbackBitmap = bmp
                                frameCounter.incrementAndGet()
                            }
                        }
                    }
                }
                delay(160L)
            }
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            decorFitsSystemWindows = false
        )
    ) {
        val dialogView = LocalView.current
        SideEffect {
            val dialogWindow = (dialogView.parent as? DialogWindowProvider)?.window
            if (dialogWindow != null) {
                dialogWindow.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                WindowCompat.setDecorFitsSystemWindows(dialogWindow, false)
                val ctrl = WindowCompat.getInsetsController(dialogWindow, dialogView)
                ctrl.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                ctrl.hide(WindowInsetsCompat.Type.systemBars())
            }
        }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black)
                .imePadding()
        ) {
            // Video Yüzeyi + Çoklu Dokunmatik Kontrol Alanı
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .onSizeChanged { viewportSize = it }
                    .pointerInput(nodeId, viewportSize) {
                        var lastTapMs = 0L
                        var lastTapX = 0f
                        var lastTapY = 0f
                        awaitEachGesture {
                            val down = awaitFirstDown(requireUnconsumed = false)
                            val downTime = System.currentTimeMillis()
                            val startPos = down.position
                            var maxPointers = 1
                            var moved = false
                            var dragging = false
                            var lastPos = startPos
                            var lastSendMs = 0L
                            var scrollAccum = 0f

                            fun normX(px: Float): Float = (px / viewportSize.width.coerceAtLeast(1)).coerceIn(0f, 1f)
                            fun normY(py: Float): Float = (py / viewportSize.height.coerceAtLeast(1)).coerceIn(0f, 1f)

                            while (true) {
                                val event = awaitPointerEvent()
                                val pressed = event.changes.filter { it.pressed }
                                if (pressed.size > maxPointers) maxPointers = pressed.size
                                if (pressed.isEmpty()) break

                                val cur = pressed.first().position
                                val dx = cur.x - lastPos.x
                                val dy = cur.y - lastPos.y
                                val totalDist = abs(cur.x - startPos.x) + abs(cur.y - startPos.y)
                                if (totalDist > 14f) moved = true

                                val nowMs = System.currentTimeMillis()
                                if (maxPointers == 2 && abs(dy) > 3f) {
                                    if (dragging) {
                                        dragging = false
                                        onSendInput(
                                            JSONObject().apply {
                                                put("target_node_id", nodeId)
                                                put("type", "drag_end")
                                                put("x_norm", normX(lastPos.x))
                                                put("y_norm", normY(lastPos.y))
                                            }
                                        )
                                    }
                                    scrollAccum += dy
                                    if (abs(scrollAccum) >= 18f && (nowMs - lastSendMs) >= 22L) {
                                        val steps = (scrollAccum / 18f).toInt().coerceIn(-5, 5)
                                        scrollAccum -= steps * 18f
                                        lastSendMs = nowMs
                                        onSendInput(
                                            JSONObject().apply {
                                                put("target_node_id", nodeId)
                                                put("type", "scroll")
                                                put("x_norm", normX(cur.x))
                                                put("y_norm", normY(cur.y))
                                                put("delta_y", -steps)
                                            }
                                        )
                                    }
                                } else if (maxPointers == 1 && moved) {
                                    if (!dragging) {
                                        dragging = true
                                        lastSendMs = nowMs
                                        onSendInput(
                                            JSONObject().apply {
                                                put("target_node_id", nodeId)
                                                put("type", "drag_start")
                                                put("x_norm", normX(startPos.x))
                                                put("y_norm", normY(startPos.y))
                                            }
                                        )
                                    } else if ((abs(dx) > 1.5f || abs(dy) > 1.5f) && (nowMs - lastSendMs) >= 16L) {
                                        lastSendMs = nowMs
                                        onSendInput(
                                            JSONObject().apply {
                                                put("target_node_id", nodeId)
                                                put("type", "drag_move")
                                                put("x_norm", normX(cur.x))
                                                put("y_norm", normY(cur.y))
                                            }
                                        )
                                    }
                                }
                                lastPos = cur
                            }

                            val elapsed = System.currentTimeMillis() - downTime
                            val nx = normX(lastPos.x)
                            val ny = normY(lastPos.y)

                            if (dragging) {
                                onSendInput(
                                    JSONObject().apply {
                                        put("target_node_id", nodeId)
                                        put("type", "drag_end")
                                        put("x_norm", nx)
                                        put("y_norm", ny)
                                    }
                                )
                            } else when {
                                maxPointers >= 3 -> {
                                    onSendInput(
                                        JSONObject().apply {
                                            put("target_node_id", nodeId)
                                            put("type", "key")
                                            put("key", "alt+Tab")
                                        }
                                    )
                                }
                                maxPointers == 2 && !moved -> {
                                    onSendInput(
                                        JSONObject().apply {
                                            put("target_node_id", nodeId)
                                            put("type", "right_click")
                                            put("x_norm", nx)
                                            put("y_norm", ny)
                                        }
                                    )
                                }
                                !moved && elapsed >= 420L -> {
                                    onSendInput(
                                        JSONObject().apply {
                                            put("target_node_id", nodeId)
                                            put("type", "right_click")
                                            put("x_norm", nx)
                                            put("y_norm", ny)
                                        }
                                    )
                                }
                                !moved -> {
                                    val now = System.currentTimeMillis()
                                    val isDouble = (now - lastTapMs) < 300L &&
                                        abs(lastPos.x - lastTapX) < 60f &&
                                        abs(lastPos.y - lastTapY) < 60f
                                    lastTapMs = now
                                    lastTapX = lastPos.x
                                    lastTapY = lastPos.y
                                    onSendInput(
                                        JSONObject().apply {
                                            put("target_node_id", nodeId)
                                            put("type", if (isDouble) "double_click" else "click")
                                            put("x_norm", nx)
                                            put("y_norm", ny)
                                        }
                                    )
                                }
                            }
                        }
                    }
            ) {
                if (useH264) {
                    AndroidView(
                        factory = { ctx ->
                            SurfaceView(ctx).apply {
                                holder.addCallback(object : SurfaceHolder.Callback {
                                    override fun surfaceCreated(holder: SurfaceHolder) {
                                        activeSurface = holder.surface
                                    }
                                    override fun surfaceChanged(holder: SurfaceHolder, f: Int, w: Int, h: Int) {
                                        activeSurface = holder.surface
                                    }
                                    override fun surfaceDestroyed(holder: SurfaceHolder) {
                                        activeSurface = null
                                    }
                                })
                            }
                        },
                        modifier = Modifier.fillMaxSize()
                    )
                    if (liveFps == 0) {
                        Text(
                            text = streamStatus,
                            style = PortalTypography.monoMetric,
                            color = PortalPalette.TextSecondary,
                            modifier = Modifier
                                .align(Alignment.Center)
                                .clip(RoundedCornerShape(10.dp))
                                .background(PortalPalette.SurfaceCard.copy(alpha = 0.85f))
                                .padding(horizontal = 14.dp, vertical = 8.dp)
                        )
                    }
                } else {
                    val bmp = fallbackBitmap
                    if (bmp != null) {
                        Image(
                            bitmap = bmp.asImageBitmap(),
                            contentDescription = "Remote Desktop",
                            contentScale = ContentScale.Fit,
                            modifier = Modifier.fillMaxSize()
                        )
                    } else {
                        Text(
                            text = streamStatus,
                            style = PortalTypography.monoMetric,
                            color = PortalPalette.TextSecondary,
                            modifier = Modifier.align(Alignment.Center)
                        )
                    }
                }
            }

            // İsteğe Bağlı Sağ Kaydırma Şeridi
            if (showScrollStrip) {
                Box(
                    modifier = Modifier
                        .align(Alignment.CenterEnd)
                        .padding(end = 68.dp)
                        .width(34.dp)
                        .height(210.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(PortalPalette.SurfaceCard.copy(alpha = 0.85f))
                        .border(0.5.dp, PortalPalette.Hairline, RoundedCornerShape(12.dp))
                        .pointerInput(nodeId) {
                            var accum = 0f
                            detectVerticalDragGestures { _, dragAmount ->
                                accum += dragAmount
                                if (abs(accum) >= 20f) {
                                    val steps = (accum / 20f).toInt()
                                    accum -= steps * 20f
                                    onSendInput(
                                        JSONObject().apply {
                                            put("target_node_id", nodeId)
                                            put("type", "scroll")
                                            put("x_norm", 0.5)
                                            put("y_norm", 0.5)
                                            put("delta_y", -steps)
                                        }
                                    )
                                }
                            }
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "▲\n\n▼",
                        style = PortalTypography.monoCaption,
                        color = PortalPalette.TextSecondary,
                        textAlign = TextAlign.Center
                    )
                }
            }

            // Sağ Kenar Dikey Mat HUD
            Column(
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .padding(end = 10.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(PortalPalette.SurfaceCard.copy(alpha = 0.88f))
                    .border(0.5.dp, PortalPalette.Hairline, RoundedCornerShape(14.dp))
                    .padding(horizontal = 6.dp, vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = bwLabel,
                    style = PortalTypography.monoCaption.copy(fontSize = 9.5.sp),
                    color = PortalPalette.Accent,
                    textAlign = TextAlign.Center
                )
                HudChip(
                    label = "$liveFps\nFPS",
                    active = targetFps == 60,
                    onClick = { targetFps = if (targetFps == 60) 30 else 60 }
                )
                HudChip(
                    label = if (tr) "Kaydır" else "Scroll",
                    active = showScrollStrip,
                    onClick = { showScrollStrip = !showScrollStrip }
                )
                HudChip(
                    label = if (tr) "Klavye" else "Keys",
                    active = showKeyboardDock,
                    onClick = { showKeyboardDock = !showKeyboardDock }
                )
                HudChip(
                    label = "×",
                    active = false,
                    textColor = PortalPalette.StatusOffline,
                    onClick = onDismiss
                )
            }

            // Gizlenebilir Alt Klavye & Kısayol Çubuğu
            if (showKeyboardDock) {
                Column(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .background(PortalPalette.Background.copy(alpha = 0.94f))
                        .border(0.5.dp, PortalPalette.Hairline)
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf(
                            "Esc" to "Escape",
                            "Tab" to "Tab",
                            "Enter" to "Return",
                            "Back" to "BackSpace",
                            "Ctrl+C" to "ctrl+c",
                            "Ctrl+V" to "ctrl+v",
                            "Alt+Tab" to "alt+Tab",
                            "Super" to "Super_L"
                        ).forEach { (label, keySpec) ->
                            val shape = RoundedCornerShape(8.dp)
                            Box(
                                modifier = Modifier
                                    .clip(shape)
                                    .background(PortalPalette.SurfaceElevated)
                                    .border(0.5.dp, PortalPalette.Hairline, shape)
                                    .clickable {
                                        onSendInput(
                                            JSONObject().apply {
                                                put("target_node_id", nodeId)
                                                put("type", "key")
                                                put("key", keySpec)
                                            }
                                        )
                                    }
                                    .padding(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Text(text = label, style = PortalTypography.monoCaption, color = PortalPalette.TextPrimary)
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = keyboardText,
                            onValueChange = { keyboardText = it },
                            placeholder = {
                                Text(
                                    text = if (tr) "Metin gönder..." else "Send text...",
                                    style = PortalTypography.monoCaption,
                                    color = PortalPalette.TextSecondary
                                )
                            },
                            singleLine = true,
                            textStyle = PortalTypography.bodyThin.copy(color = PortalPalette.TextPrimary),
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                            keyboardActions = KeyboardActions(
                                onSend = {
                                    if (keyboardText.isNotEmpty()) {
                                        onSendInput(
                                            JSONObject().apply {
                                                put("target_node_id", nodeId)
                                                put("type", "text")
                                                put("text", keyboardText)
                                            }
                                        )
                                        keyboardText = ""
                                    }
                                }
                            ),
                            shape = RoundedCornerShape(10.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = PortalPalette.Accent,
                                unfocusedBorderColor = PortalPalette.Hairline,
                                focusedContainerColor = PortalPalette.SurfaceCard,
                                unfocusedContainerColor = PortalPalette.SurfaceCard
                            ),
                            modifier = Modifier.weight(1f)
                        )
                        MatteButton(
                            onClick = {
                                if (keyboardText.isNotEmpty()) {
                                    onSendInput(
                                        JSONObject().apply {
                                            put("target_node_id", nodeId)
                                            put("type", "text")
                                            put("text", keyboardText)
                                        }
                                    )
                                    keyboardText = ""
                                }
                            },
                            containerColor = PortalPalette.Accent,
                            contentColor = PortalPalette.Background
                        ) {
                            Text(text = if (tr) "Gönder" else "Send", style = PortalTypography.monoMetric)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun HudChip(
    label: String,
    active: Boolean,
    textColor: Color = if (active) PortalPalette.Accent else PortalPalette.TextPrimary,
    onClick: () -> Unit
) {
    val shape = RoundedCornerShape(10.dp)
    Box(
        modifier = Modifier
            .width(46.dp)
            .clip(shape)
            .background(if (active) PortalPalette.AccentSoft else PortalPalette.SurfaceElevated)
            .border(0.5.dp, if (active) PortalPalette.Accent.copy(alpha = 0.6f) else PortalPalette.Hairline, shape)
            .clickable(onClick = onClick)
            .padding(vertical = 7.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            style = PortalTypography.monoCaption.copy(fontSize = 10.sp),
            color = textColor,
            textAlign = TextAlign.Center
        )
    }
}
