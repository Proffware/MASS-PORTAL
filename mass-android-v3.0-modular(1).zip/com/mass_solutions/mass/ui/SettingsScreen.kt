package com.mass_solutions.mass.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.mass_solutions.mass.state.MassIntent
import com.mass_solutions.mass.state.MassPortalState
import com.mass_solutions.mass.state.Screen
import com.mass_solutions.mass.theme.MatteButton
import com.mass_solutions.mass.theme.MatteCard
import com.mass_solutions.mass.theme.PortalPalette
import com.mass_solutions.mass.theme.PortalTypography

@Composable
fun WelcomeScreen(
    state: MassPortalState,
    onContinue: () -> Unit,
    onOpenSettings: () -> Unit,
    onOpenPrivacy: () -> Unit
) {
    val tr = isTurkish()
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(PortalPalette.Background)
            .padding(horizontal = 24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                text = "MASS",
                style = PortalTypography.heroBrand,
                color = PortalPalette.TextPrimary
            )
            Text(
                text = if (tr) "Sunucu Telemetri, Terminal, SI ve Uzak Masaüstü"
                else "Server Telemetry, Console, SI & Remote Desktop",
                style = PortalTypography.bodyThin,
                color = PortalPalette.TextSecondary,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(12.dp))

            MatteCard(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = if (state.isDevicePaired) {
                        if (tr) "Eşleştirilmiş Cihaz Hazır" else "Paired Device Ready"
                    } else {
                        if (tr) "İlk Kurulum Gerekli" else "Initial Pairing Required"
                    },
                    style = PortalTypography.nodeTitle,
                    color = PortalPalette.TextPrimary
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = state.effectiveEndpoint,
                    style = PortalTypography.monoCaption,
                    color = PortalPalette.TextSecondary
                )
                Spacer(modifier = Modifier.height(14.dp))
                MatteButton(
                    onClick = if (state.isDevicePaired) onContinue else onOpenSettings,
                    containerColor = PortalPalette.Accent,
                    contentColor = PortalPalette.Background,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = if (state.isDevicePaired) {
                            if (tr) "Portala Gir" else "Enter Portal"
                        } else {
                            if (tr) "Sunucuyu Eşleştir" else "Pair Server"
                        },
                        style = PortalTypography.monoMetric
                    )
                }
            }

            Text(
                text = if (tr) "Gizlilik & Güvenlik Politikası" else "Privacy & Security Policy",
                style = PortalTypography.monoCaption,
                color = PortalPalette.TextSecondary,
                modifier = Modifier
                    .clickable(onClick = onOpenPrivacy)
                    .padding(8.dp)
            )
        }
    }
}

@Composable
fun SettingsScreen(
    state: MassPortalState,
    onIntent: (MassIntent) -> Unit,
    onOpenGuide: () -> Unit
) {
    val tr = isTurkish()
    var lanInput by remember(state.apiEndpoint) { mutableStateOf(state.apiEndpoint) }
    var remoteInput by remember(state.remoteEndpoint) { mutableStateOf(state.remoteEndpoint) }
    var caInput by remember(state.caCertPem) { mutableStateOf(state.caCertPem) }
    var pairCode by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            text = if (tr) "Ayarlar & Güvenlik" else "Settings & Security",
            style = PortalTypography.pageTitle,
            color = PortalPalette.TextPrimary
        )

        // Bağlantı Adresleri
        MatteCard(modifier = Modifier.fillMaxWidth()) {
            Text(
                text = if (tr) "SUNUCU BAĞLANTISI" else "SERVER CONNECTION",
                style = PortalTypography.sectionOverline,
                color = PortalPalette.TextSecondary
            )
            Spacer(modifier = Modifier.height(10.dp))

            OutlinedTextField(
                value = lanInput,
                onValueChange = { lanInput = it },
                label = { Text(if (tr) "Yerel LAN Adresi (HTTPS)" else "Local LAN URL (HTTPS)", style = PortalTypography.monoCaption) },
                singleLine = true,
                textStyle = PortalTypography.monoMetric.copy(color = PortalPalette.TextPrimary),
                shape = RoundedCornerShape(10.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = PortalPalette.Accent,
                    unfocusedBorderColor = PortalPalette.Hairline,
                    focusedContainerColor = PortalPalette.Background,
                    unfocusedContainerColor = PortalPalette.Background
                ),
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(8.dp))

            OutlinedTextField(
                value = remoteInput,
                onValueChange = { remoteInput = it },
                label = { Text(if (tr) "4G/5G Uzak Tünel (Otomatik Senkron)" else "4G/5G Remote Tunnel (Auto-Synced)", style = PortalTypography.monoCaption) },
                singleLine = true,
                textStyle = PortalTypography.monoMetric.copy(color = PortalPalette.TextPrimary),
                shape = RoundedCornerShape(10.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = PortalPalette.Accent,
                    unfocusedBorderColor = PortalPalette.Hairline,
                    focusedContainerColor = PortalPalette.Background,
                    unfocusedContainerColor = PortalPalette.Background
                ),
                modifier = Modifier.fillMaxWidth()
            )

            if (!state.endpointError.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = state.endpointError,
                    style = PortalTypography.monoCaption,
                    color = PortalPalette.StatusOffline
                )
            }

            Spacer(modifier = Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                MatteButton(
                    onClick = {
                        onIntent(MassIntent.UpdateEndpoint(lanInput))
                        onIntent(MassIntent.UpdateRemoteEndpoint(remoteInput))
                        onIntent(MassIntent.CheckServerHealth)
                    },
                    containerColor = PortalPalette.Accent,
                    contentColor = PortalPalette.Background,
                    modifier = Modifier.weight(1f)
                ) {
                    Text(text = if (tr) "Kaydet & Test Et" else "Save & Test", style = PortalTypography.monoMetric)
                }
            }
        }

        // Cihaz Eşleştirme (ECDSA P-256)
        MatteCard(modifier = Modifier.fillMaxWidth()) {
            Text(
                text = if (tr) "DONANIM EŞLEŞTİRME (ECDSA P-256)" else "HARDWARE PAIRING (ECDSA P-256)",
                style = PortalTypography.sectionOverline,
                color = PortalPalette.TextSecondary
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = if (state.isDevicePaired) {
                    if (tr) "Durum: Eşleştirildi (${state.licenseQuotaText})" else "Status: Paired (${state.licenseQuotaText})"
                } else {
                    if (tr) "Sunucu terminalindeki 6 haneli eşleştirme kodunu girin."
                    else "Enter the 6-digit pairing code shown on your server."
                },
                style = PortalTypography.bodyThin,
                color = if (state.isDevicePaired) PortalPalette.StatusOnline else PortalPalette.TextSecondary
            )
            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = pairCode,
                    onValueChange = { if (it.length <= 12) pairCode = it.uppercase() },
                    placeholder = { Text("6-DIGIT CODE", style = PortalTypography.monoCaption, color = PortalPalette.TextSecondary) },
                    singleLine = true,
                    textStyle = PortalTypography.monoMetric.copy(color = PortalPalette.TextPrimary),
                    shape = RoundedCornerShape(10.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = PortalPalette.Accent,
                        unfocusedBorderColor = PortalPalette.Hairline,
                        focusedContainerColor = PortalPalette.Background,
                        unfocusedContainerColor = PortalPalette.Background
                    ),
                    modifier = Modifier.weight(1f)
                )
                MatteButton(
                    onClick = {
                        val code = pairCode.trim()
                        if (code.isNotEmpty()) {
                            pairCode = ""
                            onIntent(MassIntent.PairDevice(code))
                        }
                    },
                    enabled = pairCode.isNotBlank(),
                    containerColor = PortalPalette.AccentSoft,
                    contentColor = PortalPalette.Accent
                ) {
                    Text(text = if (tr) "Eşleştir" else "Pair", style = PortalTypography.monoMetric)
                }
            }

            if (state.isDevicePaired) {
                Spacer(modifier = Modifier.height(10.dp))
                MatteButton(
                    onClick = { onIntent(MassIntent.ResetLocalPairing) },
                    containerColor = PortalPalette.SurfaceElevated,
                    contentColor = PortalPalette.StatusOffline,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(text = if (tr) "Yerel Eşleştirmeyi Sıfırla" else "Reset Local Pairing", style = PortalTypography.monoMetric)
                }
            }
        }

        // Güvenli Mod & İsteğe Bağlı CA PEM
        MatteCard(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = if (tr) "Salt Okunur Güvenli Mod" else "Read-Only Safe Mode",
                        style = PortalTypography.nodeTitle,
                        color = PortalPalette.TextPrimary
                    )
                    Text(
                        text = if (tr) "Terminal komut yürütmeyi geçici olarak kilitler."
                        else "Temporarily blocks remote terminal execution.",
                        style = PortalTypography.monoCaption,
                        color = PortalPalette.TextSecondary
                    )
                }
                Switch(
                    checked = state.safeModeEnabled,
                    onCheckedChange = { onIntent(MassIntent.ToggleSafeMode(it)) },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = PortalPalette.Background,
                        checkedTrackColor = PortalPalette.Accent
                    )
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(
                value = caInput,
                onValueChange = { caInput = it },
                label = { Text(if (tr) "Özel CA Sertifikası (PEM, isteğe bağlı)" else "Custom CA Certificate (PEM, optional)", style = PortalTypography.monoCaption) },
                minLines = 2,
                maxLines = 4,
                textStyle = PortalTypography.monoCaption.copy(color = PortalPalette.TextPrimary),
                shape = RoundedCornerShape(10.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = PortalPalette.Accent,
                    unfocusedBorderColor = PortalPalette.Hairline,
                    focusedContainerColor = PortalPalette.Background,
                    unfocusedContainerColor = PortalPalette.Background
                ),
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(8.dp))
            MatteButton(
                onClick = { onIntent(MassIntent.UpdateCaCertPem(caInput)) },
                containerColor = PortalPalette.SurfaceElevated,
                contentColor = PortalPalette.TextPrimary
            ) {
                Text(text = if (tr) "CA Sertifikasını Kaydet" else "Save CA PEM", style = PortalTypography.monoMetric)
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = if (tr) "Kullanım Kılavuzu" else "User Guide",
                style = PortalTypography.monoCaption,
                color = PortalPalette.Accent,
                modifier = Modifier
                    .clickable(onClick = onOpenGuide)
                    .padding(6.dp)
            )
            Text(
                text = if (tr) "Gizlilik Politikası" else "Privacy Policy",
                style = PortalTypography.monoCaption,
                color = PortalPalette.TextSecondary,
                modifier = Modifier
                    .clickable { onIntent(MassIntent.Navigate(Screen.PrivacyPolicy)) }
                    .padding(6.dp)
            )
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
fun PrivacyPolicyScreen(onBack: () -> Unit) {
    val tr = isTurkish()
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            text = if (tr) "Gizlilik & Güvenlik" else "Privacy & Security",
            style = PortalTypography.pageTitle,
            color = PortalPalette.TextPrimary
        )
        MatteCard(modifier = Modifier.fillMaxWidth()) {
            Text(
                text = if (tr) {
                    "• Tüm iletişim TLS 1.3 üzerinden şifrelenir ve Android Keystore içindeki ECDSA P-256 anahtarıyla imzalanır.\n" +
                    "• Her istek 30 saniyelik tek kullanımlık nonce ile tekrar saldırılarına karşı korunur.\n" +
                    "• Sudo parolaları bellekte veya diskte asla saklanmaz, yalnızca ilgili oturuma iletilir.\n" +
                    "• Üçüncü taraf analitik, reklam veya takip kütüphanesi bulunmaz."
                } else {
                    "• All traffic is encrypted via TLS 1.3 and signed using an Android Keystore ECDSA P-256 key.\n" +
                    "• Every request is protected against replay attacks with a single-use 30-second nonce.\n" +
                    "• Sudo passwords are never stored or logged.\n" +
                    "• Zero third-party analytics, ads, or tracking SDKs."
                },
                style = PortalTypography.bodyThin,
                color = PortalPalette.TextPrimary
            )
        }
        MatteButton(
            onClick = onBack,
            containerColor = PortalPalette.SurfaceElevated,
            contentColor = PortalPalette.TextPrimary
        ) {
            Text(text = if (tr) "Geri Dön" else "Back", style = PortalTypography.monoMetric)
        }
    }
}

@Composable
fun PortalGuideDialog(onDismiss: () -> Unit) {
    val tr = isTurkish()
    Dialog(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(PortalPalette.SurfaceCard)
                .border(0.5.dp, PortalPalette.Hairline, RoundedCornerShape(16.dp))
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(
                text = if (tr) "MASS v3.0 Kılavuzu" else "MASS v3.0 Guide",
                style = PortalTypography.nodeTitle,
                color = PortalPalette.TextPrimary
            )
            Text(
                text = if (tr) {
                    "• Özet: Cihaz kartlarındaki ince çizgiler canlı CPU/GPU trendini gösterir. Donanım dallarına dokunarak GPU, SSD ve port detaylarını açabilirsiniz.\n" +
                    "• Masaüstü: Tek dokunuş sol tık, çift dokunuş çift tık, uzun basış veya iki parmak dokunuşu sağ tık, iki parmak kaydırma tekerlek, üç parmak Alt+Tab gönderir.\n" +
                    "• Wi-Fi / 4G Geçişi: Ev ağına döndüğünüzde uygulama otomatik olarak 25 Mbps yerel LAN rotasına geçer."
                } else {
                    "• Dashboard: Sparklines display the last 20 CPU/GPU readings. Expand branches for GPUs, SSDs, and ports.\n" +
                    "• Desktop: 1-tap click, double-tap, long-press or 2-finger tap right-click, 2-finger scroll, 3-finger Alt+Tab.\n" +
                    "• Auto-Route: Automatically switches back to 25 Mbps LAN when home Wi-Fi is reachable."
                },
                style = PortalTypography.bodyThin,
                color = PortalPalette.TextSecondary
            )
            MatteButton(
                onClick = onDismiss,
                containerColor = PortalPalette.AccentSoft,
                contentColor = PortalPalette.Accent,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(text = if (tr) "Kapat" else "Close", style = PortalTypography.monoMetric)
            }
        }
    }
}
