package com.mass_solutions.mass.ui

import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.mass_solutions.mass.state.LocalAiMessage
import com.mass_solutions.mass.state.MassIntent
import com.mass_solutions.mass.state.MassPortalState
import com.mass_solutions.mass.theme.MatteButton
import com.mass_solutions.mass.theme.PortalPalette
import com.mass_solutions.mass.theme.PortalTypography
import kotlinx.coroutines.delay

@Composable
fun SsaScreen(
    state: MassPortalState,
    onIntent: (MassIntent) -> Unit
) {
    val tr = isTurkish()
    var queryText by remember { mutableStateOf("") }
    var modelMenuExpanded by remember { mutableStateOf(false) }
    var scopeMenuExpanded by remember { mutableStateOf(false) }
    var showPrompts by remember { mutableStateOf(false) }

    val selectedModel = state.localAiModels.find { it.id == state.selectedAiModelId }
        ?: state.localAiModels.firstOrNull()
    val selectedScopeNode = state.devices.find { it.id == state.selectedAiScopeNodeId }

    val listState = rememberLazyListState()
    LaunchedEffect(state.localAiMessages.size, state.ssaThinkingStartMs) {
        val total = state.localAiMessages.size + (if (state.ssaThinkingStartMs != null) 1 else 0)
        if (total > 0) listState.animateScrollToItem(total - 1)
    }

    val quickPrompts = remember(tr) {
        if (tr) listOf(
            "Sistem genel durumu nasıl?",
            "Sıcaklık ve GPU yükünü özetle",
            "Disk ve RAM darboğazı var mı?"
        ) else listOf(
            "Summarize overall system health",
            "Check GPU and thermal load",
            "Any disk or memory bottlenecks?"
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .imePadding()
            .padding(horizontal = 14.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Model + Kapsam Seçiciler
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Box {
                    val shape = RoundedCornerShape(10.dp)
                    Row(
                        modifier = Modifier
                            .clip(shape)
                            .background(PortalPalette.SurfaceCard)
                            .border(0.5.dp, PortalPalette.Hairline, shape)
                            .clickable { modelMenuExpanded = true }
                            .padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(5.dp)
                    ) {
                        Text(
                            text = selectedModel?.name ?: (if (tr) "Model tara" else "Scan models"),
                            style = PortalTypography.monoCaption,
                            color = PortalPalette.TextPrimary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(text = "▾", style = PortalTypography.monoCaption, color = PortalPalette.TextSecondary)
                    }
                    DropdownMenu(
                        expanded = modelMenuExpanded,
                        onDismissRequest = { modelMenuExpanded = false },
                        modifier = Modifier.background(PortalPalette.SurfaceElevated)
                    ) {
                        state.localAiModels.forEach { m ->
                            DropdownMenuItem(
                                text = {
                                    Text(
                                        text = "${m.name} (${m.runtime})",
                                        style = PortalTypography.monoMetric,
                                        color = PortalPalette.TextPrimary
                                    )
                                },
                                onClick = {
                                    modelMenuExpanded = false
                                    onIntent(MassIntent.SelectLocalAiModel(m.id))
                                }
                            )
                        }
                        DropdownMenuItem(
                            text = {
                                Text(
                                    text = if (tr) "Modelleri Yeniden Tara" else "Rescan Models",
                                    style = PortalTypography.monoMetric,
                                    color = PortalPalette.Accent
                                )
                            },
                            onClick = {
                                modelMenuExpanded = false
                                onIntent(MassIntent.ScanLocalAiModels)
                            }
                        )
                    }
                }

                Box {
                    val shape = RoundedCornerShape(10.dp)
                    Row(
                        modifier = Modifier
                            .clip(shape)
                            .background(PortalPalette.SurfaceCard)
                            .border(0.5.dp, PortalPalette.Hairline, shape)
                            .clickable { scopeMenuExpanded = true }
                            .padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(5.dp)
                    ) {
                        Text(
                            text = selectedScopeNode?.hostname ?: (if (tr) "Tüm Küme" else "All Nodes"),
                            style = PortalTypography.monoCaption,
                            color = PortalPalette.TextSecondary,
                            maxLines = 1
                        )
                        Text(text = "▾", style = PortalTypography.monoCaption, color = PortalPalette.TextSecondary)
                    }
                    DropdownMenu(
                        expanded = scopeMenuExpanded,
                        onDismissRequest = { scopeMenuExpanded = false },
                        modifier = Modifier.background(PortalPalette.SurfaceElevated)
                    ) {
                        DropdownMenuItem(
                            text = {
                                Text(
                                    text = if (tr) "Tüm Küme" else "All Nodes",
                                    style = PortalTypography.monoMetric,
                                    color = PortalPalette.TextPrimary
                                )
                            },
                            onClick = {
                                scopeMenuExpanded = false
                                onIntent(MassIntent.SelectLocalAiScopeNode(null))
                            }
                        )
                        state.devices.forEach { d ->
                            DropdownMenuItem(
                                text = {
                                    Text(
                                        text = d.hostname,
                                        style = PortalTypography.monoMetric,
                                        color = PortalPalette.TextPrimary
                                    )
                                },
                                onClick = {
                                    scopeMenuExpanded = false
                                    onIntent(MassIntent.SelectLocalAiScopeNode(d.id))
                                }
                            )
                        }
                    }
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = if (showPrompts) (if (tr) "Gizle" else "Hide") else (if (tr) "Öneriler" else "Prompts"),
                    style = PortalTypography.monoCaption,
                    color = PortalPalette.Accent,
                    modifier = Modifier
                        .clickable { showPrompts = !showPrompts }
                        .padding(horizontal = 4.dp, vertical = 4.dp)
                )
                Text(
                    text = if (tr) "Temizle" else "Clear",
                    style = PortalTypography.monoCaption,
                    color = PortalPalette.TextSecondary,
                    modifier = Modifier
                        .clickable { onIntent(MassIntent.ClearLocalAiChat) }
                        .padding(horizontal = 4.dp, vertical = 4.dp)
                )
            }
        }

        if (showPrompts) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                quickPrompts.forEach { p ->
                    val shape = RoundedCornerShape(8.dp)
                    Box(
                        modifier = Modifier
                            .clip(shape)
                            .background(PortalPalette.SurfaceElevated)
                            .border(0.5.dp, PortalPalette.Hairline, shape)
                            .clickable { onIntent(MassIntent.SendLocalAiQuery(p)) }
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text(text = p, style = PortalTypography.monoCaption, color = PortalPalette.TextPrimary)
                    }
                }
            }
        }

        // Mesaj Listesi
        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(vertical = 4.dp)
        ) {
            if (state.localAiMessages.isEmpty() && state.ssaThinkingStartMs == null) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 36.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "MASS SI",
                                style = PortalTypography.brandTitle,
                                color = PortalPalette.TextPrimary
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = if (tr) "Yerel Ollama asistanı. Günlük sohbet veya canlı telemetri analizi sorabilirsiniz."
                                else "Local Ollama assistant. Ask casual questions or live telemetry diagnostics.",
                                style = PortalTypography.bodyThin,
                                color = PortalPalette.TextSecondary
                            )
                        }
                    }
                }
            }

            items(state.localAiMessages, key = { it.id }) { msg ->
                SsaMessageRow(msg = msg)
            }

            if (state.ssaThinkingStartMs != null) {
                item(key = "ssa-thinking") {
                    SsaThinkingBubble(startTimeMs = state.ssaThinkingStartMs)
                }
            }
        }

        // Mesaj Giriş Satırı
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = queryText,
                onValueChange = { queryText = it },
                placeholder = {
                    Text(
                        text = if (tr) "Bir şey sorun..." else "Ask something...",
                        style = PortalTypography.bodyThin,
                        color = PortalPalette.TextSecondary
                    )
                },
                singleLine = true,
                textStyle = PortalTypography.bodyThin.copy(color = PortalPalette.TextPrimary),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(
                    onSend = {
                        val trimmed = queryText.trim()
                        if (trimmed.isNotEmpty() && state.ssaThinkingStartMs == null) {
                            queryText = ""
                            onIntent(MassIntent.SendLocalAiQuery(trimmed))
                        }
                    }
                ),
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = PortalPalette.Accent.copy(alpha = 0.7f),
                    unfocusedBorderColor = PortalPalette.Hairline,
                    focusedContainerColor = PortalPalette.SurfaceCard,
                    unfocusedContainerColor = PortalPalette.SurfaceCard,
                    cursorColor = PortalPalette.Accent
                ),
                modifier = Modifier.weight(1f)
            )

            MatteButton(
                onClick = {
                    val trimmed = queryText.trim()
                    if (trimmed.isNotEmpty() && state.ssaThinkingStartMs == null) {
                        queryText = ""
                        onIntent(MassIntent.SendLocalAiQuery(trimmed))
                    }
                },
                enabled = queryText.isNotBlank() && state.ssaThinkingStartMs == null,
                containerColor = PortalPalette.Accent,
                contentColor = PortalPalette.Background,
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp)
            ) {
                Text(text = if (tr) "Gönder" else "Send", style = PortalTypography.monoMetric)
            }
        }
    }
}

@Composable
private fun SsaMessageRow(msg: LocalAiMessage) {
    val tr = isTurkish()
    var showThink by remember(msg.id) { mutableStateOf(false) }
    val shape = RoundedCornerShape(12.dp)
    val bg = if (msg.isFromUser) PortalPalette.AccentSoft else PortalPalette.SurfaceCard

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(bg)
            .border(0.5.dp, PortalPalette.Hairline, shape)
            .animateContentSize()
            .padding(12.dp)
    ) {
        Text(
            text = msg.senderLabel,
            style = PortalTypography.sectionOverline,
            color = if (msg.isFromUser) PortalPalette.Accent else PortalPalette.TextSecondary
        )
        if (!msg.thinkingText.isNullOrBlank()) {
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = (if (showThink) "▾ " else "▸ ") + (if (tr) "Düşünce Süreci" else "Reasoning"),
                style = PortalTypography.monoCaption,
                color = PortalPalette.TextSecondary,
                modifier = Modifier.clickable { showThink = !showThink }
            )
            if (showThink) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = msg.thinkingText,
                    style = PortalTypography.monoCaption,
                    color = PortalPalette.TextSecondary
                )
            }
        }
        Spacer(modifier = Modifier.height(5.dp))
        SelectionContainer {
            Text(
                text = msg.text,
                style = PortalTypography.bodyThin,
                color = PortalPalette.TextPrimary
            )
        }
    }
}

@Composable
private fun SsaThinkingBubble(startTimeMs: Long) {
    val tr = isTurkish()
    var elapsedSec by remember(startTimeMs) {
        mutableStateOf(((System.currentTimeMillis() - startTimeMs) / 1000L).coerceAtLeast(0L))
    }
    LaunchedEffect(startTimeMs) {
        while (true) {
            elapsedSec = ((System.currentTimeMillis() - startTimeMs) / 1000L).coerceAtLeast(0L)
            delay(1000L)
        }
    }
    val shape = RoundedCornerShape(12.dp)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(PortalPalette.SurfaceCard)
            .border(0.5.dp, PortalPalette.Hairline, shape)
            .padding(12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = if (tr) "SI yanıt hazırlıyor..." else "SI is thinking...",
            style = PortalTypography.bodyThin,
            color = PortalPalette.TextSecondary
        )
        Text(
            text = "${elapsedSec}s",
            style = PortalTypography.monoCaption,
            color = PortalPalette.Accent
        )
    }
}
